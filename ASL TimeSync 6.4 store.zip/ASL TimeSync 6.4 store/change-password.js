     function disableConsoleLog() {
    console.log = function() {};
}
// Call disableConsoleLog() to disable console logging
disableConsoleLog();
  
  const googleSheetsApiKey = "AIzaSyDIuRc7QsUTJ8C5-0yzXeY9bM79-jxyTFY";

async function validateAndUpdatePassword() {
    try {
        const inputUsername = document.getElementById("username").value.trim().toUpperCase();
        const inputPassword = document.getElementById("currentPassword").value.trim();
        const inputEmail = document.getElementById("email").value.trim().toLowerCase();
        const newPassword = document.getElementById("newPassword").value.trim();
        const confirmPassword = document.getElementById("confirmPassword").value.trim();

        if (!inputUsername || !inputPassword || !inputEmail || !newPassword || !confirmPassword) {
            alert("⚠️ Please fill in all fields.");
            return;
        }

        if (newPassword !== confirmPassword) {
            alert("❌ New password and confirm password do not match.");
            return;
        }

        const token = await new Promise((resolve, reject) => {
            chrome.identity.getAuthToken({ interactive: true }, function (token) {
                if (!token) reject(new Error("Failed to get auth token."));
                else resolve(token);
            });
        });

        const { sheetId } = await new Promise((resolve) => {
            chrome.storage.local.get(['sheetId'], resolve);
        });

        if (!sheetId) throw new Error("Sheet ID not found.");

        const sheetName = "Credential";

        const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!A:F?key=${googleSheetsApiKey}`, {
            method: "GET",
            headers: { Authorization: `Bearer ${token}` }
        });

        const data = await response.json();
        const rows = data.values;
        const rowIndex = rows.findIndex(row => row[0]?.trim().toUpperCase() === inputUsername);

        if (rowIndex === -1) {
            alert("❌ Username not found.");
            return;
        }

        const savedRow = rows[rowIndex];
        const savedPassword = savedRow[1]?.trim();
        const savedEmail = savedRow[5]?.trim().toLowerCase();

        // Get current signed-in Gmail
        const userInfoResponse = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
            headers: { Authorization: `Bearer ${token}` }
        });
        const userInfo = await userInfoResponse.json();
        const currentSignedInGmail = userInfo.email?.trim().toLowerCase();

        // Validate current password
        if (inputPassword !== savedPassword) {
            alert("❌ Current password is incorrect.");
            return;
        }
          // 🚫 Check new password length
         if (newPassword.length > 11) {
             alert("❌ New password must not be more than 11 characters.");
           return;
         }
        // Validate input email
        if (inputEmail !== savedEmail && savedEmail !== "unlinked") {
            alert("❌ Entered Gmail does not match saved Gmail.");
            return;
        }

        // Validate signed-in Google account
        if (currentSignedInGmail !== savedEmail && savedEmail !== "unlinked") {
            alert("❌ You are signed in with an unauthorized Google account.");
            return;
        }

        // ✅ All validation passed – update password
        const updateRange = `${sheetName}!B${rowIndex + 1}`;

        const updateResponse = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${updateRange}?valueInputOption=RAW`, {
            method: "PUT",
            headers: {
                Authorization: `Bearer ${token}`,
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                range: updateRange,
                values: [[newPassword]]
            })
        });

        if (!updateResponse.ok) {
            throw new Error("Failed to update password in sheet.");
        }

        alert("✅ Password updated successfully!");
		// Clear all form fields
document.getElementById("username").value = "";
document.getElementById("currentPassword").value = "";
document.getElementById("email").value = "";
document.getElementById("newPassword").value = "";
document.getElementById("confirmPassword").value = "";


    } catch (error) {
        console.error("⚠️ Error:", error);
        alert(error.message || "An unexpected error occurred.");
    }
}



document.querySelector("form").addEventListener("submit", function (e) {
    e.preventDefault();
    validateAndUpdatePassword();
});
