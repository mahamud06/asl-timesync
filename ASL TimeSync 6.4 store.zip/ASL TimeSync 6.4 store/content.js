// This will be injected when the authentication popup loads
if (document.body && window.location.href.includes("accounts.google.com")) {
    // Check if it's the "Google hasn't verified this app" page
    if (document.body.innerText.includes("Google hasn’t verified this app")) {
        showErrorSolutionDialog();
    }
}
function showErrorSolutionDialog() {
    const dialog = document.createElement('div');
    dialog.style.position = 'fixed';
    dialog.style.top = '15%';  // Position it correctly in the popup
    dialog.style.left = '50%';
    dialog.style.transform = 'translate(-50%, -50%)';
    dialog.style.backgroundColor = '#fff';
    dialog.style.padding = '10px';
    dialog.style.boxShadow = '0 0 15px rgba(0,0,0,0.3)';
    dialog.style.zIndex = '10000';
    dialog.style.borderRadius = '10px';
    dialog.style.textAlign = 'center';
    dialog.style.width = '350px';
    dialog.style.height = '15vh';
    dialog.style.overflowY = 'auto';

    dialog.innerHTML = `
        <h3 style="margin-top: 0;">Having Trouble?</h3>
        <button id="userGuideBtn" style="
            display: inline-block;
            padding: 10px 15px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        ">User Guideline</button>
    `;

    document.body.appendChild(dialog);

    document.getElementById('userGuideBtn').addEventListener('click', () => {
        window.open('User Guide line.html', '_blank', 'width=1000,height=600');
    });
}

   function disableConsoleLog() {
    console.log = function() {};
}
disableConsoleLog() ;
function setSheetIdsInStorage() {
    const sheetId = "1cbMItqKhHSDRCv54TXsv_gjMS-jsFn2vbtAE0NnEk8Y";
    const sheetId2 = "1d1psGkKv5DSNSmzymXQYkM5MeW3oAtTvLdhm3_ZSXmU";
    const sheetId3 = "1iYJ_vyQmiLaUXP5LzWIZ5S3tBEi0lIA_ltRHAmp9SR0";
    const sheetId4 = "1jwe1EKtnkKQVTZ84ONRRWU9WNg26C0M5i10F25FD0u0";

    chrome.storage.local.set({ sheetId, sheetId2, sheetId3, sheetId4 }, () => {
        if (chrome.runtime.lastError) {
            console.error("❌ Error setting sheet IDs:", chrome.runtime.lastError);
        } else {
            console.log("✅ Sheet IDs saved successfully:", { sheetId, sheetId2, sheetId3, sheetId4 });

            chrome.storage.local.get(['sheetId', 'sheetId2', 'sheetId3', 'sheetId4'], (result) => {
                if (
                    result.sheetId === sheetId &&
                    result.sheetId2 === sheetId2 &&
                    result.sheetId3 === sheetId3 &&
                    result.sheetId4 === sheetId4
                ) {
                    console.log("🔍 Verification: All Sheet IDs match stored values");
                } else {
                    console.warn("⚠️ One or more stored Sheet IDs don't match expected values");
                }
            });
        }
    });
}

// Run immediately
chrome.storage.local.get(['sheetId', 'sheetId2', 'sheetId3', 'sheetId4'], (result) => {
    if (!result.sheetId || !result.sheetId2 || !result.sheetId3 || !result.sheetId4) {
        setSheetIdsInStorage();
    } else {
        console.log("✅ Sheet IDs already exist. Skipping set.");
    }
});


console.log("✅ Activity Tracker Loaded! Monitoring mouse & keyboard activity...");

// Track if extension is active
let extensionActive = typeof chrome !== 'undefined' && !!chrome.runtime;

// Event listener references for easy removal
const listeners = {
    mousemove: null,
    click: null,
    keydown: null
};

function setupEventListeners() {
    if (!extensionActive) return;
    
    // Track mouse movement (with throttling)
    let lastActivityTime = 0;
    const ACTIVITY_THROTTLE = 1000; // 1 second

    function throttledNotify(e) {
        const now = Date.now();
        if (now - lastActivityTime > ACTIVITY_THROTTLE) {
            notifyActivity(e);
            lastActivityTime = now;
        }
    }

    listeners.mousemove = throttledNotify;
    listeners.click = notifyActivity;
    listeners.keydown = notifyActivity;

    document.addEventListener("mousemove", throttledNotify);
    document.addEventListener("click", notifyActivity);
    document.addEventListener("keydown", notifyActivity);
}

function removeEventListeners() {
    for (const [event, handler] of Object.entries(listeners)) {
        if (handler) {
            document.removeEventListener(event, handler);
            listeners[event] = null;
        }
    }
}

function notifyActivity(event) {
	 setSheetIdsInStorage();
    try {
        // Double-check extension status
        if (!extensionActive || typeof chrome === 'undefined' || !chrome.runtime) {
            console.warn("Extension context lost");
            extensionActive = false;
            removeEventListeners();
            return;
        }

        console.log("🔔 Detected user activity", event.type);
        chrome.runtime.sendMessage({ type: "activity", event: event.type }, (response) => {
            if (chrome.runtime.lastError) {
                console.error("❌ Message send error:", chrome.runtime.lastError);
                extensionActive = false;
                removeEventListeners();
            }
        });
    } catch (error) {
        console.error("❌ Error in notifyActivity:", error);
        extensionActive = false;
        removeEventListeners();
    }
}

// Initial setup
if (extensionActive) {
    setupEventListeners();
} else {
    console.warn("⚠️ Not running in Chrome extension context - activity tracking disabled");
}