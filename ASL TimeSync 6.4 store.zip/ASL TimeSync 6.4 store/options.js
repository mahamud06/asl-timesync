// Preload default values and restore from localStorage
window.addEventListener('DOMContentLoaded', () => {
  const defaultValues = {
    baseSalary: 22000,
    workingDays: 26,
    daysWorked: '',
    overtimeHours: '',
    hoursPerDay: 9
  };

  // Restore or set defaults
  Object.keys(defaultValues).forEach(key => {
    const input = document.getElementById(key);
    const stored = localStorage.getItem(key);
    input.value = stored !== null ? stored : defaultValues[key];

    // Save on change
    input.addEventListener('input', () => {
      localStorage.setItem(key, input.value);
    });
  });
});

// Calculate button logic
document.getElementById('calculateSalaryBtn').addEventListener('click', function () {
  const baseSalary = parseFloat(document.getElementById('baseSalary').value);
  const contractedDays = parseInt(document.getElementById('workingDays').value);
  const daysWorked = parseInt(document.getElementById('daysWorked').value);
  const overtimeHours = parseFloat(document.getElementById('overtimeHours').value);
  const hoursPerDay = parseFloat(document.getElementById('hoursPerDay').value);

  // Basic validation
  if (isNaN(baseSalary) || baseSalary <= 0) {
    alert('Please enter a valid base salary.');
    return;
  }
  if (isNaN(contractedDays) || contractedDays <= 0) {
    alert('Please enter valid contracted days.');
    return;
  }
  if (isNaN(daysWorked) || daysWorked < 0) {
    alert('Please enter valid days worked.');
    return;
  }
  if (isNaN(overtimeHours) || overtimeHours < 0) {
    alert('Please enter valid overtime hours.');
    return;
  }
  if (isNaN(hoursPerDay) || hoursPerDay <= 0) {
    alert('Please enter valid hours per day.');
    return;
  }

  // Calculations
  const dailyRate = baseSalary / contractedDays;
  const hourlyRate = dailyRate / hoursPerDay;
  const overtimeRate = hourlyRate * 1.5;

  const earnedSalary = daysWorked * dailyRate;
  const overtimePay = overtimeHours * overtimeRate;
  const totalSalary = earnedSalary + overtimePay-500;

document.getElementById('salaryResults').innerHTML = `
  <p><strong>Daily Rate:</strong> $${dailyRate.toFixed(2)}</p>
  <p><strong>Hourly Rate:</strong> $${hourlyRate.toFixed(2)}</p>
  <p><strong>Overtime Rate (1.5x):</strong> $${overtimeRate.toFixed(2)}</p>
  <hr>
  <p><strong>Earned Salary (for ${daysWorked} days):</strong> $${earnedSalary.toFixed(2)}</p>
  <p><strong>Overtime Pay (${overtimeHours} hrs):</strong> $${overtimePay.toFixed(2)}</p>
  <p><strong>Provident Fund Deduction:</strong> -$500.00</p>
  <p><strong>Total Salary:</strong> <span style="color: green;">$${totalSalary.toFixed(2)}</span></p>
`;
});



































document.addEventListener('DOMContentLoaded', function () {
  const userGuideBtn = document.getElementById('userGuideBtn');
  if (userGuideBtn) {
    userGuideBtn.addEventListener('click', function () {
      window.open('User_Guideline.html', '_blank');
    });
  }

  const salaryCalcBtn = document.getElementById('salaryCalcBtn');
  if (salaryCalcBtn) {
    salaryCalcBtn.addEventListener('click', function () {
      window.open('Salarycalculation.html', '_blank', 'width=1000,height=600');
    });
  }
});

function createNotifFields(data = {}) {
  const container = document.getElementById('notifContainer');

  const wrapper = document.createElement('div');
  wrapper.className = 'notif-entry';
  wrapper.innerHTML = `
    <label>Reminder Title:</label>
    <input type="text" class="notifTitle" placeholder="Daily Reminder" value="${data.notificationTitle || ''}">

    <label>Reminder Message:</label>
    <input type="text" class="notifMessage" placeholder="Don't forget to check-in!" value="${data.notificationMessage || ''}">

    <label>Time:</label>
    <input type="time" class="notifTime" value="${data.dailyNotificationTime || ''}">

    <div style="display: flex; justify-content: space-between; gap: 10px; margin-top: 5px;">
      <button class="set-btn">Set</button>
      <button class="delete-btn" style="margin-left: auto;">Delete</button>
    </div>
  `;

wrapper.querySelector('.delete-btn').addEventListener('click', () => {
  const time = wrapper.querySelector('.notifTime').value;
  wrapper.remove();

  // Cancel alarm
  chrome.runtime.sendMessage({ action: 'cancelAlarm', time });

  // Update storage
  const notifWrappers = document.querySelectorAll('.notif-entry');
  const notifications = [];

  notifWrappers.forEach(w => {
    const title = w.querySelector('.notifTitle').value.trim();
    const message = w.querySelector('.notifMessage').value.trim();
    const time = w.querySelector('.notifTime').value;

    if (title && message && time) {
      notifications.push({
        notificationTitle: title,
        notificationMessage: message,
        dailyNotificationTime: time
      });
    }
  });

  chrome.storage.sync.set({ notifications });
});


  // Optional: Individual Set handler to trigger global save
  wrapper.querySelector('.set-btn').addEventListener('click', () => {
    document.getElementById('saveNotifs')?.click();
  });

  container.appendChild(wrapper);
}

// Add Notification
document.getElementById('addNotif').addEventListener('click', () => {
  createNotifFields();
});

// Save All Notifications
document.getElementById('saveNotifs').addEventListener('click', () => {
  const statusEl = document.getElementById('status');
  const notifWrappers = document.querySelectorAll('.notif-entry');

  const notifications = [];
  let valid = true;

  notifWrappers.forEach(wrapper => {
    const title = wrapper.querySelector('.notifTitle').value.trim();
    const message = wrapper.querySelector('.notifMessage').value.trim();
    const time = wrapper.querySelector('.notifTime').value;

    if (!title || !message || !time) {
      valid = false;
      return;
    }

    notifications.push({
      notificationTitle: title,
      notificationMessage: message,
      dailyNotificationTime: time
    });
  });

  if (!valid) {
    statusEl.textContent = 'Please fill all fields.';
    statusEl.style.color = 'red';
    return;
  }

  chrome.storage.sync.set({ notifications }, () => {
    notifications.forEach(notif => {
      chrome.runtime.sendMessage({ action: 'scheduleAlarm', time: notif.dailyNotificationTime });
    });

    statusEl.textContent = 'All notifications saved!';
    statusEl.style.color = 'green';
  });
});

// Load from storage on startup
window.onload = () => {
  chrome.storage.sync.get('notifications', (data) => {
    if (data.notifications && Array.isArray(data.notifications)) {
      data.notifications.forEach(notif => createNotifFields(notif));
    } else {
      createNotifFields(); // One default
    }
  });
};
