
function disableConsoleLog() {
    console.log = function() {};
}
// Uncomment the next line to disable console logging in production
// disableConsoleLog();

// Helper function to convert 24-hour time to 12-hour format with seconds (HH:MM:SS AM/PM)
function to12HourFormat(time) {
    if (!time || time === 'N/A' || time.trim() === '') return 'N/A';
    const [hours, minutes] = time.split(':').map(Number);
    const period = hours >= 12 ? 'PM' : 'AM';
    const adjustedHours = hours % 12 || 12; // Convert 0 to 12 for midnight
    return `${adjustedHours}:${minutes.toString().padStart(2, '0')}:00 ${period}`;
}

// Helper function to convert 12-hour HH:MM:SS AM/PM to 24-hour HH:MM for form
function to24HourFormat(time) {
    if (!time || time === 'N/A' || time.trim() === '') return '';
    try {
        const [timePart, period] = time.split(' ');
        let [hours, minutes] = timePart.split(':').map(Number);
        if (period && period.toUpperCase() === 'PM' && hours !== 12) hours += 12;
        if (period && period.toUpperCase() === 'AM' && hours === 12) hours = 0;
        return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
    } catch (error) {
        console.warn(`Invalid time format: "${time}"`, error);
        return '';
    }
}

// Helper function to convert column index to letter (0=A, 1=B, ..., 515=OU, 1535=AFW)
function getColumnLetter(index) {
    let letters = '';
    while (index >= 0) {
        letters = String.fromCharCode((index % 26) + 65) + letters;
        index = Math.floor(index / 26) - 1;
    }
    return letters;
}

// Helper function for API calls with retries
async function fetchWithRetry(url, options, retries = 3, delay = 1500) {
    for (let i = 0; i < retries; i++) {
        try {
            const response = await fetch(url, options);
            if (!response.ok && response.status === 429) {
                console.warn(`Rate limit hit (429) on attempt ${i + 1}. Retrying after ${delay}ms...`);
                await new Promise(resolve => setTimeout(resolve, delay));
                delay *= 2; // Exponential backoff
                continue;
            }
            return response;
        } catch (error) {
            console.warn(`Fetch error on attempt ${i + 1}: ${error.message}`);
            if (i === retries - 1) throw error;
            await new Promise(resolve => setTimeout(resolve, delay));
            delay *= 2;
        }
    }
}

const googleSheetsApiKey = "AIzaSyDIuRc7QsUTJ8C5-0yzXeY9bM79-jxyTFY";

// Function to check user permission by matching username in Credential sheet and returning column M departments
async function userPermission(username, token) {
    try {
        const sheetId = '1cbMItqKhHSDRCv54TXsv_gjMS-jsFn2vbtAE0NnEk8Y'; // Credential sheet ID
        const sheetName = 'Credential';
        
        // Fetch usernames and departments from A2:M (assuming A1 is a header)
        const response = await fetchWithRetry(
            `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!A2:M`,
            {
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        if (!response.ok) {
            const errorData = await response.json();
            console.error('Error fetching usernames for permission check:', errorData);
            throw new Error(`Failed to fetch usernames: ${errorData.error?.message || 'Unknown error'}`);
        }

        const data = await response.json();
        const rows = data.values || [];
        console.log('Fetched usernames and departments from A2:M (Credential):', rows);

        // Find the row where username matches (case-insensitive)
        const matchedRowIndex = rows.findIndex(row => 
            row[0] && row[0].trim().toLowerCase() === username.trim().toLowerCase()
        );

        if (matchedRowIndex === -1) {
            console.warn(`Username "${username}" not found in column A of Credential sheet ${sheetId}.`);
            return null; // No match found
        }

        // Column M is index 12 (A=0, B=1, ..., M=12)
        const departmentValue = rows[matchedRowIndex][12] ? rows[matchedRowIndex][12].trim() : '';
        console.log(`Department for username "${username}" found at row ${matchedRowIndex + 2}: ${departmentValue}`);
        return departmentValue || null; // Return department string or null if empty

    } catch (error) {
        console.error('Error checking user permission:', error);
        return null; // Return null on error to allow caller to handle
    }
}

// Function to populate employee dropdown from AGENTS_MISSING_DATA sheet, filtered by user's permitted departments
async function populateEmployeeDropdown(token, userDepartment = null) {
    try {
        const sheetId = '1d1psGkKv5DSNSmzymXQYkM5MeW3oAtTvLdhm3_ZSXmU';
        const sheetName = 'AGENTS_MISSING_DATA';
        const employeeSelect = document.getElementById('employeeName');

        // Fetch employee names and departments from A2:C
        const response = await fetchWithRetry(
            `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!A2:C`,
            {
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        if (!response.ok) {
            const errorData = await response.json();
            console.error('Error fetching employee names and departments:', errorData);
            throw new Error(`Failed to fetch employee data: ${errorData.error?.message || 'Unknown error'}`);
        }

        const data = await response.json();
        const employees = data.values ? data.values.map(row => ({
            name: row[0] ? row[0].trim().toUpperCase() : '',
            department: row[2] ? row[2].trim() : ''
        })).filter(employee => employee.name) : [];
        console.log('Fetched employee data from AGENTS_MISSING_DATA:', employees);

        // Clear existing options except the placeholder
        employeeSelect.innerHTML = '<option value="" disabled selected>Select an employee</option>';

        // If no userDepartment provided, include all employees
        let filteredEmployees = employees;
        if (userDepartment) {
            // Split departments by commas (e.g., "Miinto/Arrival,Miinto/TVB" -> ["Miinto/Arrival", "Miinto/TVB"])
            const allowedDepartments = userDepartment.split(',').map(dep => dep.trim().toLowerCase());
            console.log('Filtering employees by allowed departments:', allowedDepartments);

            // Filter employees by matching department
            filteredEmployees = employees.filter(employee => 
                employee.department && 
                allowedDepartments.includes(employee.department.toLowerCase())
            );
            console.log('Filtered employees:', filteredEmployees);
        }

        // Add filtered employee names to the dropdown (without department)
        filteredEmployees.forEach(employee => {
            const option = document.createElement('option');
            option.value = employee.name;
            option.textContent = employee.name; // Show only employee name
            employeeSelect.appendChild(option);
        });

        console.log('Employee dropdown populated with', filteredEmployees.length, 'options.');
    } catch (error) {
        console.error('Error populating employee dropdown:', error);
        alert('⚠️ Failed to load employee names from Google Sheet. Check console for details.');
    }
}

// Function to load attendance data from Google Sheet
async function loadAttendanceData(employeeName, token) {
    try {
        const sheetId = '1jwe1EKtnkKQVTZ84ONRRWU9WNg26C0M5i10F25FD0u0';
        const sheetName = 'Sheet1';

        // Clear all time inputs before loading
        const form = document.getElementById('attendanceForm');
        const inputs = form.querySelectorAll('input[type="time"]');
        inputs.forEach(input => input.value = '');
        console.log('Cleared all time inputs before loading.');

        // Fetch row 1 (A1:AFW1) to find the username column
        const headerResponse = await fetchWithRetry(
            `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!A1:AFW1`,
            {
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        if (!headerResponse.ok) {
            const errorData = await headerResponse.json();
            console.error('Header fetch response error:', errorData);
            throw new Error(`Failed to fetch row 1: ${errorData.error?.message || 'Unknown error'}`);
        }

        const headerData = await headerResponse.json();
        const headerValues = headerData.values ? headerData.values[0] : [];
        console.log('Fetched headers from row 1 (A1:AFW1):', headerValues);
        console.log('Trimmed headers:', headerValues.map(val => val ? val.trim() : ''));

        // Find the column index of the username (case-insensitive)
        const usernameColumnIndex = headerValues.findIndex(val => val && val.trim().toLowerCase() === employeeName.toLowerCase());
        if (usernameColumnIndex === -1) {
            console.error('Username not found in row 1 (A1:AFW1):', employeeName);
            return; // Don't alert on load
        }

        // Determine check-in and check-out columns (e.g., OU → OV, OW)
        const checkInColumn = getColumnLetter(usernameColumnIndex + 1);
        const checkOutColumn = getColumnLetter(usernameColumnIndex + 2);
        console.log(`Username found in column ${getColumnLetter(usernameColumnIndex)} (index ${usernameColumnIndex}).`);
        console.log(`Check-in column: ${checkInColumn} (index ${usernameColumnIndex + 1}), Check-out column: ${checkOutColumn} (index ${usernameColumnIndex + 2})`);

        // Fetch dates and times from B5:[checkOutColumn]35
        const dataResponse = await fetchWithRetry(
            `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!B5:${checkOutColumn}35`,
            {
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        if (!dataResponse.ok) {
            const errorData = await dataResponse.json();
            console.error('Data fetch response error:', errorData);
            throw new Error(`Failed to fetch attendance data: ${errorData.error?.message || 'Unknown error'}`);
        }

        const sheetData = await dataResponse.json();
        const rows = sheetData.values || [];
        console.log('Fetched attendance data (B5:' + checkOutColumn + '35):', rows);
        console.log('Number of rows fetched:', rows.length);

        // Map sheet dates to form inputs
        rows.forEach((row, index) => {
            const sheetDate = row[0] ? row[0].trim() : '';
            // Adjust indices relative to the fetch range starting at B (index 1)
            const checkInTime = row[usernameColumnIndex] ? row[usernameColumnIndex].trim() : ''; // OV (index 411 - 1 = 410)
            const checkOutTime = row[usernameColumnIndex + 1] ? row[usernameColumnIndex + 1].trim() : ''; // OW (index 412 - 1 = 411)
            const formDate = `08-${(index + 1).toString().padStart(2, '0')}-2025`;

            console.log(`Row ${index + 5}: Sheet date="${sheetDate}", Form date="${formDate}"`);
            console.log(`Check-In (column ${checkInColumn}, index ${usernameColumnIndex + 1}): "${checkInTime}"`);
            console.log(`Check-Out (column ${checkOutColumn}, index ${usernameColumnIndex + 2}): "${checkOutTime}"`);

            if (sheetDate === formDate) {
                const checkInInput = document.querySelector(`input[name="checkIn_${index + 1}"]`);
                const checkOutInput = document.querySelector(`input[name="checkOut_${index + 1}"]`);
                
                console.log(`Query for checkIn_${index + 1}:`, checkInInput ? 'Found' : 'Not found');
                console.log(`Query for checkOut_${index + 1}:`, checkOutInput ? 'Found' : 'Not found');
                
                if (checkInInput) {
                    const formattedCheckIn = to24HourFormat(checkInTime);
                    checkInInput.value = formattedCheckIn;
                    console.log(`Set checkIn_${index + 1} to "${formattedCheckIn}" for date ${formDate}`);
                } else {
                    console.warn(`checkIn_${index + 1} input not found for date ${formDate}`);
                }
                if (checkOutInput) {
                    const formattedCheckOut = to24HourFormat(checkOutTime);
                    checkOutInput.value = formattedCheckOut;
                    console.log(`Set checkOut_${index + 1} to "${formattedCheckOut}" for date ${formDate}`);
                } else {
                    console.warn(`checkOut_${index + 1} input not found for date ${formDate}`);
                }
            } else {
                console.warn(`Date mismatch for row ${index + 5}: Sheet date="${sheetDate}" != Form date="${formDate}"`);
            }
        });

    } catch (error) {
        console.error('Error loading attendance data:', error);
        // Don't alert on load
    }
}

// Initialize username and load data on page load
document.addEventListener('DOMContentLoaded', async () => {
    const employeeNameSelect = document.getElementById('employeeName');
    const form = document.getElementById('attendanceForm');

    try {
        const token = await new Promise((resolve, reject) => {
            if (typeof chrome === 'undefined' || !chrome.identity) {
                reject(new Error('Chrome identity API not available.'));
            }
            chrome.identity.getAuthToken({ interactive: false }, function (token) {
                if (chrome.runtime.lastError || !token) {
                    reject(new Error(`Failed to get auth token: ${chrome.runtime.lastError?.message || 'Unknown error'}`));
                } else {
                    resolve(token);
                }
            });
        });
        console.log('Obtained auth token for initial load.');

        // Load stored username and check permission
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            chrome.storage.local.get("username", async (userResult) => {
                const username = userResult.username?.toUpperCase();
                if (username) {
                    console.log('Loaded stored username:', username);

                    // Check user permission (department from Credential sheet)
                    const department = await userPermission(username, token);
                    if (department) {
                        console.log(`User department permission: ${department}`);
                        // Store permitted departments for use in submitAttendance
                        window.permittedDepartments = department;
                        // Populate dropdown with employees from the permitted department(s)
                        await populateEmployeeDropdown(token, department);

                        // If username exists in the filtered dropdown, select it
                        if (employeeNameSelect.querySelector(`option[value="${username}"]`)) {
                            employeeNameSelect.value = username;
                            console.log('Set dropdown to stored username:', username);
                            await loadAttendanceData(username, token);
                        } else {
                            console.warn(`Username "${username}" not found in filtered dropdown for department "${department}".`);
                            alert(`⚠️ Your username "${username}" does not match any employee in the allowed department(s): ${department}.`);
                            employeeNameSelect.disabled = true;
                            if (form) form.style.display = 'none';
                            console.log('Access restricted: Username not in allowed department.');
                        }
                    } else {
                        console.warn(`No department found for username "${username}" or permission check failed.`);
                        alert('⚠️ Permission check failed. Username not found or no department assigned in Credential sheet.');
                        employeeNameSelect.disabled = true;
                        if (form) form.style.display = 'none';
                        console.log('Access restricted due to permission check failure.');
                    }
                } else {
                    console.log('No stored username. Populating dropdown with all employees.');
                    await populateEmployeeDropdown(token); // No department filter if no username
                    employeeNameSelect.value = ''; // Default to placeholder
                }
            });
        } else {
            console.warn('Chrome storage API not available. Please ensure this is running in a Chrome extension.');
            await populateEmployeeDropdown(token); // No department filter
            employeeNameSelect.value = ''; // Default to placeholder
        }

        // Load attendance data when username changes (no permission check)
        employeeNameSelect.addEventListener('change', async () => {
            const employeeName = employeeNameSelect.value;
            console.log('Dropdown changed to:', employeeName);
            if (employeeName) {
                try {
                    const token = await new Promise((resolve, reject) => {
                        if (typeof chrome === 'undefined' || !chrome.identity) {
                            reject(new Error('Chrome identity API not available.'));
                        }
                        chrome.identity.getAuthToken({ interactive: true }, function (token) {
                            if (chrome.runtime.lastError || !token) {
                                reject(new Error(`Failed to get auth token: ${chrome.runtime.lastError?.message || 'Unknown error'}`));
                            } else {
                                resolve(token);
                            }
                        });
                    });
                    console.log('Obtained auth token for dropdown change.');
                    await loadAttendanceData(employeeName, token);
                } catch (error) {
                    console.error('Error loading attendance data on dropdown change:', error);
                    alert('⚠️ Failed to load attendance data. Check console for details.');
                }
            }
        });

        // Explicitly attach form submit handler
        if (form) {
            form.addEventListener('submit', (event) => {
                event.preventDefault();
                event.stopPropagation();
                console.log('Form submitted.');
                submitAttendance();
            });
        } else {
            console.error('Form with ID "attendanceForm" not found.');
        }

    } catch (error) {
        console.error('Error initializing page:', error);
        alert('⚠️ Failed to initialize page. Check console for details.');
    }
});

async function submitAttendance() {
    try {
        const employeeName = document.getElementById('employeeName').value.trim();
        console.log('Submitting attendance for:', employeeName);
        if (!employeeName) {
            alert('⚠️ Please select an employee name.');
            console.error('Employee name is not selected.');
            return;
        }

        // Use stored permitted departments
        const department = window.permittedDepartments;
        if (!department) {
            alert('⚠️ Permission check failed. No department permissions available.');
            console.log('Submission blocked due to missing permitted departments.');
            return;
        }
        console.log(`User department permission: ${department}`);

        // Get auth token
        const token = await new Promise((resolve, reject) => {
            if (typeof chrome === 'undefined' || !chrome.identity) {
                reject(new Error('Chrome identity API not available.'));
            }
            chrome.identity.getAuthToken({ interactive: true }, function (token) {
                if (chrome.runtime.lastError || !token) {
                    reject(new Error(`Failed to get auth token: ${chrome.runtime.lastError?.message || 'Unknown error'}`));
                } else {
                    resolve(token);
                }
            });
        });
        console.log('Obtained auth token for submission.');

        // Verify the employee is in the permitted department(s)
        const employeeDepartmentResponse = await fetchWithRetry(
            `https://sheets.googleapis.com/v4/spreadsheets/1d1psGkKv5DSNSmzymXQYkM5MeW3oAtTvLdhm3_ZSXmU/values/AGENTS_MISSING_DATA!A2:C`,
            {
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        if (!employeeDepartmentResponse.ok) {
            const errorData = await employeeDepartmentResponse.json();
            console.error('Error fetching employee departments:', errorData);
            throw new Error(`Failed to fetch employee data: ${errorData.error?.message || 'Unknown error'}`);
        }

        const employeeData = await employeeDepartmentResponse.json();
        const employees = employeeData.values ? employeeData.values.map(row => ({
            name: row[0] ? row[0].trim().toUpperCase() : '',
            department: row[2] ? row[2].trim() : ''
        })).filter(employee => employee.name) : [];

        const allowedDepartments = department.split(',').map(dep => dep.trim().toLowerCase());
        const selectedEmployee = employees.find(emp => emp.name.toLowerCase() === employeeName.toLowerCase());
        if (!selectedEmployee || !selectedEmployee.department || !allowedDepartments.includes(selectedEmployee.department.toLowerCase())) {
            alert(`⚠️ You do not have permission to submit attendance for "${employeeName}" (department: ${selectedEmployee?.department || 'none'}). Allowed department(s): ${department}.`);
            console.log('Submission blocked: Selected employee not in allowed department.');
            return;
        }

        // Collect attendance data from the form
        const attendanceData = [];
        for (let i = 1; i <= 31; i++) {
            const checkIn = document.querySelector(`input[name="checkIn_${i}"]`)?.value;
            const checkOut = document.querySelector(`input[name="checkOut_${i}"]`)?.value;
            if (checkIn || checkOut) {
                attendanceData.push({
                    date: `08-${i.toString().padStart(2, '0')}-2025`,
                    checkIn: checkIn || 'N/A',
                    checkOut: checkOut || 'N/A'
                });
            }
        }

        console.log('Collected attendance data:', attendanceData);

        if (attendanceData.length === 0) {
            alert('⚠️ Please fill in at least one check-in or check-out time.');
            console.error('No attendance data provided.');
            return;
        }

        const sheetId = '1jwe1EKtnkKQVTZ84ONRRWU9WNg26C0M5i10F25FD0u0';
        const sheetName = 'Sheet1';

        // Fetch row 1 (A1:AFW1) to find the username column
        const headerResponse = await fetchWithRetry(
            `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!A1:AFW1`,
            {
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        if (!headerResponse.ok) {
            const errorData = await headerResponse.json();
            console.error('Header fetch response error:', errorData);
            throw new Error(`Failed to fetch row 1 from Google Sheet: ${errorData.error?.message || 'Unknown error'}`);
        }

        const headerData = await headerResponse.json();
        const headerValues = headerData.values ? headerData.values[0] : [];
        console.log('Fetched headers from row 1 (A1:AFW1):', headerValues);
        console.log('Trimmed headers:', headerValues.map(val => val ? val.trim() : ''));

        // Find the column index of the username (case-insensitive)
        const usernameColumnIndex = headerValues.findIndex(val => val && val.trim().toLowerCase() === employeeName.toLowerCase());
        if (usernameColumnIndex === -1) {
            console.error('Username not found in row 1 (A1:AFW1):', employeeName);
            alert(`⚠️ Username "${employeeName}" not found in row 1 of the Google Sheet (A1:AFW1).`);
            return;
        }

        // Determine check-in and check-out columns (e.g., OU → OV, OW)
        const checkInColumn = getColumnLetter(usernameColumnIndex + 1);
        const checkOutColumn = getColumnLetter(usernameColumnIndex + 2);
        console.log(`Username found in column ${getColumnLetter(usernameColumnIndex)} (index ${usernameColumnIndex}). Using ${checkInColumn} for check-in, ${checkOutColumn} for check-out.`);

        // Fetch dates from column B starting from row 5
        const fetchResponse = await fetchWithRetry(
            `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!B5:B35`,
            {
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        if (!fetchResponse.ok) {
            const errorData = await fetchResponse.json();
            console.error('Fetch response error:', errorData);
            throw new Error(`Failed to fetch dates from Google Sheet: ${errorData.error?.message || 'Unknown error'}`);
        }

        const sheetData = await fetchResponse.json();
        const sheetDates = sheetData.values ? sheetData.values.flat().map(date => date.trim()) : [];
        console.log('Fetched dates from column B (B5:B35):', sheetDates);
        console.log('Number of dates fetched:', sheetDates.length);

        // Use form dates directly (MM-DD-YYYY)
        console.log('Form dates (MM-DD-YYYY):', attendanceData.map(entry => entry.date));

        // Match form dates with sheet dates and prepare updates
        const updates = [];
        attendanceData.forEach(entry => {
            const rowIndex = sheetDates.findIndex(sheetDate => {
                const isMatch = sheetDate === entry.date;
                console.log(`Comparing form date "${entry.date}" with sheet date "${sheetDate}": ${isMatch}`);
                return isMatch;
            });
            if (rowIndex !== -1) {
                const rowNumber = 5 + rowIndex; // Start from row 5
                updates.push({
                    range: `${sheetName}!${checkInColumn}${rowNumber}:${checkOutColumn}${rowNumber}`,
                    values: [[to12HourFormat(entry.checkIn), to12HourFormat(entry.checkOut)]]
                });
            }
        });

        console.log('Prepared updates:', updates);

        if (updates.length === 0) {
            console.error('No matching dates found. Sheet dates:', sheetDates, 'Form dates:', attendanceData.map(entry => entry.date));
            alert('⚠️ No matching dates found in column B of the Google Sheet. Check console for details.');
            return;
        }

        // Batch update the Google Sheet
        const batchUpdateResponse = await fetchWithRetry(
            `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values:batchUpdate`,
            {
                method: 'POST',
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    valueInputOption: 'RAW',
                    data: updates
                })
            }
        );

        if (!batchUpdateResponse.ok) {
            const errorData = await batchUpdateResponse.json();
            console.error('Batch update response error:', errorData);
            throw new Error(`Failed to update attendance data: ${errorData.error?.message || 'Unknown error'}`);
        }

        // Success message
        let message = `✅ Attendance recorded for ${employeeName} in Google Sheet:\n\n`;
        attendanceData.forEach(entry => {
            message += `Date: ${entry.date}\nCheck-In: ${to12HourFormat(entry.checkIn)}\nCheck-Out: ${to12HourFormat(entry.checkOut)}\n\n`;
        });
        alert(message);
        console.log('Attendance data successfully uploaded:', updates);

        // Reset form fields except employeeName and reload data
        const form = document.getElementById('attendanceForm');
        const inputs = form.querySelectorAll('input[type="time"]');
        inputs.forEach(input => input.value = '');
        console.log('Cleared form inputs after submission.');
        await loadAttendanceData(employeeName, token);

    } catch (error) {
        console.error('⚠️ Error in submitAttendance:', error);
        alert(`Error: ${error.message || 'An unexpected error occurred while uploading to Google Sheets. Check console for details.'}`);
    }
}
