   function disableConsoleLog() {
    console.log = function() {};
}

document.getElementById('changePasswordText').addEventListener('click', function () {
  window.open('change-password.html', '_blank');
});

document.getElementById('issueTicketText').addEventListener('click', function () {
  window.open('Form/issueTicketText.html', '_blank');
});


// Call disableConsoleLog() to disable console logging

document.addEventListener("DOMContentLoaded", () => {
    chrome.storage.local.get(['sheetId', 'sheetId2', 'sheetId3'], (result) => {
        // Check if any of the sheet IDs are missing
        if (!result.sheetId || !result.sheetId2 || !result.sheetId3) {
            // Close the popup
            window.close();

            // Open the specified link in a new tab
            openLinkInNewTab();
        } else {
            console.log("✅ Sheet IDs already exist. Popup will remain open.");
        }
    });
});

function openLinkInNewTab() {
    const url = "https://www.aslpreservationsolutions.com/";
    chrome.tabs.create({ url: url }, (tab) => {
        console.log("📂 New tab opened with the link:", url);
    });
}

    document.getElementById("toggle-password").addEventListener("mousedown", function () {
        const passwordField = document.getElementById("password");
        const icon = this;
        const statusTextArea = document.getElementById("statusTextArea");

        // Check if the user is already logged in
        if (!localStorage.getItem("password")) {
            passwordField.type = "text";  // Show the password
            icon.innerHTML = "&#128065;"; // Open eye icon
                   } else {
            statusTextArea.value = "You can't view your password while logged in.";
        }
    });


document.addEventListener('DOMContentLoaded', function () {
  const historyButton = document.getElementById('historyButton');
  
  if (historyButton) {
    historyButton.addEventListener('click', function () {
      window.open('history.html', '_blank');
	          
    });
  }
});


document.getElementById("toggle-password").addEventListener("mouseup", function () {
    const passwordField = document.getElementById("password");
    const icon = this;

    passwordField.type = "password";  // Hide the password
    icon.innerHTML = "&#128064;"; // Change the icon (closed eye)
});

document.getElementById("toggle-password").addEventListener("mouseleave", function () {
    const passwordField = document.getElementById("password");
    const icon = this;

    passwordField.type = "password";  // Hide the password if the mouse leaves
    icon.innerHTML = "&#128064;"; // Change the icon (closed eye)
});

 
 
 // Function to apply stored mode and background color
  function applyStoredMode() {
    var mode = localStorage.getItem('mode');
    var darkModeIcon = document.getElementById('darkModeIcon');
    var body = document.body;

    // Default to light mode if mode is not found in localStorage
    if (!mode) {
      mode = 'light';
      localStorage.setItem('mode', 'light');
    }

    if (mode === 'light') {
      darkModeIcon.classList.remove('fa-sun');
      darkModeIcon.classList.add('fa-moon');
      body.style.backgroundColor = 'blue'; // Set body background color to default (light) mode
    } else {
      darkModeIcon.classList.remove('fa-moon');
      darkModeIcon.classList.add('fa-sun');
      body.style.backgroundColor = 'black'; // Set body background color to dark mode
    }
  }

  // Function to toggle dark mode
  function toggleDarkMode() {
    var darkModeIcon = document.getElementById('darkModeIcon');
    var body = document.body;
    var mode = localStorage.getItem('mode');

    if (mode === 'light') {
      darkModeIcon.classList.remove('fa-moon');
      darkModeIcon.classList.add('fa-sun');
      body.style.backgroundColor = 'black'; // Set body background color to dark mode
      localStorage.setItem('mode', 'dark');
    } else {
      darkModeIcon.classList.remove('fa-sun');
      darkModeIcon.classList.add('fa-moon');
      body.style.backgroundColor = 'blue'; // Set body background color to default (light) mode
      localStorage.setItem('mode', 'light');
    }
  }

  var darkModeButton = document.getElementById('darkModeButton');
  darkModeButton.addEventListener('click', toggleDarkMode);

  // Apply stored mode and background color when the DOM content is fully loaded
  document.addEventListener('DOMContentLoaded', applyStoredMode);

document.addEventListener("DOMContentLoaded", function () {
disableConsoleLog();
// Define a global variable to hold the welcome message and version
let globalWelcomeMessage = null;
let globalVersion = null;
const expectedVersion = "6.0"; // Define the expected version

function getWelcomeMessage() {
    return new Promise((resolve, reject) => {
        chrome.identity.getAuthToken({ interactive: true }, function (token) {
            if (chrome.runtime.lastError || !token) {
                reject(new Error("Failed to get auth token."));
                statusTextArea.value = "Failed to get auth token.";
                return;
            }

            chrome.storage.local.get(["sheetId"], function (result) {
                if (chrome.runtime.lastError || !result.sheetId) {
                    reject(new Error("Sheet ID not found in Chrome storage."));
                    statusTextArea.value = "Sheet ID not found in storage.";
                    return;
                }

                const sheetId = result.sheetId;
                const sheetName = "Credential";

                fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!G2?key=${googleSheetsApiKey}`, {
                    method: "GET",
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data && data.values && data.values.length > 0 && data.values[0].length > 0) {
                        const cellValue = data.values[0][0];
                        console.log("Data from cell G2:", cellValue);
                        
                        const parts = cellValue.split(",");
                        
                        if (parts.length === 2) {
                            const welcomeMsg = parts[0].trim();
                            globalVersion = parts[1].replace('version=', '').trim();

                            console.log("Parsed Welcome Message:", welcomeMsg);
                            console.log("Parsed Version:", globalVersion);

                            // Check version
                            if (globalVersion !== expectedVersion) {
                                globalWelcomeMessage = `Extension Update Required! Your current version is ${expectedVersion}. Please update to version ${globalVersion}.`;
                                statusTextArea.value = globalWelcomeMessage;
								  showUpdateDialog();
                            } else {
                                globalWelcomeMessage = welcomeMsg;
								
                                //statusTextArea.value = "System is up to date!";
								
                            }

                            resolve(globalWelcomeMessage);
                        } else {
                            reject(new Error("Invalid format of data in G2."));
                        }
                    } else {
                        reject(new Error("No data found in cell G2."));
                    }
                })
                .catch(error => {
                    reject(error);
                    console.error("Error:", error);
                });
            });
        });
    });
}



chrome.identity.getAuthToken({ interactive: true }, function(token) {
  if (chrome.runtime.lastError || !token) {
    showErrorSolutionDialog();
    return;
  }
  // Use token...
});


let dialog; // Global so we can remove it later

function showErrorSolutionDialog() {
    dialog = document.createElement('div');
    dialog.style.position = 'fixed';
    dialog.style.top = '44%';
    dialog.style.left = '103px';
    dialog.style.transform = 'translate(-50%, -50%)';
    dialog.style.backgroundColor = '#fff';
    dialog.style.padding = '10px 9px';
    dialog.style.boxShadow = '0 0 15px rgba(0,0,0,0.3)';
    dialog.style.zIndex = '10000';
    dialog.style.borderRadius = '10px';
    dialog.style.textAlign = 'center';
    dialog.style.width = '126px';
    dialog.style.height = '13.4vh';
    dialog.style.overflowY = 'auto';

    dialog.innerHTML = `
        <h3 style="margin-top: 0;">Having Trouble?</h3>
        <button id="userGuideBtn" style="
            display: inline-block;
            padding: 08px 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        ">User Guideline</button>
    `;

    document.body.appendChild(dialog);

    document.getElementById('userGuideBtn').addEventListener('click', () => {
        window.open('User_Guideline.html');
    });
}

function removeErrorSolutionDialog() {
    if (dialog && dialog.parentNode) {
        dialog.parentNode.removeChild(dialog);
        dialog = null; // Clear the reference
    }
}



function showUpdateDialog() {
    const dialog = document.createElement('div');
    dialog.style.position = 'fixed';
    dialog.style.top = '41%';
    dialog.style.left = '50%';
    dialog.style.transform = 'translate(-50%, -50%)';
    dialog.style.backgroundColor = '#fff';
    dialog.style.padding = '20px';
    dialog.style.boxShadow = '0 0 15px rgba(0,0,0,0.3)';
    dialog.style.zIndex = '10000';
    dialog.style.borderRadius = '10px';
    dialog.style.textAlign = 'center';
    dialog.style.width = '300px';

dialog.innerHTML = `
    <h3>Update Required</h3>
    <p>Your current version is <strong>${expectedVersion}</strong>.</p>
    <p>Please update to version <strong>${globalVersion}</strong>.</p>
    <a href="https://www.youtube.com/watch?v=wfGbFOPpeDA" target="_blank" style="
        display: inline-block;
        margin-top: 10px;
        padding: 10px 15px;
        background-color: #007bff;
        color: white;
        text-decoration: none;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    ">How To Update</a>
`;


    document.body.appendChild(dialog);

    document.getElementById('updateNowBtn').addEventListener('click', () => {
        // Redirect to your extension's update page or Chrome Web Store
        window.open('https://www.youtube.com/watch?v=wfGbFOPpeDA', '_blank');
        dialog.remove();
    });
}

async function initializeWelcomeMessage() {
    try {
        globalWelcomeMessage = await getWelcomeMessage();
        console.log("Global Welcome Message:", globalWelcomeMessage);
    } catch (error) {
        console.error("Error fetching welcome message:", error);
    }
}

// Call the initialization function
initializeWelcomeMessage();
getagentsmissedstat();

// Function to use the global welcome message
function useGlobalWelcomeMessage() {
    if (globalWelcomeMessage !== null) {
        console.log("Using Global Welcome Message:", globalWelcomeMessage);
        // Use as needed
    } else {
        console.log("Global Welcome Message is not yet initialized.");
    }
}

async function initializeWelcomeMessage() {
    try {
        globalWelcomeMessage = await getWelcomeMessage();
        console.log("Global Welcome Message:", globalWelcomeMessage);
    } catch (error) {
        console.error("Error fetching welcome message:", error);
    }
}

// Call the initialization function to set the global variable
initializeWelcomeMessage();
getagentsmissedstat();

// Function to get the global welcome message (for demonstration purposes)
function useGlobalWelcomeMessage() {
    if (globalWelcomeMessage !== null) {
        console.log("Using Global Welcome Message:", globalWelcomeMessage);
        // Use the globalWelcomeMessage as needed in your application
    } else {
        console.log("Global Welcome Message is not yet initialized.");
    }
}

   function disableConsoleLog() {
    console.log = function() {};
}
function checkCredentials() {
  var savedUsername = localStorage.getItem("username");
  var savedPassword = localStorage.getItem("password");
  

  if (!savedUsername || !savedPassword) {
    statusTextArea.value = "Enter your credential and start your work today !";
	showErrorSolutionDialog();
	
  }else {
    statusTextArea.value = "Credential Found. Trying to connect with server!";
    
   
}
}


  var scrapedData = [];
  
  var checkInButton = document.getElementById("checkInButton");
    var checkOutButton = document.getElementById("checkOutButton");
	  var breakStartButton = document.getElementById("breakStartButton");
    var breakEndButton = document.getElementById("breakEndButton");
	    var totalWorkHour = document.getElementById("totalWorkHour");
		var totalBreakHour = document.getElementById("totalBreakTime");
  var statusTextArea = document.getElementById("statusTextArea");
  var saveLoginInfoButton = document.getElementById("saveLoginInfoButton");
  var logoutButton = document.getElementById("logoutButton");
  document.getElementById("statusTextArea").readOnly = true;
  document.getElementById("totalWorkHour").readOnly = true;
   document.getElementById("totalBreakTime").readOnly = true;

  // Event listener for the "Save Login Information" button


   // Disable the button initially
    checkInButton.disabled = true;
    checkOutButton.disabled = true;
	breakStartButton.disabled = true;
  breakEndButton.disabled = true;
 // Check if "username" and "password" items exist in localStorage
if (localStorage.getItem("username") && localStorage.getItem("password")) {
    logoutButton.disabled = false; // Enable the logout button
} else {
    logoutButton.disabled = true; // Disable the logout button
}

checkCredentials();
    // Chain the functions
	
	
	
getLastWorkingDay()
    .then(savedsheetname => {
        checkInButton.disabled = false;
        checkOutButton.disabled = false;
        breakStartButton.disabled = false;
        breakEndButton.disabled = false;

        // Proceed with the next steps after enabling buttons
        RunningBreaktime(savedsheetname);
        showStopWorkTimeInTotalWorkHourElement();
		
        
        // Log the saved sheet name if needed
        console.log('Saved Sheet Name:', savedsheetname);
    })
    .catch(error => {
        console.error('Error:', error);
    });

      


    
// Function to clear input fields
function clearInputFields() {
	
    document.getElementById("username").value = "";
    document.getElementById("password").value = "";
    document.getElementById("totalBreakTime").value = "0:00 Hour";
    document.getElementById("totalWorkHour").value = "0:00 Hour";
}

// Add event listener for the logout button
logoutButton.addEventListener("click", function () {
  // Remove username and password from localStorage
  localStorage.removeItem("username");
  localStorage.removeItem("password");
  
  // Clear the input fields
  clearInputFields();
  
  // Update status textarea with the message
  statusTextArea.value = "Successfully logged out";
  


chrome.storage.local.remove('username', () => {
    if (chrome.runtime.lastError) {
        console.error("Error removing username from Chrome storage:", chrome.runtime.lastError);
    } else {
        console.log("Username has been removed from Chrome storage.");
    }
});



});

  // Retrieve saved username and password from local storage and populate input fields
  var savedUsername = localStorage.getItem("username");
  var savedPassword = localStorage.getItem("password");
 
  
  if (savedUsername && savedPassword) {
    document.getElementById("username").value = savedUsername;
    document.getElementById("password").value = savedPassword;
  }
 //const sheetId = "1cbMItqKhHSDRCv54TXsv_gjMS-jsFn2vbtAE0NnEk8Y"; // Google Sheets ID
  const googleSheetsApiKey = "AIzaSyDIuRc7QsUTJ8C5-0yzXeY9bM79-jxyTFY";



// Add event listener to the username and password fields to trigger login on Enter key press
document.getElementById("username").addEventListener("keydown", function(event) {
    if (event.key === "Enter") {
        saveLoginInfoButton.click(); // Simulate click on login button when Enter is pressed
    }
});

document.getElementById("password").addEventListener("keydown", function(event) {
    if (event.key === "Enter") {
        saveLoginInfoButton.click(); // Simulate click on login button when Enter is pressed
    }
});

	 
	function getAgentGmail() {
    return new Promise((resolve, reject) => {
        chrome.identity.getAuthToken({ interactive: true }, function (token) {
            if (!token) {
                reject(new Error("Failed to get auth token."));
                return;
            }

            chrome.storage.local.get(['sheetId'], (result) => {
                const sheetId = result.sheetId;

                if (!sheetId) {
                    reject(new Error("Sheet ID not found in chrome.storage.local."));
                    return;
                }

                const savedUsername = document.getElementById("username").value.trim().toUpperCase();

                if (!savedUsername) {
                    reject(new Error("Saved username not found in input."));
                    return;
                }

                const sheetName = "Credential";

                fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!A:F?key=${googleSheetsApiKey}`, {
                    method: "GET",
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                })
                .then(response => response.json())
                .then(data => {
                    const foundUsername = data.values.find(row => row[0]?.trim().toUpperCase() === savedUsername);

                    if (foundUsername) {
                        const savedGmailFromSheet = foundUsername[5]?.trim().toLowerCase();
                        console.log("📄 Gmail from sheet:", savedGmailFromSheet);

                        fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
                            headers: {
                                Authorization: `Bearer ${token}`
                            }
                        })
                        .then(response => response.json())
                        .then(userInfo => {
                            const currentGmail = userInfo.email?.trim().toLowerCase();
                            console.log("🔐 Current Gmail:", currentGmail);

                            if (currentGmail === savedGmailFromSheet || savedGmailFromSheet === "unlinked") {
                                console.log("✅ Gmail matches with the one in the sheet or is marked as unlinked.");
                                resolve(currentGmail);
                            } else {
                                console.log("❌ Gmail does not match.");
                                reject(new Error("You are using a unauthorised Google account."));
                            }
                        })
                        .catch(error => {
                            console.error("⚠️ Error fetching current Gmail:", error);
                            reject(error);
                        });

                    } else {
                        console.log("❌ Username not found in column A.");
                        reject(new Error("Username not found in the spreadsheet."));
                    }
                })
                .catch(error => {
                    console.error("⚠️ Error fetching sheet data:", error);
                    reject(error);
                });
            });
        });
    });
}
 
	 
	 
	 
	 
	 
	 
	 
saveLoginInfoButton.addEventListener("click", function () {
	 statusTextArea.value = "Checking Please Wait......";
    chrome.storage.local.get("sheetId", function (result) {
        const sheetId = result.sheetId;

        if (!sheetId) {
            console.error("Sheet ID not found in Chrome storage.");
            statusTextArea.value = "Sheet ID not found. Please set it in extension settings.";
            return;
        }

        const savedUsername = document.getElementById("username").value.trim().toUpperCase();
        const savedPassword = document.getElementById("password").value.trim();

        if (!savedUsername || !savedPassword) {
            console.error("Username or password not found. Upload failed.");
            statusTextArea.value = "Username or password not found. Upload failed.";
            return;
        }

        // Step 1: Check Gmail match
        getAgentGmail()
            .then(currentGmail => {
                // Step 2: Get Auth token and validate credentials
                chrome.identity.getAuthToken({ interactive: true }, function (token) {
                    fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/Credential!A:B?key=${googleSheetsApiKey}`, {
                        headers: {
                            Authorization: `Bearer ${token}`
                        }
                    })
                        .then((response) => response.json())
                        .then((response) => {
                            const fetchedData = response.values || [];
                            const fetchedUsernames = fetchedData.map(row => row[0]);
                            const fetchedPasswords = fetchedData.map(row => row[1]);

                            const usernameIndex = fetchedUsernames.findIndex(username =>
                                username && username.trim() === savedUsername.trim()
                            );

                            if (usernameIndex !== -1) {
                                if (fetchedPasswords[usernameIndex] === savedPassword) {
                                    console.log("✅ Username-password combination matched.");

                                    // Continue with rest of the login process
                                    fetchOnlineTime()
                                        .then(onlineTime => {
                                            localStorage.setItem("username", savedUsername);
                                            localStorage.setItem("password", savedPassword);

                                            chrome.storage.local.set({ username: savedUsername }, () => {
                                                if (chrome.runtime.lastError) {
                                                    console.error("Error saving username to Chrome storage:", chrome.runtime.lastError);
                                                } else {
                                                    console.log("Username saved to Chrome storage:", savedUsername);
                                                }
                                            });

                                            getLastWorkingDay()
                                                .then(savedsheetname => {
                                                    RunningBreaktime(savedsheetname);
                                                    showStopWorkTimeInTotalWorkHourElement();
                                                    removeErrorSolutionDialog();
                                                    checkInButton.disabled = false;
                                                    checkOutButton.disabled = false;
                                                    breakStartButton.disabled = false;
                                                    breakEndButton.disabled = false;
                                                })
                                                .catch(error => {
                                                    console.error("Error during post-login operations:", error);
                                                });

                                            statusTextArea.value = "Login information saved successfully!";
                                            logoutButton.disabled = false;
                                        })
                                        .catch(error => {
                                            console.error("Error fetching online time:", error);
                                            statusTextArea.value = "Error fetching online time. Upload failed!";
                                        });
                                } else {
                                    console.log("❌ Password mismatch.");
                                    statusTextArea.value = "Password is incorrect.";
                                }
                            } else {
                                console.log("❌ Username not found.");
                                statusTextArea.value = "Username not found. Upload failed.";
                            }
                        })
                        .catch((error) => {
                            console.error("Error retrieving credentials:", error);
                            statusTextArea.value = "Error retrieving credentials. Upload failed.";
                        });
                });
            })
            .catch(error => {
                console.error("Gmail mismatch or error:", error);
                statusTextArea.value = error.message || "Unauthorized Gmail account.";
            });
    });
});




function AgentLastWorkingDay(callback) {
    chrome.identity.getAuthToken({ interactive: true }, async function (token) {
        try {
            const savedUsername = localStorage.getItem("username");
            if (!savedUsername) {
                throw new Error("Saved username not found in storage.");
            }

            // Get sheetId from chrome.storage.local
            const sheetId = await new Promise((resolve, reject) => {
                chrome.storage.local.get(["sheetId"], (result) => {
                    if (chrome.runtime.lastError || !result.sheetId) {
                        reject(new Error("Sheet ID not found in chrome.storage.local."));
                    } else {
                        resolve(result.sheetId);
                    }
                });
            });

            const sheetName = "Credential";

            const fetchResponse = await fetch(
                `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!A:C?key=${googleSheetsApiKey}`,
                {
                    method: "GET",
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }
            );

            const data = await fetchResponse.json();
            console.log("Username found in column A. Data:", data);

            const columnAData = data.values ? data.values.map(row => row[0]) : [];
            const usernameIndex = columnAData.findIndex(value => value === savedUsername);

            if (usernameIndex === -1) {
                throw new Error(`Username '${savedUsername}' not found.`);
            }

            console.log(`Username '${savedUsername}' found at row ${usernameIndex + 1}.`);

            const rowData = [
                localStorage.getItem('formattedDate')
            ];

            const rowIndex = usernameIndex;
            const range = `${sheetName}!C${rowIndex + 1}`;
            const payload = {
                values: [rowData],
            };

            const updateResponse = await fetch(
                `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${range}?valueInputOption=RAW&key=${googleSheetsApiKey}`,
                {
                    method: "PUT",
                    headers: {
                        Authorization: `Bearer ${token}`,
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify(payload),
                }
            );

            const jsonResponse = await updateResponse.json();
            console.log("Data uploaded to Google Sheets:", jsonResponse);

            if (callback) {
                callback();
            }

        } catch (error) {
            console.error("Error:", error);
        }
    });
}





let missedstat = "";

function getagentsmissedstat() {
    return new Promise((resolve, reject) => {
        chrome.identity.getAuthToken({ interactive: true }, async function (token) {
            try {
                // Fetch the saved username from storage
                const savedUsername = localStorage.getItem("username");
                if (!savedUsername) {
                    reject(new Error("Saved username not found in storage."));
                    return;
                }

                // Get sheetId from chrome.storage.local
                const sheetId = await new Promise((resolveSheetId, rejectSheetId) => {
                    chrome.storage.local.get(["sheetId"], (result) => {
                        if (chrome.runtime.lastError || !result.sheetId) {
                            rejectSheetId(new Error("Sheet ID not found in chrome.storage.local."));
                        } else {
                            resolveSheetId(result.sheetId);
                        }
                    });
                });

                // Set the sheet name to "Credential"
                const sheetName = "Credential";

                // Fetch the data from A to D columns
                const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!A:D?key=${googleSheetsApiKey}`, {
                    method: "GET",
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });

                const data = await response.json();

                console.log("Last working status", localStorage.getItem("localsheetname"));

                // Search for saved username in column A
                const foundUsername = data.values.find(row => row[0] === savedUsername);

                if (foundUsername) {
                    console.log("Username found in column A. Data:", foundUsername);

                    // Extract IP or status data from column D (index 3)
                    const missedstat = foundUsername[3];
                    console.log("IP,s:", missedstat);

                    // Resolve the promise with the value
                    resolve(missedstat);
                } else {
                    console.log("Username not found in column A.");
                    reject(new Error("Username not found in the spreadsheet."));
                }
            } catch (error) {
                console.error("Error fetching IP:", error);
                reject(error);
            }
        });
    });
}









let laststate = "";
let lastcheckintime = "";

function getLastAgentStatus() {
    return new Promise((resolve, reject) => {
        chrome.identity.getAuthToken({ interactive: true }, async function (token) {
            try {
                // Fetch the saved username from localStorage
                const savedUsername = localStorage.getItem("username");
                if (!savedUsername) {
                    reject(new Error("Saved username not found in storage."));
                    return;
                }

                // Get sheetId from chrome.storage.local
                const sheetId = await new Promise((resolveSheetId, rejectSheetId) => {
                    chrome.storage.local.get(["sheetId"], (result) => {
                        if (chrome.runtime.lastError || !result.sheetId) {
                            rejectSheetId(new Error("Sheet ID not found in chrome.storage.local."));
                        } else {
                            resolveSheetId(result.sheetId);
                        }
                    });
                });

                // Sheet name
                const sheetName = "Credential";

                // Fetch data from columns A to K
                const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!A:K?key=${googleSheetsApiKey}`, {
                    method: "GET",
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });

                const data = await response.json();

                // Log fetched data
                console.log("Last working day data:", localStorage.getItem("localsheetname"));

                // Search for saved username in column A
                const foundUsername = data.values.find(row => row[0] === savedUsername);

                if (foundUsername) {
                    console.log("Username found in column A. Data:", foundUsername);

                    // Extract last state from column I (index 8)
                    const laststate = foundUsername[8] || "";
                    console.log("Last state:", laststate);

                    // Extract last check-in time from column J (index 10)
                    const lastcheckintime = foundUsername[10] || "";
                    console.log("Last check-in time:", lastcheckintime);

                    resolve({ laststate, lastcheckintime });
                } else {
                    console.log("Username not found in column A.");
                    reject(new Error("Username not found in the spreadsheet."));
                }
            } catch (error) {
                console.error("Error fetching state:", error);
                reject(error);
            }
        });
    });
}





let savedip = "";

function getagentsip() {
    return new Promise((resolve, reject) => {
        chrome.identity.getAuthToken({ interactive: true }, function (token) {
            // Get sheetId from chrome storage
            chrome.storage.local.get(['sheetId'], (result) => {
                const sheetId = result.sheetId;

                if (!sheetId) {
                    reject(new Error("Sheet ID not found in chrome.storage.local."));
                    return;
                }

                // Get saved username from local storage
                const savedUsername = localStorage.getItem("username");
                if (!savedUsername) {
                    reject(new Error("Saved username not found in storage."));
                    return;
                }

                const sheetName = "Credential";

                fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!A:D?key=${googleSheetsApiKey}`, {
                    method: "GET",
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                })
                .then(response => response.json())
                .then(data => {
                    console.log("Last working day data:", localStorage.getItem("localsheetname"));

                    const foundUsername = data.values.find(row => row[0] === savedUsername);

                    if (foundUsername) {
                        console.log("Username found in column A. Data:", foundUsername);
                        console.log("IP,s:", foundUsername[3]);
                        const savedip = foundUsername[3];
                        resolve(savedip);
                    } else {
                        console.log("Username not found in column A.");
                        reject(new Error("Username not found in the spreadsheet."));
                    }
                })
                .catch(error => {
                    console.error("Error fetching IP:", error);
                    reject(error);
                });
            });
        });
    });
}





async function compareIP(action) {
    try {
        // Reference to the statusTextArea (Make sure this is correctly referenced in your code)
        const statusTextArea = document.getElementById('statusTextArea'); // Adjust the selector as needed

        // Check if the action requires IP address comparison
        if (action === 'Check-in' || action === 'Check-out') {
            // Fetch the saved IP addresses from the Google Sheet
            const savedIPsString = await getagentsip();
            // Convert the comma-separated string into an array
            const savedIPs = savedIPsString.split(',').map(ip => ip.trim());

            // Check if "WFH" is present in the saved IPs array
            if (savedIPs.includes("WFH")) {
                // If "WFH" is present, allow the action to be performed from any IP
                await performAction(action);
                statusTextArea.value = 'Work From Home condition met. Action performed from any IP.';
            } else {
                // Fetch the IP address from ipinfo.io
                const response = await fetch('https://ipinfo.io/json');
                const data = await response.json();
                const fetchedIP = data.ip;

                // Log both IP addresses for comparison
                console.log('Fetched IP Address:', fetchedIP);
                console.log('Saved IP Addresses:', savedIPs);

                // Check if the fetched IP address is in the array of saved IP addresses
                if (savedIPs.includes(fetchedIP)) {
                    // If it matches, perform the action
                    await performAction(action);
                    statusTextArea.value = 'IP address matches. Action performed. Please Wait !';
                } else {
                    // If it does not match, show status in statusTextArea
                    statusTextArea.value = `Please disconnect your VPN.                                                           Your IP ${fetchedIP} is not authorized.`;
                }
            }
        } else {
            // For actions that don't require IP check, directly perform the action
            await performAction(action);
        }
    } catch (error) {
        console.error('Error comparing IP addresses or performing action:', error);
        // Show error status in statusTextArea
        statusTextArea.value = 'Error occurred: ' + error.message;
    }
}




async function performAction(action) {
    switch (action) {
        case "Check-in":
		
		
		
		
		var usernameInput = document.getElementById("username").value;	
    // Check if username and password inputs are not empty
if (usernameInput) {
  // Save username and password to localStorage
     // Save username to chrome.storage.local as well
  chrome.storage.local.set({ username: usernameInput.trim() }, () => {
    if (chrome.runtime.lastError) {
      console.error("Error saving username to Chrome storage:", chrome.runtime.lastError);
    } else {
      console.log("Username saved to Chrome storage:", usernameInput.trim());
    }
  });

 
}		
		
		
		
            await checkLastStateAndUpload(action);
            break;
        case "Check-out":
            await checkLastCheckInStateAndUpload(action);
            break;
        case "Break-Start":
		
	var usernameInput = document.getElementById("username").value;	
    // Check if username and password inputs are not empty
if (usernameInput) {
  // Save username and password to localStorage
     // Save username to chrome.storage.local as well
  chrome.storage.local.set({ username: usernameInput.trim() }, () => {
    if (chrome.runtime.lastError) {
      console.error("Error saving username to Chrome storage:", chrome.runtime.lastError);
    } else {
      console.log("Username saved to Chrome storage:", usernameInput.trim());
    }
  });

 
}		
	
		
            await checkLastCheckInOrBreakStartStateAndUpload(action);
            break;
        case "Break-End":
            await checkLastBreakStartStateAndUpload(action);
            clearInterval(interval); // Stop the timer
            interval = null; // Reset the interval variable
            TotalBreakTimeADay(); // Call TotalBreakTimeADay() function
            break;
    }
}



let savedsheetname = "";


function getLastWorkingDay() {
    return new Promise((resolve, reject) => {
        chrome.identity.getAuthToken({ interactive: true }, function (token) {
            // Get the saved sheetId from chrome.storage.local
            chrome.storage.local.get(['sheetId'], (result) => {
                const sheetId = result.sheetId;

                if (!sheetId) {
                    reject(new Error("Sheet ID not found in chrome.storage.local."));
                    return;
                }

                // Fetch the saved username from localStorage
                const savedUsername = localStorage.getItem("username");
                if (!savedUsername) {
                    reject(new Error("Saved username not found in storage."));
                    return;
                }

                const sheetName = "Credential";

                fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!A:C?key=${googleSheetsApiKey}`, {
                    method: "GET",
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                })
                .then(response => response.json())
                .then(data => {
                    console.log("Last working day data:", localStorage.getItem("localsheetname"));

                    const foundUsername = data.values.find(row => row[0] === savedUsername);

                    if (foundUsername) {
                        console.log("Username found in column A. Data:", foundUsername);
                        console.log("Date:", foundUsername[2]);
                        savedsheetname = foundUsername[2];
                        resolve(savedsheetname);
                    } else {
                        console.log("Username not found in column A.");
                        reject(new Error("Username not found in column A."));
                    }
                })
                .catch(error => {
                    reject(error);
                    console.error("Error:", error);
                    statusTextArea.value = "Failed to connect. Check your internet connection.";
					  showErrorSolutionDialog();
                });
            });
        });
    });
}




async function RunningBreaktime(savedsheetname) {
    try {
        const savedUsername = localStorage.getItem("username");
        if (!savedUsername) throw new Error("Saved username not found in storage.");
        console.log(savedsheetname);

        const sheetName = savedsheetname;

        // Get the auth token
        const token = await new Promise((resolve, reject) => {
            chrome.identity.getAuthToken({ interactive: true }, function (token) {
                if (chrome.runtime.lastError || !token) {
                    reject(new Error('Failed to get auth token.'));
                } else {
                    resolve(token);
                }
            });
        });

        // Get sheetId from chrome storage
        const sheetId = await new Promise((resolve, reject) => {
            chrome.storage.local.get(['sheetId'], (result) => {
                if (chrome.runtime.lastError || !result.sheetId) {
                    reject(new Error("Sheet ID not found in chrome.storage.local."));
                } else {
                    resolve(result.sheetId);
                }
            });
        });

        const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}?key=${googleSheetsApiKey}`, {
            method: "GET",
            headers: {
                Authorization: `Bearer ${token}`
            }
        });

        if (!response.ok) throw new Error("Failed to fetch data from Google Sheets.");
        const data = await response.json();

        const headerRow = data.values?.[0] || [];
        const usernameColumnIndex = headerRow.findIndex(cellValue => cellValue === savedUsername);

        if (usernameColumnIndex === -1) throw new Error(`Column for username '${savedUsername}' not found.`);

        const matchedColumnData = data.values.slice(1)
            .map(row => row[usernameColumnIndex])
            .filter(value => value !== undefined && ["Check-in", "Check-out", "Break-Start", "Break-End"].includes(value));

        let lastState = null;
        let lastBreakStartTime = null;

        matchedColumnData.forEach((_, rowIndex) => {
            const state = data.values[rowIndex + 1][usernameColumnIndex];
            if (state === "Break-Start") {
                lastBreakStartTime = data.values[rowIndex + 1][usernameColumnIndex + 1]; // Assumes time is next to "Break-Start"
            }
            lastState = state;
        });

        const currentUnixTime = await fetchOnlineTime(); // Should return a timestamp
        localStorage.setItem("fatchedonlinetimefromweb", currentUnixTime);
        console.log("Current Unix Time:", currentUnixTime);

        if (lastBreakStartTime && lastState === "Break-Start") {
            const timeDifferenceInSeconds = currentUnixTime - lastBreakStartTime;

            if (timeDifferenceInSeconds > 0) {
                const totalWorkHourInput = document.getElementById("totalBreakTime");
                startTimer(totalWorkHourInput, timeDifferenceInSeconds);

                chrome.action.setBadgeBackgroundColor({ color: 'red' });
                chrome.action.setBadgeTextColor({ color: 'white' });
                chrome.runtime.sendMessage({ action: "updateBadge", text: "Break" });
            } else {
                console.log("Current time is earlier than last Break-Start time.");
            }
        } else {
            chrome.runtime.sendMessage({ action: "updateBadge", text: "" });
            TotalBreakTimeADay();
        }

        console.log("Last Break-Start time (Unix):", lastBreakStartTime);
        console.log("Current Time (Unix):", currentUnixTime);
    } catch (error) {
        console.error("Error in RunningBreaktime:", error.message);
    }
}


// Function to start the timer
function startTimer(totalWorkHourInput, timeDifferenceInSeconds) {
    let totalSeconds = timeDifferenceInSeconds;
    interval = setInterval(() => {
        const hoursLeft = Math.floor(totalSeconds / 3600);
        const minutesLeft = Math.floor((totalSeconds % 3600) / 60);
        const secondsLeft = totalSeconds % 60;
        totalWorkHourInput.value = `${hoursLeft.toString().padStart(2, '0')}:${minutesLeft.toString().padStart(2, '0')}:${secondsLeft.toString().padStart(2, '0')}`;
        totalSeconds++;
    }, 1000);
}




async function checkAndRun() {
    try {
        const { lastcheckintime } = await getLastAgentStatus(); // Get last check-in time from sheet

        // Check if lastcheckintime is undefined, null, or invalid
        if (!lastcheckintime || isNaN(lastcheckintime)) {
            statusTextArea.value = "Last check-in approach was not successful.                           Please try again.";
            document.getElementById("totalWorkHour").value = "Unsuccessful";
            checkOutButton.disabled = true;
            breakStartButton.disabled = true;
            breakEndButton.disabled = true;
            return;
        }

        const onlineTime = await fetchOnlineTime(); // Get current time from API (Unix time in seconds)
        const timeDifference = onlineTime - lastcheckintime; // Compare in seconds

        // Format both timestamps for display
        const lastCheckInFormatted = new Date(lastcheckintime * 1000).toLocaleString();
        const currentTimeFormatted = new Date(onlineTime * 1000).toLocaleString();

        console.log("🔁 Last Check-in:", lastCheckInFormatted);
        console.log("🌐 Online Time:", currentTimeFormatted);
        console.log("⏱️ Time Difference (s):", timeDifference);

        if (timeDifference > 54000) { // more than 15 hours
            document.getElementById("totalWorkHour").value = "Missed";
            checkOutButton.disabled = true;
            breakStartButton.disabled = true;
            breakEndButton.disabled = true;
            statusTextArea.value = "Last day you have missed your Check out. Status forwarded to your teamlead.";
        } else {
            Runningworktime(); // Time is within limit
        }
    } catch (error) {
        console.error("❌ Error in checkAndRun:", error);
        statusTextArea.value = "Error checking attendance status.";
    }
}




function showStopWorkTimeInTotalWorkHourElement() {
    chrome.identity.getAuthToken({ interactive: true }, function (token) {
        let timeoutId; // For the 3-second countdown
        removeErrorSolutionDialog(); // Remove any old dialog first
 document.getElementById("totalWorkHour").value = "Loading...";
 document.getElementById("totalBreakTime").value = "Loading...";
        statusTextArea.value = "Please wait, your system is loading...."; // Show loading message

        // Start a 3-second countdown to show the dialog if not fetched yet
        timeoutId = setTimeout(() => {
            showErrorSolutionDialog();
        }, 3000);

        const savedUsername = localStorage.getItem("username");
        if (!savedUsername) {
            console.error("Saved username not found in storage.");
            clearTimeout(timeoutId);
            return;
        }

        const sheetName = savedsheetname;  // Assuming `savedsheetname` is defined elsewhere
        console.log("Sheet name:", sheetName);

        chrome.storage.local.get(["sheetId"], function (result) {
            const sheetId = result.sheetId;
            if (!sheetId) {
                console.error("Sheet ID not found in Chrome storage.");
                statusTextArea.value = "Sheet ID not found.";
                clearTimeout(timeoutId);
                return;
            }

            fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}?key=${googleSheetsApiKey}`, {
                method: "GET",
                headers: {
                    Authorization: `Bearer ${token}`
                }
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error("Failed to fetch data from Google Sheet API.");
                    }
                    return response.json();
                })
                .then(data => {
                    clearTimeout(timeoutId); // Cancel timeout once data is received
                    removeErrorSolutionDialog(); // Remove the dialog if it was shown

                    const headerRow = data.values && data.values.length > 0 ? data.values[0] : [];
                    const usernameColumnIndex = headerRow.findIndex(cellValue => cellValue === savedUsername);

                    if (usernameColumnIndex === -1) {
                        throw new Error(`Column for username '${savedUsername}' not found.`);
                    }

                    const matchedColumnData = data.values.map(row => row[usernameColumnIndex]).filter(value => value !== undefined);
                    const filteredData = matchedColumnData.filter(value => value === "Check-in" || value === "Check-out");

                    const lastState = filteredData[filteredData.length - 1];
                    if (lastState !== "Check-out") {
                        checkAndRun();
                        return;
                    }

                    const lastCheckOutIndex = data.values.findIndex(row => row[usernameColumnIndex] === "Check-out");
                    const lastCheckOutTime = data.values[lastCheckOutIndex][usernameColumnIndex + 2];

                    document.getElementById("totalWorkHour").value = "Checked out";
                    statusTextArea.value = "Last session you worked " + lastCheckOutTime + " hours. Great job!";
                })
                .catch(error => {
                    clearTimeout(timeoutId); // Cancel timeout on error too
                    console.error("Error:", error.message);
                   statusTextArea.value = globalWelcomeMessage;
			        document.getElementById("totalWorkHour").value = "Pls Check-in";
			        document.getElementById("totalBreakTime").value = "Pls Check-in";
                    //showErrorSolutionDialog();
                });
        });
    });
}







// Event listener for the check-in button
checkInButton.addEventListener("click", async function () {
    const action = "Check-in"; // Set the action to "Check-in"

    // Disable the button
    checkInButton.disabled = true;

    try {
        // Compare IP addresses and perform action if IPs match
        await compareIP(action);
    } catch (error) {
        console.error("Error:", error);
    } finally {
        // Re-enable the button after 5 seconds
        setTimeout(() => {
            checkInButton.disabled = false;
        }, 5000); // 5000 milliseconds = 5 seconds
    }
});

async function checkForCheckIn(action) {
    try {
        // Get the last check-in time from storage or sheet
        const { lastcheckintime } = await getLastAgentStatus(); // Unix timestamp in seconds

        // Get current time (Unix timestamp in seconds)
        const onlineTime = await fetchOnlineTime();

        // Calculate the difference in seconds
        const timeDifference = onlineTime - lastcheckintime;

        // Convert timestamps to readable format
        const lastCheckInFormatted = new Date(lastcheckintime * 1000).toLocaleString();
        const currentTimeFormatted = new Date(onlineTime * 1000).toLocaleString();
        const lastCheckInUTC = new Date(lastcheckintime * 1000).toUTCString();
        const currentUTC = new Date(onlineTime * 1000).toUTCString();

        // Debug logs
        console.log("🔁 Last Check-in (Local):", lastCheckInFormatted);
        console.log("🌐 Online Time (Local):", currentTimeFormatted);
        console.log("🕓 Last Check-in (UTC):", lastCheckInUTC);
        console.log("🕓 Online Time (UTC):", currentUTC);
        console.log("⏱️ Time Difference (s):", timeDifference);

        // If more than 15 hours passed (54000 seconds), allow check-in
        if (timeDifference > 54000) {
            console.log("✅ More than 15 hours passed. Proceeding with check-in...");
            AgentLastWorkingDay(() => {
                uploadAction(action);
            });
        } else {
            // Otherwise, not eligible
            const statusTextArea = document.getElementById("statusTextArea");
            if (statusTextArea) {
                statusTextArea.value = "You are not eligible for check-in now.";
            }
            console.warn("⛔ Not eligible for check-in. Less than 15 hours passed.");
        }

    } catch (error) {
        console.error("❌ Error in checkForCheckIn:", error);
        const statusTextArea = document.getElementById("statusTextArea");
        if (statusTextArea) {
            statusTextArea.value = "Error checking check-in status.";
        }
    }
}







let isProcessingCheckState = false; // Flag to track if the function is already processing

function checkLastStateAndUpload(action) {
    if (isProcessingCheckState) {
        statusTextArea.value = "Another process is already in progress. Please wait...";
        return;
    }

    isProcessingCheckState = true;

    chrome.identity.getAuthToken({ interactive: true }, function (token) {
        const savedUsername = localStorage.getItem("username");
        if (!savedUsername) {
            throw new Error("Saved username not found in storage.");
        }

        const sheetNamecheckin = localStorage.getItem("formattedDate");

        // Fetch the sheetId from chrome.storage.local
        chrome.storage.local.get(["sheetId"], function (result) {
            const sheetId = result.sheetId;
            if (!sheetId) {
                console.error("Sheet ID not found in Chrome storage.");
                statusTextArea.value = "Sheet ID not found.";
                isProcessingCheckState = false;
                return;
            }

            fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetNamecheckin}?key=${googleSheetsApiKey}`, {
                method: "GET",
                headers: {
                    Authorization: `Bearer ${token}`
                }
            })
                .then(response => response.json())
                .then(data => {
                    const headerRow = data.values && data.values.length > 0 ? data.values[0] : [];
                    const usernameColumnIndex = headerRow.findIndex(cellValue => cellValue === savedUsername);

                    if (usernameColumnIndex === -1) {
                        statusTextArea.value = `Column for username '${savedUsername}' not found.`;
						  // Remove username and password from localStorage
                              localStorage.removeItem("username");
                               localStorage.removeItem("password");
  
                                   // Clear the input fields
                                   clearInputFields();

                                      chrome.storage.local.remove('username', () => {
                                         if (chrome.runtime.lastError) {
                                             console.error("Error removing username from Chrome storage:", chrome.runtime.lastError);
                                              } else {
                                            console.log("Username has been removed from Chrome storage.");
                                               }
                                           });

                        throw new Error(`Column for username '${savedUsername}' not found.`);
                    }

                    const matchedColumnData = data.values.map(row => row[usernameColumnIndex]).filter(value => value !== undefined);
                    console.log("Matched Column Data:", matchedColumnData);

                    const filteredStates = matchedColumnData.filter(state => state === "Check-in" || state === "Check-out");

                    if (filteredStates.length === 0) {
checkForCheckIn(action);

                    } else if (filteredStates[filteredStates.length - 1] === "Check-out") {
                        statusTextArea.value = `Failed '${action}'. You Already checked out today.`;
                        console.log(`Cannot upload '${action}'. Last state is 'check-out' or there is no previous state.`);
                        getLastWorkingDay()
                            .then(savedsheetname => {
                                setTimeout(() => {
                                    checkInButton.disabled = false;
                                    checkOutButton.disabled = false;
                                    breakStartButton.disabled = false;
                                    breakEndButton.disabled = false;

                                    RunningBreaktime(savedsheetname);
                                    showStopWorkTimeInTotalWorkHourElement();
                                }, 10000);
                            });

                    } else if (filteredStates[filteredStates.length - 1] === "Check-in") {
                        statusTextArea.value = `Failed '${action}'. Your last session is not finished or there is already check-in today.`;
                        console.log(`Cannot upload '${action}'. Last state is 'Check-in'.`);
                        getLastWorkingDay()
                            .then(savedsheetname => {
                                setTimeout(() => {
                                    checkInButton.disabled = false;
                                    checkOutButton.disabled = false;
                                    breakStartButton.disabled = false;
                                    breakEndButton.disabled = false;

                                    RunningBreaktime(savedsheetname);
                                    showStopWorkTimeInTotalWorkHourElement();
                                }, 10000);
                            });

                    } else {
checkForCheckIn(action);
                    }
                })
                .catch(error => {
                    console.error("Error checking last state:", error);
                })
                .finally(() => {
                    setTimeout(function () {
                        isProcessingCheckState = false;
                    }, 3000);
                });
        });
    });
}






// Event listener for the checkout button
checkOutButton.addEventListener("click", async function () {

    const action = "Check-out"; // Set the action to "Check-out"
    try {
        // Compare IP addresses and perform action if IPs match
        await compareIP(action);
    } catch (error) {
        console.error("Error:", error);
    }

});


async function checkLastCheckInStateAndUpload(action, callback) {
    if (isProcessing) {
        console.log("Another process is already in progress. Please wait...");
        statusTextArea.value = "Another process is already in progress. Please wait...";
        return;
    }

    isProcessing = true;

    chrome.identity.getAuthToken({ interactive: true }, async function (token) {
        try {
            const savedUsername = localStorage.getItem("username");
            if (!savedUsername) throw new Error("Saved username not found in storage.");

            // Get sheetId from chrome.storage.local
            const sheetId = await new Promise((resolve, reject) => {
                chrome.storage.local.get(["sheetId"], (result) => {
                    if (chrome.runtime.lastError || !result.sheetId) {
                        reject(new Error("Sheet ID not found in chrome.storage.local."));
                    } else {
                        resolve(result.sheetId);
                    }
                });
            });

            const sheetName = savedsheetname;

            const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}?key=${googleSheetsApiKey}`, {
                method: "GET",
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });

            const data = await response.json();
            const headerRow = data.values?.[0] || [];
            const usernameColumnIndex = headerRow.findIndex(cell => cell === savedUsername);

            if (usernameColumnIndex === -1) throw new Error(`Column for username '${savedUsername}' not found.`);

            const matchedColumnData = data.values.slice(1).map(row => row[usernameColumnIndex]);
            const filteredStates = matchedColumnData.filter(val => ["Check-in", "Check-out", "Break-Start", "Break-End"].includes(val));
            const lastCellValue = filteredStates[filteredStates.length - 1];

            if (!lastCellValue || lastCellValue === "Check-out" || lastCellValue === "Break-Start") {
                console.log("Last state is 'Check-out' or 'Break-Start', action not uploaded.");
                statusTextArea.value = "Last state is 'Check-out' or 'Break-Start', action not uploaded.";

                getLastWorkingDay().then(savedsheetname => {
                    setTimeout(() => {
                        checkInButton.disabled = false;
                        checkOutButton.disabled = false;
                        breakStartButton.disabled = false;
                        breakEndButton.disabled = false;

                        RunningBreaktime(savedsheetname);
                        showStopWorkTimeInTotalWorkHourElement();
                    }, 5000);
                });

                return;
            }

            // If all checks pass, upload action
            uploadAction(action);

            if (typeof callback === "function") callback();

        } catch (error) {
            console.error("Error checking last check-in state:", error);
            statusTextArea.value = "Error: " + error.message;
        } finally {
            setTimeout(() => {
                isProcessing = false;
            }, 3000);
        }
    });
}




 

function TotalBreakTimeADay() {
    chrome.identity.getAuthToken({ interactive: true }, function (token) {
        // Fetch the saved username from localStorage
        const savedUsername = localStorage.getItem("username");
        if (!savedUsername) {
            throw new Error("Saved username not found in storage.");
        }

        // Get the sheet ID from chrome.storage.local
        chrome.storage.local.get("sheetId", function (result) {
            const sheetId = result.sheetId;
            if (!sheetId) {
                console.error("Sheet ID not found in chrome.storage.");
                return;
            }

            // Get today's sheet name
            const sheetName = savedsheetname;

            // Fetch all data from the sheet
            fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}?key=${googleSheetsApiKey}`, {
                method: "GET",
                headers: {
                    Authorization: `Bearer ${token}`
                }
            })
            .then(response => response.json())
            .then(data => {
                const headerRow = data.values && data.values.length > 0 ? data.values[0] : [];

                const usernameColumnIndex = headerRow.findIndex(cellValue => cellValue === savedUsername);
                if (usernameColumnIndex === -1) {
                    throw new Error(`Column for username '${savedUsername}' not found.`);
                }

                const matchedColumnData = data.values.slice(1).map(row => row[usernameColumnIndex]).filter(value => value !== undefined);

                let totalTimestamps = 0;
                let lastState = null;
                let breakStartTimestamp = null;
                let lastBreakStartTime = null;

                matchedColumnData.forEach((_, rowIndex) => {
                    const row = data.values[rowIndex + 1];
                    const timestamp = row[usernameColumnIndex + 3]; // Timestamp
                    const actualTime = row[usernameColumnIndex + 1]; // Actual time
                    const state = row[usernameColumnIndex];         // State

                    if (timestamp !== undefined && timestamp.trim() !== "") {
                        const [hours, minutes, seconds] = timestamp.split(':').map(Number);
                        const timestampMilliseconds = ((hours * 60 + minutes) * 60 + seconds) * 1000;
                        totalTimestamps += timestampMilliseconds;

                        if (lastState === "Break-Start") {
                            const currentTime = new Date().getTime();
                            const breakTimeElapsed = currentTime - breakStartTimestamp;
                        }

                        lastState = state;

                        if (state === "Break-Start") {
                            lastBreakStartTime = actualTime;
                            breakStartTimestamp = new Date().getTime();
                        }
                    } else if (state === "Break-Start") {
                        lastBreakStartTime = actualTime;
                    }
                });

                const totalHours = Math.floor(totalTimestamps / (1000 * 60 * 60));
                const totalMinutes = Math.floor((totalTimestamps % (1000 * 60 * 60)) / (1000 * 60));
                const totalSeconds = Math.floor((totalTimestamps % (1000 * 60)) / 1000);

                document.getElementById("totalBreakTime").value =
                    `${totalHours.toString().padStart(2, '0')}:${totalMinutes.toString().padStart(2, '0')}:${totalSeconds.toString().padStart(2, '0')}`;

                console.log("Last Break-Start time:", lastBreakStartTime);
            })
            .catch(error => {
                console.error("Error checking last check-in state:", error);
            });
        });
    });
}


let timerInterval;


function Runningworktime() {
    chrome.identity.getAuthToken({ interactive: true }, function (token) {
        statusTextArea.value = globalWelcomeMessage;

        const savedUsername = localStorage.getItem("username");
        if (!savedUsername) {
            console.error("Saved username not found in storage.");
            return;
        }

        // Fetch sheetId from chrome storage
        chrome.storage.local.get("sheetId", function (result) {
            const sheetId = result.sheetId;
            if (!sheetId) {
                console.error("Sheet ID not found in Chrome storage.");
                return;
            }

            const sheetName = savedsheetname;
            console.log("Sheet name:", sheetName);

            fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}?key=${googleSheetsApiKey}`, {
                method: "GET",
                headers: {
                    Authorization: `Bearer ${token}`
                }
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error("Failed to fetch data from Google Sheet API.");
                    }
                    return response.json();
                })
                .then(data => {
                    const headerRow = data.values && data.values.length > 0 ? data.values[0] : [];
                    const usernameColumnIndex = headerRow.findIndex(cellValue => cellValue === savedUsername);
                    if (usernameColumnIndex === -1) {
                        throw new Error(`Column for username '${savedUsername}' not found.`);
                    }

                    const matchedColumnData = data.values.map(row => row[usernameColumnIndex]).filter(value => value !== undefined);
                    const lastCheckInIndex = matchedColumnData.lastIndexOf("Check-in");
                    const lastCheckInUnixTime = lastCheckInIndex !== -1 ? data.values[lastCheckInIndex][usernameColumnIndex + 1] : null;

                    if (!lastCheckInUnixTime) {
                        document.getElementById("totalWorkHour").value = "Pls Check-in";
                        return;
                    }

                    const currentTimeString = localStorage.getItem("fatchedonlinetimefromweb");
                    if (!currentTimeString) {
                        console.error("Current time not found in localStorage.");
                        return;
                    }

                    const lastCheckInDateTime = new Date(lastCheckInUnixTime * 1000);
                    const currentDateTime = new Date(currentTimeString * 1000);
                    let timeDifferenceMillis = currentDateTime - lastCheckInDateTime;

                    const updateTimerDisplay = () => {
                        const hours = Math.floor(timeDifferenceMillis / (1000 * 60 * 60));
                        const minutes = Math.floor((timeDifferenceMillis % (1000 * 60 * 60)) / (1000 * 60));
                        const seconds = Math.floor((timeDifferenceMillis % (1000 * 60)) / 1000);
                        const formattedTimeDifference = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
                        document.getElementById("totalWorkHour").value = formattedTimeDifference;
                    };

                    const timerInterval = setInterval(() => {
                        updateTimerDisplay();
                        timeDifferenceMillis += 1000;
                    }, 1000);

                    ["checkInButton", "checkOutButton", "breakStartButton", "breakEndButton", "logoutButton", "saveLoginInfoButton"].forEach(buttonId => {
                        document.getElementById(buttonId).addEventListener("click", () => {
                            clearInterval(timerInterval);
                        });
                    });
                })
                .catch(error => {
                    console.error("Error:", error.message);
                    document.getElementById("statusTextArea").value = "User name not found. Please check..";
                });
        });
    });
}











// Event listener for the break start button
breakStartButton.addEventListener("click", async function () {
    const action = "Break-Start"; // Set the action to "Break-Start"

    try {
        // Compare IP addresses, date, and time and perform action if all match
        await compareIP(action);
    } catch (error) {
        console.error("Error:", error);
    } 
});


function checkLastCheckInOrBreakStartStateAndUpload(action, callback) {
    if (isProcessing) {
        console.log("Another process is already in progress. Please wait...");
        statusTextArea.value = "Another process is already in progress. Please wait...";
        return;
    }

    isProcessing = true;

    chrome.identity.getAuthToken({ interactive: true }, function (token) {
        const savedUsername = localStorage.getItem("username");
        if (!savedUsername) {
            throw new Error("Saved username not found in storage.");
        }

        const sheetName = savedsheetname;

        chrome.storage.local.get(["sheetId"], function (result) {
            const sheetId = result.sheetId;
            if (!sheetId) {
                statusTextArea.value = "Sheet ID not found in storage.";
                isProcessing = false;
                return;
            }

            fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}?key=${googleSheetsApiKey}`, {
                method: "GET",
                headers: {
                    Authorization: `Bearer ${token}`
                }
            })
            .then(response => response.json())
            .then(data => {
                const headerRow = data.values?.[0] || [];
                const usernameColumnIndex = headerRow.findIndex(cell => cell === savedUsername);

                if (usernameColumnIndex === -1) throw new Error(`Column for '${savedUsername}' not found.`);

                const matchedColumnData = data.values.map(row => row[usernameColumnIndex]).filter(Boolean);
                const filteredStates = matchedColumnData.filter(value =>
                    ["Check-in", "Check-out", "Break-Start", "Break-End"].includes(value)
                );

                const lastCellValue = filteredStates.at(-1);

                if (!lastCellValue || lastCellValue === "Check-out" || lastCellValue === "Break-Start") {
                    console.log("Last state is 'Check-out' or 'Break-Start', action not uploaded.");
                    statusTextArea.value = "Last state is 'Check-out' or 'Break-Start', action not uploaded.";
                    getLastWorkingDay().then(savedsheetname => {
                        setTimeout(() => {
                            checkInButton.disabled = false;
                            checkOutButton.disabled = false;
                            breakStartButton.disabled = false;
                            breakEndButton.disabled = false;
                            RunningBreaktime(savedsheetname);
                            showStopWorkTimeInTotalWorkHourElement();
                        }, 5000);
                    });
                    return;
                }

                uploadAction(action);
                if (typeof callback === "function") callback();
            })
            .catch(error => console.error("Error checking last check-in state:", error))
            .finally(() => {
                setTimeout(() => {
                    isProcessing = false;
                }, 3000);
            });
        });
    });
}




// Event listener for the break end button
breakEndButton.addEventListener("click", async function () {
    const action = "Break-End"; // Set the action to "Break-End"

    try {
        // Compare IP addresses, date, and time and perform action if all match
        await compareIP(action);
    } catch (error) {
        console.error("Error:", error);
    } finally {
        clearInterval(interval); // Stop the timer
        interval = null; // Reset the interval variable
        TotalBreakTimeADay(); // Call TotalBreakTimeADay() function
    }
});



let isProcessing = false; // Flag to track if the function is already processing

function checkLastBreakStartStateAndUpload(action, callback) {
    // If the function is already processing, show a message and return
    if (isProcessing) {
        if (statusTextArea) statusTextArea.value = "Another process is already in progress. Please wait...";
        return;
    }

    isProcessing = true;
    console.log("Button is disabled. Process is ongoing.");
    breakEndButton.disabled = true;

    chrome.identity.getAuthToken({ interactive: true }, function (token) {
        const savedUsername = localStorage.getItem("username");
        if (!savedUsername) {
            throw new Error("Saved username not found in storage.");
        }

        chrome.storage.local.get(["sheetId"], function (result) {
            const sheetId = result.sheetId;
            if (!sheetId) {
                console.error("Sheet ID not found in Chrome storage.");
                if (statusTextArea) statusTextArea.value = "Sheet ID is missing in storage.";
                isProcessing = false;
                breakEndButton.disabled = false;
                return;
            }

            const sheetName = savedsheetname;

            fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}?key=${googleSheetsApiKey}`, {
                method: "GET",
                headers: {
                    Authorization: `Bearer ${token}`
                }
            })
            .then(response => response.json())
            .then(data => {
                const headerRow = data.values && data.values.length > 0 ? data.values[0] : [];
                const usernameColumnIndex = headerRow.findIndex(cellValue => cellValue === savedUsername);

                if (usernameColumnIndex === -1) {
                    throw new Error(`Column for username '${savedUsername}' not found.`);
                }

                const matchedColumnData = data.values.map(row => row[usernameColumnIndex]).filter(value => value !== undefined);
                const filteredStates = matchedColumnData
                    .map(val => val.trim())
                    .filter(state =>
                        ["Check-in", "Check-out", "Break-Start", "Break-End"].includes(state)
                    );

                console.log("Filtered States:", filteredStates);

                if (filteredStates.length > 0 && filteredStates[filteredStates.length - 1] === "Break-Start") {
                    uploadAction(action);
                } else {
                    console.log("Last state is not 'Break-Start', action not uploaded.");
                    if (statusTextArea) statusTextArea.value = "Last state is not 'Break-Start', action not uploaded.";

                    setTimeout(() => {
                        checkInButton.disabled = false;
                        checkOutButton.disabled = false;
                        breakStartButton.disabled = false;
                        breakEndButton.disabled = false;

                        RunningBreaktime(savedsheetname);
                        showStopWorkTimeInTotalWorkHourElement();
                    }, 5000);
                }

                if (callback && typeof callback === "function") {
                    callback();
                }
            })
            .catch(error => {
                console.error("Error checking last break start state:", error);
            })
            .finally(() => {
                setTimeout(() => {
                    breakEndButton.disabled = false;
                    isProcessing = false;
                }, 10000);
            });
        });
    });
}




// Function to upload the action
async function uploadAction(action, seasonTime) { // Made async to await fetchOnlineTime()
    // Get the current tab's URL
    chrome.tabs.query({ active: true, currentWindow: true }, async function (tabs) { // Changed callback to async
        const currentTabUrl = tabs[0].url;
        console.log("Current Tab's URL:", currentTabUrl);

        // Update the existing textarea content
        statusTextArea.value = "Uploading " + action + "..."; // Show uploading status with the action
        console.log("Uploading " + action + "...");

        try {
            // Ensure fetchOnlineTime is called to set 'formattedDate' in localStorage
            // We don't need its return value here, just its side effect on localStorage
            await fetchOnlineTime();

            // Upload data to Google Sheets.
            // The sheetName argument can still be null as uploadToGoogleSheets will use localStorage.getItem("formattedDate")
            uploadToGoogleSheets([scrapedData[scrapedData.length - 1]], currentTabUrl, null, statusTextArea, action);
        } catch (error) {
            console.error("Error in uploadAction:", error);
            statusTextArea.value = "Failed to upload: " + error.message;
        }
    });
}

// Function to handle button action (check-in or check-out)
function handleButtonAction(action) {
    // Get the current tab's URL
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        const currentTabUrl = tabs[0].url;
        console.log("Current Tab's URL:", currentTabUrl);

        // Update the existing textarea content
        statusTextArea.value = "Uploading..."; // Show uploading status
        console.log("Uploading...");

        // Upload data to Google Sheets with the correct action
        uploadToGoogleSheets([scrapedData[scrapedData.length - 1]], currentTabUrl, getTodayDateString(), statusTextArea, action);
    });
}
// Function to toggle between Check-in and Check-out
function toggleAction() {
    currentAction = currentAction === "Check-in" ? "Check-out" : "Check-in";
}








async function fetchOnlineTime() {
    // Define the maximum number of retries
    const maxRetries = 10;
    const retryDelay = 5000; // 2 seconds

    // Array of API keys
    const apiKeys = ['MHLHX9SQS9OS', 'J21IZJE6J4BO', 'Z9OWQ4H6VY06', 'T01OC6STNHSY','9CZH7ESKOGMA','XQ1504UMC00R'];

    // Function to fetch data with a timeout
    const fetchWithTimeout = async (url, timeout) => {
        return Promise.race([
            fetch(url).then(response => response.json()),
            new Promise((_, reject) =>
                setTimeout(() => reject(new Error('Request timed out')), timeout)
            )
        ]);
    };

    let usedKeys = new Set(); // To keep track of used API keys

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            // Select a new API key for each attempt that hasn't been used
            let availableKeys = apiKeys.filter(key => !usedKeys.has(key));
            
            if (availableKeys.length === 0) {
                throw new Error('No available API keys left');
            }

            const randomKey = availableKeys[Math.floor(Math.random() * availableKeys.length)];
            usedKeys.add(randomKey);

            console.error(`Attempt ${attempt} - Using API Key: ${randomKey}`);

            // Get the current Unix timestamp
            const url = `https://api.timezonedb.com/v2.1/get-time-zone?key=${randomKey}&format=json&by=zone&zone=GMT`;

            // Fetch data from the API with a 2-second timeout
            const data = await fetchWithTimeout(url, retryDelay);

            // Save the fetched Unix timestamp in local storage
            localStorage.setItem('unixTimestamp', data.timestamp);
            console.log('Saved Unix Timestamp:', data.timestamp);

            // Convert Unix timestamp to Date object
            const gmtDateTime = new Date(data.timestamp * 1000);

            // Format the date as MM-DD-YYYY
            const formattedDate = `${String(gmtDateTime.getMonth() + 1).padStart(2, '0')}-${String(gmtDateTime.getDate()).padStart(2, '0')}-${gmtDateTime.getFullYear()}`;

            // Save the formatted date in local storage
            localStorage.setItem('formattedDate', formattedDate);

            // Format the time as HH:MM:SS
            const formattedTime = data.timestamp;

            console.log("Current Date (GMT):", formattedDate);
            console.log("Current Time (GMT):", formattedTime);

            return formattedTime;

        } catch (error) {
            console.error(`Attempt ${attempt} failed:`, error);
            statusTextArea.value = 'Please wait. Trying to calculating your time.';
            if (attempt === maxRetries) {
                statusTextArea.value = 'Server busy please try again';
            }

            await new Promise(resolve => setTimeout(resolve, retryDelay));
        }
    }
}









function uploadToGoogleSheets(data, tabUrl, sheetName, statusTextArea, action) {
    chrome.identity.getAuthToken({ interactive: true }, async function (token) {
        if (chrome.runtime.lastError) {
            console.error(chrome.runtime.lastError);
            statusTextArea.value = "Upload failed. Auth token not found. Restart your browser or your device.";
            return;
        }

        const sheetId = await new Promise((resolve) => {
            chrome.storage.local.get(['sheetId'], (result) => {
                resolve(result.sheetId || "");
            });
        });

        if (!sheetId) {
            console.error("Sheet ID not found in storage");
            statusTextArea.value = "Error: Google Sheet ID not configured";
            return;
        }

        const savedUsername = localStorage.getItem("username");
        const savedPassword = localStorage.getItem("password");

        if (!savedUsername || !savedPassword) {
            console.error("Username or password not found. Upload failed.");
            statusTextArea.value = "Username or password not found. Upload failed.";
            return;
        }

        fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/Credential!A:B?key=${googleSheetsApiKey}`, {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        })
        .then((response) => response.json())
        .then((response) => {
            const fetchedData = response.values || [];
            const fetchedUsernames = fetchedData.map(row => row[0]);
            const fetchedPasswords = fetchedData.map(row => row[1]);

            if (fetchedData.length > 0) {
                const usernameIndex = fetchedUsernames.findIndex(username => username?.trim() === savedUsername?.trim());
                if (usernameIndex !== -1 && fetchedPasswords[usernameIndex] === savedPassword) {
                    console.log("Username-password combination found. Proceeding with upload.");

                    fetchOnlineTime()
                        .then(onlineTime => {
                            console.log("Online Time:", onlineTime);
                            uploadDataToGoogleSheets(onlineTime, sheetId, token);
                        })
                        .catch(error => {
                            console.error("Error fetching online time:", error);
                            statusTextArea.value = "Error fetching online time.";
                        });
                } else {
                    console.log("Username or password is incorrect.");
                    statusTextArea.value = "Username or Password is incorrect.";
                }
            } else {
                console.error("Credential sheet is empty or not found.");
                statusTextArea.value = "Error retrieving credentials. Upload failed! Restart your browser may solve the issue.";
            }
        })
        .catch((error) => {
            console.error("Error retrieving credentials:", error);
            statusTextArea.value = "Error retrieving credentials. Upload failed! Restart your browser may solve the issue.";
        });

        async function uploadDataToGoogleSheets(onlineTime, sheetId, token) {
            if (!onlineTime) {
                statusTextArea.value = "Server error: Please try again.";
                return;
            }

            const savedUsername = localStorage.getItem("username");
            if (!savedUsername) {
                throw new Error("Saved username not found in storage.");
            }

            try {
                if (action === "Check-out") {
                    await chrome.storage.local.set({
                        activityUpload: 'turnoff',
                        activeTime: 0,
                        idleTime: 0
                    });
                    console.log('⏱️ Time tracking stopped');
                }

                if (action === "Check-in") {
                    await chrome.storage.local.set({
                        activeTime: 0,
                        activityUpload: 'turnon',
                        idleTime: 0
                    });
                    console.log('⏱️ Time counters reset');
                }

                const savedsheetname = await getLastWorkingDay();
                const effectiveSheetName = (action === "Check-in")
                    ? localStorage.getItem("formattedDate")
                    : savedsheetname;

                const response = await fetch(
                    `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${effectiveSheetName}?key=${googleSheetsApiKey}`,
                    { headers: { Authorization: `Bearer ${token}` } }
                );
                const data = await response.json();
                const headerRow = data.values?.[0] || [];
                const usernameColumnIndex = headerRow.findIndex(cell => cell === savedUsername);

                if (usernameColumnIndex === -1) {
                    throw new Error(`Column for '${savedUsername}' not found`);
                }

                let lastRowIndex = data.values.length;
                for (let i = data.values.length - 1; i >= 0; i--) {
                    if (data.values[i][usernameColumnIndex]?.trim()) {
                        lastRowIndex = i + 1;
                        break;
                    }
                }

                const rowData = [action, onlineTime];
                const range = getColumnRange(usernameColumnIndex, lastRowIndex + 1, effectiveSheetName);

                const uploadResponse = await fetch(
                    `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${range}?valueInputOption=RAW&key=${googleSheetsApiKey}`,
                    {
                        method: "PUT",
                        headers: {
                            Authorization: `Bearer ${token}`,
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({ values: [rowData] })
                    }
                );
                const result = await uploadResponse.json();
                console.log("Data uploaded:", result);

                await handlePostUploadActions(action);
            } catch (error) {
                console.error("Upload failed:", error);
                if (action === "Check-in") {
                    await chrome.storage.local.set({ activityUpload: 'turnon' });
                }
                throw error;
            }
        }

        function getColumnRange(columnIndex, row, sheetName) {
            let column = "";
            let index = columnIndex;
            while (index >= 0) {
                column = String.fromCharCode(65 + (index % 26)) + column;
                index = Math.floor(index / 26) - 1;
            }
            return `${sheetName}!${column}${row}`;
        }

        async function handlePostUploadActions(action) {
            const savedsheetname = await getLastWorkingDay();
            await RunningBreaktime(savedsheetname);
            await showStopWorkTimeInTotalWorkHourElement();

            const notifications = {
                "Check-in": { title: 'Check-in', message: 'Checked-in successfully!' },
                "Check-out": { title: 'Check-out', message: 'Checked-out successfully!' },
                "Break-Start": { title: 'Break-Start', message: 'Break started successfully!' },
                "Break-End": { title: 'Break-End', message: 'Break ended successfully!' }
            };

            if (notifications[action]) {
                chrome.runtime.sendMessage({
                    action: 'showNotification',
                    ...notifications[action]
                });
            }

            if (action === "Break-End") {
                clearInterval(interval);
                interval = null;
                statusTextArea.value = "Break time updated";
            }
        }
    });
}



});
