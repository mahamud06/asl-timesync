function disableConsoleLog() {
    console.log = function() {};
}
// Call disableConsoleLog() to disable console logging
disableConsoleLog();

(function() {
  // Enable console logging for debugging (disable in production)
  const isDev = true;
  const log = isDev ? console.log.bind(console) : () => {};

  // Load data from sessionStorage initially
  let employeeData = JSON.parse(sessionStorage.getItem('employeeData') || '{}');
  let { row, sheetRowIndex } = employeeData;

  // Define headers and indices (0-based)
  const headers = [
    "TimeSync Username", "Full Name", "DOB", "Employee ID", "Finger ID", "Finger name", "Joing date",
    "Department", "Shift", "Designation", "Contracted Day", "Contracted Hours", "Base Salary",
    "Duty Start", "OT status", "Paid Leave elegble", "Outstanding", "connection code",
    "Data export code", "NID number", "Birth certificate number", "Profile Pic", "Address",
    "Gmail", "Contact number", "Certificate image 1", "Certificate image 2", "Certificate image 3",
    "Certificate image 4", "Certificate image 5", "Employment Option", "Termination date", "Status", "Remark",
    "Father's Name", "Blood Group", "Emergency Contact Number",
    "Certificate image 6", "Certificate image 7", "Certificate image 8", "Certificate image 9",
    "Warning Letter 1", "Warning Letter 2", "Warning Letter 3", "Bank Account Number", "Provident Fund",
    "Conditional Bonus", "Unconditional Bonus"
  ];
  const indices = Array.from({ length: headers.length }, (_, i) => i);

  // Image fields
  const imageFields = [
    "Profile Pic", "Certificate image 1", "Certificate image 2", "Certificate image 3", "Certificate image 4", "Certificate image 5",
    "Certificate image 6", "Certificate image 7", "Certificate image 8", "Certificate image 9",
    "Warning Letter 1", "Warning Letter 2", "Warning Letter 3"
  ];
  const imageIndices = imageFields.map(field => headers.indexOf(field));

  // Date and time fields
  const dateFields = ["DOB", "Joing date", "Termination date"];
  const timeFields = ["Duty Start"];

  // Employment option
  const employmentOptions = ["Active", "Lay Off", "Resigned", "Terminated"];

  // Paid Leave eligible options
  const paidLeaveOptions = ["After 1 year", "After 3 month", "Immediate after join"];

  // Status options
  const statusOptions = [
    "Draft", "Pending", "Verified by Admin", "Verified by HR", "Verified by Manager", "Verified by CEO",
    "Verified by Teamlead", "Verified by Team Coordinator"
  ];

  // Allowed fields for update when status is Draft
  const allowedFields = [
    "Address", "NID number", "Birth certificate number", "Full Name", "DOB", "Blood Group",
    "Father's Name", "Emergency Contact Number", "Contact number", "Gmail", "Bank Account Number",
    "Profile Pic", "Certificate image 1", "Certificate image 2", "Certificate image 3", "Certificate image 4",
    "Certificate image 5", "Certificate image 6", "Certificate image 7", "Certificate image 8", "Certificate image 9"
  ];

  // Store image URLs in state
  const imageUrls = {};

  // Fetch data from Google Sheet for a specific range
  async function fetchFromSheet(token, range) {
    try {
      log(`Fetching data from Google Sheet for range ${range}`);
      const result = await new Promise((resolve) => {
        chrome.storage.local.get(['sheetId2'], (result) => {
          resolve(result);
        });
      });

      const sheetId = result.sheetId2;
      if (!sheetId) {
        throw new Error('Sheet ID not found in chrome.storage.local');
      }

      const response = await fetch(
        `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${range}`,
        {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        throw new Error(error.error?.message || `Failed to fetch data from sheet: ${response.status}`);
      }

      const data = await response.json();
      log('Data fetched from sheet:', data);
      return data.values || [];
    } catch (error) {
      log(`Error fetching data from sheet:`, error);
      throw error;
    }
  }

  // Find row index by username
  async function findRowByUsername(token, username) {
    try {
      const sheetName = 'Employee_Management';
      const range = `${sheetName}!A2:A`;
      const rows = await fetchFromSheet(token, range);
      for (let i = 0; i < rows.length; i++) {
        if (rows[i][0] === username) {
          return i + 2;
        }
      }
      return null;
    } catch (error) {
      log(`Error finding row by username:`, error);
      throw error;
    }
  }

  // Fetch row data by row index
  async function fetchRowByIndex(token, rowIndex) {
    const sheetName = 'Employee_Management';
    const range = `${sheetName}!A${rowIndex}:AV${rowIndex}`;
    const rows = await fetchFromSheet(token, range);
    const fetchedRow = rows[0] || Array(48).fill('');
    while (fetchedRow.length < 48) fetchedRow.push('');
    return fetchedRow;
  }

  // Initialize form with fetched data
  async function initializeForm() {
    try {
      const storage = await new Promise((resolve) => {
        chrome.storage.local.get(['username'], (result) => {
          resolve(result);
        });
      });

      const username = storage.username;
      if (!username) {
        throw new Error('Username not found in chrome.storage.local');
      }
      log('Username from chrome storage:', username);

      const token = await new Promise((resolve, reject) => {
        chrome.identity.getAuthToken({ interactive: true }, (token) => {
          if (chrome.runtime.lastError || !token) {
            reject(new Error(chrome.runtime.lastError?.message || "Authentication failed"));
          } else {
            resolve(token);
          }
        });
      });

      sheetRowIndex = await findRowByUsername(token, username);
      if (sheetRowIndex) {
        row = await fetchRowByIndex(token, sheetRowIndex);
        employeeData = { row, sheetRowIndex };
        sessionStorage.setItem('employeeData', JSON.stringify(employeeData));
        log('Fetched fresh row for username:', username, 'Row:', row);
      } else {
        log('No data found for username:', username);
      }
    } catch (error) {
      log('Failed to fetch data from sheet:', error);
      if (employeeData.row && employeeData.sheetRowIndex && row[0] === username) {
        log('Using data from sessionStorage as fallback for username:', username);
        row = employeeData.row;
        sheetRowIndex = employeeData.sheetRowIndex;
      } else {
        throw error;
      }
    }

    if (!row || !sheetRowIndex) {
      log('No employee data found for username, using fallback data');
      row = Array(48).fill('');
      sheetRowIndex = 1;
      document.getElementById('fieldsContainer').innerHTML = `
        <span class="text-center text-red-500 font-medium">No employee data found for your username. Showing empty form.</span>`;
    } else if (row.length !== 48) {
      log(`Data mismatch: row length (${row.length}) does not match headers (48)`);
      while (row.length < 48) row.push('');
    }

    imageIndices.forEach(i => {
      imageUrls[i] = row[i] || "";
    });

    renderForm();
  }

  // Time conversion helpers
  const parseTime = (timeStr) => {
    if (!timeStr) return '';
    const match = timeStr.match(/^(\d{1,2}):(\d{2})(?:\s*(AM|PM))?$/i);
    if (!match) {
      log(`Invalid time format: ${timeStr}`);
      return '';
    }
    let [_, hours, minutes, period] = match;
    hours = parseInt(hours, 10);
    if (period) {
      if (period.toUpperCase() === 'PM' && hours !== 12) hours += 12;
      if (period.toUpperCase() === 'AM' && hours === 12) hours = 0;
    }
    return `${hours.toString().padStart(2, '0')}:${minutes}`;
  };

  const formatTime = (timeStr) => {
    if (!timeStr) return '';
    const match = timeStr.match(/^(\d{1,2}):(\d{2})$/);
    if (!match) {
      log(`Invalid time format for output: ${timeStr}`);
      return '';
    }
    const [_, hours, minutes] = match;
    return `${hours.padStart(2, '0')}:${minutes}`;
  };

  // Date conversion helpers
  const parseMMDDYYYY = (dateStr) => {
    if (!dateStr) return '';
    const match = dateStr.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if (!match) {
      log(`Invalid date format: ${dateStr}`);
      return '';
    }
    const [_, month, day, year] = match;
    const paddedMonth = month.padStart(2, '0');
    const paddedDay = day.padStart(2, '0');
    return `${year}-${paddedMonth}-${paddedDay}`;
  };

  const formatToMMDDYYYY = (dateStr) => {
    if (!dateStr) return '';
    const match = dateStr.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!match) {
      if (dateStr.match(/^\d{1,2}\/\d{1,2}\/\d{4}$/)) return dateStr;
      log(`Invalid date format for output: ${dateStr}`);
      return '';
    }
    const [_, year, month, day] = match;
    return `${month}/${day}/${year}`;
  };

  // Generate header content
  const generateHeaderHTML = () => {
    const employeeId = row[headers.indexOf("Employee ID")] || "";
    const profilePic = imageUrls[headers.indexOf("Profile Pic")];
    const canUpdate = (row[headers.indexOf("Status")] || "Draft") === "Draft" && allowedFields.includes("Profile Pic");
    let headerHTML = `
      <div class="cv-header-info">
        <div class="cv-field">
          <label>Employee ID:</label>
          <input type="text" id="input-${headers.indexOf("Employee ID")}" value="${employeeId}" disabled>
        </div>
      </div>
      <div class="cv-header-pic">
    `;
    if (profilePic && profilePic.startsWith("http")) {
      const fileIdMatch = profilePic.match(/\/d\/([a-zA-Z0-9_-]{33})\/view/) || profilePic.match(/mock\/([a-zA-Z0-9_-]+)/);
      if (fileIdMatch && fileIdMatch[1]) {
        headerHTML += `
          <img src="https://drive.google.com/thumbnail?id=${fileIdMatch[1]}&sz=w80" 
               class="cv-profile-pic loading" 
               id="profile-pic-img">
        `;
      } else {
        headerHTML += `<span id="profile-pic-img">No image</span>`;
      }
    } else {
      headerHTML += `<span id="profile-pic-img">No image</span>`;
    }
    headerHTML += `
        <div class="cv-image-actions" id="profile-pic-actions">
          ${profilePic && profilePic.startsWith("http") && canUpdate
            ? `<button class="delete-btn" data-index="${headers.indexOf("Profile Pic")}">Delete</button>`
            : canUpdate ? `<input type="file" id="file-${headers.indexOf("Profile Pic")}" accept="image/*">` : ''}
        </div>
      </div>
    `;
    return headerHTML;
  };

  // Helper function to generate field HTML
  const generateField = (header, value) => {
    const i = headers.indexOf(header);
    const isDateField = dateFields.includes(header);
    const isTimeField = timeFields.includes(header);
    const isEmploymentOption = header === "Employment Option";
    const isPaidLeaveField = header === "Paid Leave elegble";
    const canUpdate = (row[headers.indexOf("Status")] || "Draft") === "Draft" && allowedFields.includes(header);

    if (isEmploymentOption || isPaidLeaveField) {
      const options = isEmploymentOption ? employmentOptions : paidLeaveOptions;
      const defaultOption = isEmploymentOption ? "Active" : "After 3 month";
      return `
        <div class="cv-field">
          <label>${header}:</label>
          <select id="input-${i}" disabled>
            ${options.map(opt => `<option value="${opt}" ${opt === (value || defaultOption) ? 'selected' : ''}>${opt}</option>`).join("")}
          </select>
        </div>`;
    }

    if (isTimeField) {
      const timeValue = parseTime(value);
      return `
        <div class="cv-field">
          <label>${header}:</label>
          <input type="time" id="input-${i}" value="${timeValue || ""}" disabled>
        </div>`;
    }

    const dateValue = isDateField ? parseMMDDYYYY(value) : value;
    return `
      <div class="cv-field">
        <label>${header}:</label>
        ${isDateField 
          ? `<input type="date" id="input-${i}" value="${dateValue || ""}" ${!canUpdate ? 'disabled' : ''}>` 
          : `<input type="text" id="input-${i}" value="${dateValue || ""}" ${!canUpdate ? 'disabled' : ''}>`}
      </div>`;
  };

  const generateImageField = (header, value) => {
    const i = headers.indexOf(header);
    const canUpdate = (row[headers.indexOf("Status")] || "Draft") === "Draft" && allowedFields.includes(header);
    let imageHTML = '';
    if (value && value.startsWith("http")) {
      const fileIdMatch = value.match(/\/d\/([a-zA-Z0-9_-]{33})\/view/) || value.match(/mock\/([a-zA-Z0-9_-]+)/);
      if (fileIdMatch && fileIdMatch[1]) {
        imageHTML = `
          <div class="image-container">
            <img src="https://drive.google.com/thumbnail?id=${fileIdMatch[1]}&sz=w60" 
                 class="loading" 
                 id="image-${i}">
            <a href="${value}" target="_blank" class="view-full-image">View Full Image</a>
          </div>
        `;
      } else {
        imageHTML = `
          <div class="image-container">
            <span id="image-${i}">No image</span>
            <a href="${value}" target="_blank" class="view-full-image">View Image</a>
          </div>
        `;
      }
    } else {
      imageHTML = `
        <div class="image-container">
          <span id="image-${i}">No image</span>
        </div>
      `;
    }
    return `
      <div class="cv-field">
        <label>${header}:</label>
        ${imageHTML}
        <input type="hidden" id="input-${i}" value="${value || ""}">
        <div class="cv-image-actions" id="actions-${i}">
          ${value && value.startsWith("http") && canUpdate
            ? `<button class="delete-btn" data-index="${i}">Delete</button>`
            : canUpdate ? `<input type="file" id="file-${i}" accept="image/*">` : ''}
        </div>
      </div>`;
  };

  // Render form content
  const renderForm = () => {
    const canUpdate = (row[headers.indexOf("Status")] || "Draft") === "Draft";

    const cvHeader = document.getElementById('cvHeader');
    if (cvHeader) {
      cvHeader.innerHTML = generateHeaderHTML();
    } else {
      log('Error: cvHeader element not found');
    }

    const fieldsContainer = document.getElementById('fieldsContainer');
    if (!fieldsContainer) {
      log('Error: fieldsContainer element not found');
      return;
    }

    let modalHTML = `
      <div class="cv-section">
        <h2>Personal Information</h2>
        <div class="cv-field-row fade-in">
          ${generateField("TimeSync Username", row[headers.indexOf("TimeSync Username")])}
          ${generateField("Full Name", row[headers.indexOf("Full Name")])}
        </div>
        <div class="cv-field-row fade-in">
          ${generateField("DOB", row[headers.indexOf("DOB")])}
          ${generateField("Birth certificate number", row[headers.indexOf("Birth certificate number")])}
        </div>
        <div class="cv-field-row fade-in">
          ${generateField("Father's Name", row[headers.indexOf("Father's Name")])}
          ${generateField("Blood Group", row[headers.indexOf("Blood Group")])}
        </div>
        <div class="cv-field-row fade-in">
          ${generateField("Finger name", row[headers.indexOf("Finger name")])}
          ${generateField("Finger ID", row[headers.indexOf("Finger ID")])}
        </div>
        <div class="cv-field-row fade-in">
          ${generateField("Address", row[headers.indexOf("Address")])}
          ${generateField("NID number", row[headers.indexOf("NID number")])}
        </div>
        <div class="cv-field-row fade-in">
          ${generateField("Contact number", row[headers.indexOf("Contact number")])}
          ${generateField("Emergency Contact Number", row[headers.indexOf("Emergency Contact Number")])}
        </div>
        <div class="cv-field-row fade-in">
          ${generateField("Gmail", row[headers.indexOf("Gmail")])}
          ${generateField("Bank Account Number", row[headers.indexOf("Bank Account Number")])}
        </div>
      </div>
      <div class="cv-section">
        <h2>Employment Details</h2>
        <div class="cv-field-row fade-in">
          ${generateField("Joing date", row[headers.indexOf("Joing date")])}
          ${generateField("Shift", row[headers.indexOf("Shift")])}
        </div>
        <div class="cv-field-row fade-in">
          ${generateField("Department", row[headers.indexOf("Department")])}
          ${generateField("Designation", row[headers.indexOf("Designation")])}
        </div>
        <div class="cv-field-row fade-in">
          ${generateField("Paid Leave elegble", row[headers.indexOf("Paid Leave elegble")])}
          ${generateField("Outstanding", row[headers.indexOf("Outstanding")])}
        </div>
        <div class="cv-field-row fade-in">
          ${generateField("Employment Option", row[headers.indexOf("Employment Option")])}
          ${generateField("Termination date", row[headers.indexOf("Termination date")])}
        </div>
      </div>
      <div class="cv-section">
        <h2>Contract</h2>
        <div class="cv-field-row fade-in">
          ${generateField("Contracted Day", row[headers.indexOf("Contracted Day")])}
          ${generateField("Contracted Hours", row[headers.indexOf("Contracted Hours")])}
        </div>
        <div class="cv-field-row fade-in">
          ${generateField("Base Salary", row[headers.indexOf("Base Salary")])}
          ${generateField("OT status", row[headers.indexOf("OT status")])}
        </div>
        <div class="cv-field-row fade-in">
          ${generateField("Duty Start", row[headers.indexOf("Duty Start")])}
          ${generateField("Provident Fund", row[headers.indexOf("Provident Fund")])}
        </div>
      </div>
      <div class="cv-section">
        <h2>Other</h2>
        <div class="cv-field-row fade-in">
          ${generateField("connection code", row[headers.indexOf("connection code")])}
          ${generateField("Data export code", row[headers.indexOf("Data export code")])}
        </div>
      </div>
      <div class="cv-section">
        <h2>Educational Certificates</h2>
        <div class="cv-field-row fade-in">
          ${generateImageField("Certificate image 1", imageUrls[headers.indexOf("Certificate image 1")])}
          ${generateImageField("Certificate image 2", imageUrls[headers.indexOf("Certificate image 2")])}
        </div>
        <div class="cv-field-row fade-in">
          ${generateImageField("Certificate image 3", imageUrls[headers.indexOf("Certificate image 3")])}
          ${generateImageField("Certificate image 4", imageUrls[headers.indexOf("Certificate image 4")])}
        </div>
        <div class="cv-field-row fade-in">
          ${generateImageField("Certificate image 5", imageUrls[headers.indexOf("Certificate image 5")])}
        </div>
      </div>
      <div class="cv-section">
        <h2>Personal Certificates</h2>
        <div class="cv-field-row fade-in">
          ${generateImageField("Certificate image 6", imageUrls[headers.indexOf("Certificate image 6")])}
          ${generateImageField("Certificate image 7", imageUrls[headers.indexOf("Certificate image 7")])}
        </div>
        <div class="cv-field-row fade-in">
          ${generateImageField("Certificate image 8", imageUrls[headers.indexOf("Certificate image 8")])}
          ${generateImageField("Certificate image 9", imageUrls[headers.indexOf("Certificate image 9")])}
        </div>
      </div>
      <div class="cv-section">
        <h2>Warning Letters</h2>
        <div class="cv-field-row fade-in">
          ${generateImageField("Warning Letter 1", imageUrls[headers.indexOf("Warning Letter 1")])}
          ${generateImageField("Warning Letter 2", imageUrls[headers.indexOf("Warning Letter 2")])}
        </div>
        <div class="cv-field-row fade-in">
          ${generateImageField("Warning Letter 3", imageUrls[headers.indexOf("Warning Letter 3")])}
        </div>
      </div>
      <div class="cv-section">
        <h2>Bonus Days</h2>
        <div class="cv-field-row fade-in">
          ${generateField("Conditional Bonus", row[headers.indexOf("Conditional Bonus")])}
          ${generateField("Unconditional Bonus", row[headers.indexOf("Unconditional Bonus")])}
        </div>
      </div>
      <div class="cv-section">
        <h2>Status & Remarks</h2>
        <div class="cv-field-row fade-in">
          <div class="cv-field">
            <label>Status:</label>
            <select id="statusSelect" disabled>
              ${statusOptions.map(opt => `<option value="${opt}" ${opt === (row[headers.indexOf("Status")] || "Draft") ? 'selected' : ''}>${opt}</option>`).join("")}
            </select>
          </div>
          <div class="cv-field">
            <label>Remark:</label>
            <textarea id="remarkInput" rows="4" disabled>${row[headers.indexOf("Remark")] || ""}</textarea>
          </div>
        </div>
      </div>
    `;

    fieldsContainer.innerHTML = modalHTML;

    // Attach image event listeners after rendering
    attachImageEventListeners();
  };

  // Function to attach onload and onerror event listeners to images
  const attachImageEventListeners = () => {
    const images = document.querySelectorAll('img.loading');
    images.forEach(img => {
      img.addEventListener('load', () => {
        img.classList.remove('loading');
      });
      img.addEventListener('error', () => {
        img.src = img.id === 'profile-pic-img' 
          ? 'https://via.placeholder.com/80?text=No+Image' 
          : 'https://via.placeholder.com/60?text=Image+Not+Available';
        img.classList.remove('loading');
      });
    });
  };

  // Attach event listeners after rendering
  const attachEventListeners = () => {
    // Attach delete button listeners
    const deleteButtons = document.querySelectorAll('.delete-btn');
    deleteButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const index = e.target.dataset.index;
        if (confirm(`Are you sure you want to delete ${headers[index]}?`)) {
          deleteImage(index);
        }
      });
    });

    // Attach file input listeners
    const fileInputs = document.querySelectorAll('input[type="file"]');
    fileInputs.forEach(input => {
      input.addEventListener('change', async (e) => {
        const index = e.target.id.replace('file-', '');
        const file = e.target.files[0];
        if (file) {
          try {
            const token = await new Promise((resolve, reject) => {
              chrome.identity.getAuthToken({ interactive: true }, (token) => {
                if (chrome.runtime.lastError || !token) {
                  reject(new Error(chrome.runtime.lastError?.message || "Authentication failed"));
                } else {
                  resolve(token);
                }
              });
            });
            const uploaded = await uploadToDrive(token, file);
            updateImagePreview(index, uploaded.url);
          } catch (error) {
            alert(`Error uploading image: ${error.message}`);
          }
        }
      });
    });

    // Attach sticky panel button listeners
    const statusBtn = document.getElementById('statusBtn');
    if (statusBtn) {
      statusBtn.addEventListener('click', () => {
        const statusSelect = document.getElementById('statusSelect');
        if (statusSelect) statusSelect.focus();
        log('Status button clicked');
      });
    }

    const closeBtn = document.getElementById('closeBtn');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => {
        closeBtn.classList.add('opacity-50');
        log('Closing window');
        setTimeout(() => window.close(), 300);
      });
    }

    const approvalStatusBtn = document.getElementById('approvalStatusBtn');
    if (approvalStatusBtn) {
      approvalStatusBtn.addEventListener('click', () => {
        const status = row[headers.indexOf("Status")] || "Draft";
        alert(`Current Approval Status: ${status}`);
        log('Approval Status button clicked');
      });
    }

    const saveChangesBtn = document.getElementById('saveChangesBtn');
    if (saveChangesBtn) {
      saveChangesBtn.addEventListener('click', async () => {
        const currentStatus = row[headers.indexOf("Status")] || "Draft";
        if (currentStatus !== "Draft") {
          alert('You can only update information when the status is set to "Draft".');
          return;
        }

        saveChangesBtn.innerHTML = `Saving... <span class="loading-spinner"></span>`;
        saveChangesBtn.disabled = true;

        const updatedRow = [...row];
        indices.forEach(i => {
          const input = document.getElementById(`input-${i}`);
          if (input && allowedFields.includes(headers[i])) {
            if (dateFields.includes(headers[i])) {
              updatedRow[i] = formatToMMDDYYYY(input.value);
            } else if (timeFields.includes(headers[i])) {
              updatedRow[i] = formatTime(input.value);
            } else {
              updatedRow[i] = input.value.trim();
            }
          } else if (imageUrls[i] && allowedFields.includes(headers[i])) {
            updatedRow[i] = imageUrls[i];
          }
        });

        try {
          const token = await new Promise((resolve, reject) => {
            chrome.identity.getAuthToken({ interactive: true }, (token) => {
              if (chrome.runtime.lastError || !token) {
                reject(new Error(chrome.runtime.lastError?.message || "Authentication failed"));
              } else {
                resolve(token);
              }
            });
          });

          const imageUploadPromises = [];
          document.querySelectorAll('input[type="file"]').forEach(input => {
            const index = input.id.replace('file-', '');
            const file = input.files[0];
            if (file && allowedFields.includes(headers[index])) {
              imageUploadPromises.push(
                uploadToDrive(token, file).then(uploaded => {
                  updatedRow[index] = uploaded.url;
                  updateImagePreview(index, uploaded.url);
                })
              );
            }
          });

          await Promise.all(imageUploadPromises);
          log('All image uploads completed:', imageUrls);

          await appendToSheet(token, updatedRow, sheetRowIndex);
          employeeData = { row: updatedRow, sheetRowIndex };
          sessionStorage.setItem('employeeData', JSON.stringify(employeeData));
          alert("Employee information updated successfully. Please verify the changes and click Close to exit.");
          saveChangesBtn.innerHTML = `SAVE CHANGES`;
          saveChangesBtn.disabled = false;
        } catch (error) {
          alert(`Error updating employee information: ${error.message}`);
          log('Update Information failed:', error);
          saveChangesBtn.innerHTML = `SAVE CHANGES`;
          saveChangesBtn.disabled = false;
        }
      });
    }
  };

  // Upload image to Google Drive
  async function uploadToDrive(token, file) {
    try {
      log(`Starting upload for file: ${file.name}`);
      const metadata = {
        name: file.name,
        mimeType: file.type,
        parents: ['1C25n7dRnlv4sPWWb5czho1p48FvieQje']
      };

      const form = new FormData();
      form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
      form.append('file', file);

      const response = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
        body: form
      });

      if (!response.ok) {
        const error = await response.json().catch(() => {});
        throw new Error(error.error?.message || `Drive upload failed: ${response.status}`);
      }

      const data = await response.json();
      log(`File uploaded successfully: ${file.name}, ID: ${data.id}`);
      return { id: data.id, url: `https://drive.google.com/file/d/${data.id}/view` };
    } catch (error) {
      log(`Upload to Drive failed for ${file.name}:`, error);
      throw error;
    }
  };

  // Append or update data in Google Sheet
  async function appendToSheet(token, values, rowIndex = null) {
    try {
      log(`Preparing to ${rowIndex ? 'update' : 'append'} data to sheet, rowIndex: ${rowIndex}`);
      log('Values to send:', values);

      const result = await new Promise((resolve) => {
        chrome.storage.local.get(['sheetId2'], (result) => {
          resolve(result);
        });
      });

      const sheetId = result.sheetId2;
      if (!sheetId) {
        throw new Error('No sheet ID found in chrome.storage.local');
      }

      const sheetName = 'Employee_Management';
      const range = rowIndex ? `${sheetName}!A${rowIndex}:AV${rowIndex}` : `${sheetName}!A:AV`;

      const valuesToSend = [values];

      log(`Sending request to Google Sheets API: Range=${range}, Values=`, valuesToSend);

      const response = await fetch(
        `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${range}?valueInputOption=USER_ENTERED`,
        {
          method: rowIndex ? 'PUT' : 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ values: valuesToSend })
        }
      );

      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        throw new Error(error.error?.message || `Sheet ${rowIndex ? 'update' : 'append'} failed: ${response.status}`);
      }

      const data = await response.json();
      log(`Sheet ${rowIndex ? 'updated' : 'appended'} successfully:`, data);
      return data;
    } catch (error) {
      log(`Error ${rowIndex ? 'updating' : 'appending to'} sheet:`, error);
      throw error;
    }
  }

  // Update image preview and actions
  const updateImagePreview = (index, newUrl) => {
    log(`Updating image preview for index ${index}: ${newUrl}`);
    imageUrls[index] = newUrl;
    const imageElement = document.getElementById(`image-${index}`);
    const inputElement = document.getElementById(`input-${index}`);
    const isProfilePic = index == headers.indexOf("Profile Pic");
    const actionsElement = isProfilePic 
      ? document.getElementById('profile-pic-actions') 
      : document.getElementById(`actions-${index}`);
    const canUpdate = (row[headers.indexOf("Status")] || "Draft") === "Draft" && allowedFields.includes(headers[index]);

    if (inputElement) {
      inputElement.value = newUrl;
    }

    if (imageElement) {
      if (newUrl && newUrl.startsWith("http")) {
        const fileIdMatch = newUrl.match(/\/d\/([a-zA-Z0-9_-]{33})\/view/) || newUrl.match(/mock\/([a-zA-Z0-9_-]+)/);
        if (fileIdMatch && fileIdMatch[1]) {
          imageElement.outerHTML = `
            <div class="image-container">
              <img src="https://drive.google.com/thumbnail?id=${fileIdMatch[1]}&sz=w60" 
                   class="loading" 
                   id="image-${index}">
              <a href="${newUrl}" target="_blank" class="view-full-image">View Full Image</a>
            </div>`;
        } else {
          imageElement.outerHTML = `
            <div class="image-container">
              <span id="image-${index}">No image</span>
              <a href="${newUrl}" target="_blank" class="view-full-image">View Image</a>
            </div>`;
        }
      } else {
        imageElement.outerHTML = `<span id="image-${index}">No image</span>`;
      }
    }

    if (isProfilePic) {
      const profilePicImg = document.getElementById('profile-pic-img');
      if (newUrl && newUrl.startsWith("http")) {
        const fileIdMatch = newUrl.match(/\/d\/([a-zA-Z0-9_-]{33})\/view/) || newUrl.match(/mock\/([a-zA-Z0-9_-]+)/);
        if (fileIdMatch && fileIdMatch[1]) {
          profilePicImg.outerHTML = `
            <img src="https://drive.google.com/thumbnail?id=${fileIdMatch[1]}&sz=w80" 
                 class="cv-profile-pic loading" 
                 id="profile-pic-img">
          `;
        } else {
          profilePicImg.outerHTML = `<span id="profile-pic-img">No image</span>`;
        }
      } else {
        profilePicImg.outerHTML = `<span id="profile-pic-img">No image</span>`;
      }
    }

    if (actionsElement) {
      actionsElement.innerHTML = newUrl && newUrl.startsWith("http") && canUpdate
        ? `<button class="delete-btn" data-index="${index}">Delete</button>`
        : canUpdate ? `<input type="file" id="file-${index}" accept="image/*">` : '';

      const newDeleteBtn = actionsElement.querySelector('.delete-btn');
      if (newDeleteBtn) {
        newDeleteBtn.addEventListener('click', () => {
          if (confirm(`Are you sure you want to delete ${headers[index]}?`)) {
            deleteImage(index);
          }
        });
      }
      const newFileInput = actionsElement.querySelector(`#file-${index}`);
      if (newFileInput) {
        newFileInput.addEventListener('change', async (e) => {
          const file = e.target.files[0];
          if (file) {
            try {
              const token = await new Promise((resolve, reject) => {
                chrome.identity.getAuthToken({ interactive: true }, (token) => {
                  if (chrome.runtime.lastError || !token) {
                    reject(new Error(chrome.runtime.lastError?.message || "Authentication failed"));
                  } else {
                    resolve(token);
                  }
                });
              });
              const uploaded = await uploadToDrive(token, file);
              updateImagePreview(index, uploaded.url);
            } catch (error) {
              alert(`Error uploading image: ${error.message}`);
            }
          }
        });
      }
    }

    // Reattach image event listeners after updating DOM
    attachImageEventListeners();
  };

  // Handle image deletion
  const deleteImage = (index) => {
    log(`Deleting image at index ${index}`);
    updateImagePreview(index, "");
  };

  // Initialize form when DOM is loaded
  document.addEventListener('DOMContentLoaded', () => {
    log('DOM loaded, initializing form');
    initializeForm().then(() => {
      attachEventListeners();
    });
  });
})();