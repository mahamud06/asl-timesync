function disableConsoleLog() {
    console.log = function() {};
}
// Uncomment the next line to disable console logging in production
// disableConsoleLog();

// Helper function to convert 24-hour time to 12-hour format with seconds (HH:MM:SS AM/PM)
function to12HourFormat(time) {
    if (!time || time === 'N/A' || time.trim() === '') return 'N/A';
    const [hours, minutes] = time.split(':').map(Number);
    const period = hours >= 12 ? 'PM' : 'AM';
    const adjustedHours = hours % 12 || 12; // Convert 0 to 12 for midnight
    return `${adjustedHours}:${minutes.toString().padStart(2, '0')}:00 ${period}`;
}

// Helper function to convert 12-hour HH:MM:SS AM/PM to 24-hour HH:MM for form
function to24HourFormat(time) {
    if (!time || time === 'N/A' || time.trim() === '') return '';
    try {
        const [timePart, period] = time.split(' ');
        let [hours, minutes] = timePart.split(':').map(Number);
        if (period && period.toUpperCase() === 'PM' && hours !== 12) hours += 12;
        if (period && period.toUpperCase() === 'AM' && hours === 12) hours = 0;
        return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
    } catch (error) {
        console.warn(`Invalid time format: "${time}"`, error);
        return '';
    }
}

// Helper function to convert column index to letter (0=A, 1=B, ..., 515=OU, 1535=AFW)
function getColumnLetter(index) {
    let letters = '';
    while (index >= 0) {
        letters = String.fromCharCode((index % 26) + 65) + letters;
        index = Math.floor(index / 26) - 1;
    }
    return letters;
}

// Helper function for API calls with retries
async function fetchWithRetry(url, options, retries = 3, delay = 1500) {
    for (let i = 0; i < retries; i++) {
        try {
            const response = await fetch(url, options);
            if (!response.ok && response.status === 429) {
                console.warn(`Rate limit hit (429) on attempt ${i + 1}. Retrying after ${delay}ms...`);
                await new Promise(resolve => setTimeout(resolve, delay));
                delay *= 2; // Exponential backoff
                continue;
            }
            return response;
        } catch (error) {
            console.warn(`Fetch error on attempt ${i + 1}: ${error.message}`);
            if (i === retries - 1) throw error;
            await new Promise(resolve => setTimeout(resolve, delay));
            delay *= 2;
        }
    }
}

const googleSheetsApiKey = "AIzaSyDIuRc7QsUTJ8C5-0yzXeY9bM79-jxyTFY";

// Function to show loading animation
function showLoadingAnimation() {
    let loadingDiv = document.getElementById('loadingSpinner');
    if (!loadingDiv) {
        loadingDiv = document.createElement('div');
        loadingDiv.id = 'loadingSpinner';
        loadingDiv.style.position = 'fixed';
        loadingDiv.style.top = '50%';
        loadingDiv.style.left = '50%';
        loadingDiv.style.transform = 'translate(-50%, -50%)';
        loadingDiv.style.zIndex = '1000';
        loadingDiv.innerHTML = `
            <div style="border: 4px solid #f3f3f3; border-top: 4px solid #3498db; border-radius: 50%; width: 40px; height: 40px; animation: spin 1s linear infinite;"></div>
            <style>
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            </style>
        `;
        document.body.appendChild(loadingDiv);
    }
    loadingDiv.style.display = 'block';
}

// Function to hide loading animation
function hideLoadingAnimation() {
    const loadingDiv = document.getElementById('loadingSpinner');
    if (loadingDiv) {
        loadingDiv.style.display = 'none';
    }
}

// Function to set time inputs to read-only
function setTimeInputsReadOnly(readonly) {
    const inputs = document.querySelectorAll('input[type="time"]');
    inputs.forEach(input => {
        input.readOnly = readonly;
        console.log(`Set input ${input.name} to readOnly=${readonly}`);
    });
}

// Function to get days in a month
function getDaysInMonth(month, year) {
    return new Date(year, month, 0).getDate();
}

// Function to get month name from number
function getMonthName(month) {
    const monthNames = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ];
    return monthNames[month - 1] || 'Unknown';
}

// Function to get day of week from date
function getDayOfWeek(dateStr) {
    const date = new Date(dateStr);
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return days[date.getDay()];
}

// Function to fetch month/year from ATTENDENCE_LIST M1 and generate table
async function initializeAttendanceTable(token) {
    try {
        showLoadingAnimation();
        const sheetIdResult = await new Promise((resolve, reject) => {
            if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
                reject(new Error('Chrome storage API not available.'));
            }
            chrome.storage.local.get("sheetId2", (result) => {
                if (chrome.runtime.lastError || !result.sheetId2) {
                    reject(new Error(`Failed to get sheetId2: ${chrome.runtime.lastError?.message || 'No sheetId2 found in storage'}`));
                } else {
                    resolve(result.sheetId2);
                }
            });
        });
        const sheetId = sheetIdResult;
        const sheetName = 'ATTENDENCE_LIST';

        // Fetch M1 cell value
        const response = await fetchWithRetry(
            `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!M1`,
            {
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        if (!response.ok) {
            const errorData = await response.json();
            console.error('Error fetching M1 cell:', errorData);
            throw new Error(`Failed to fetch month/year: ${errorData.error?.message || 'Unknown error'}`);
        }

        const data = await response.json();
        const m1Value = data.values && data.values[0] && data.values[0][0] ? data.values[0][0].trim() : '';
        console.log('Fetched M1 value:', m1Value);

        // Parse month and year from M1 (e.g., "8" or "08 2025")
        let month, year;
        if (m1Value.includes(' ')) {
            [month, year] = m1Value.split(' ').map(val => parseInt(val));
        } else {
            month = parseInt(m1Value);
            year = 2025; // Default year if not provided
        }

        if (isNaN(month) || month < 1 || month > 12) {
            console.error('Invalid month value in M1:', m1Value);
            month = 8; // Fallback to August
            year = 2025;
        }
        if (isNaN(year)) {
            year = 2025; // Fallback year
        }
        console.log(`Parsed month: ${month}, year: ${year}`);

        // Update tracker title
        const trackerTitle = document.getElementById('trackerTitle');
        trackerTitle.textContent = `Attendance Tracker - ${getMonthName(month)} ${year}`;

        // Generate table rows
        const daysInMonth = getDaysInMonth(month, year);
        const tbody = document.getElementById('attendanceTableBody');
        tbody.innerHTML = ''; // Clear placeholder

        for (let day = 1; day <= daysInMonth; day++) {
            const dateStr = `${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}-${year}`;
            const dateForDay = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
            const dayOfWeek = getDayOfWeek(dateForDay);
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${dateStr} ${dayOfWeek}</td>
                <td><input type="time" name="checkIn_${day}"></td>
                <td><input type="time" name="checkOut_${day}"></td>
            `;
            tbody.appendChild(row);
        }
        console.log(`Generated ${daysInMonth} table rows for ${getMonthName(month)} ${year}`);
    } catch (error) {
        console.error('Error initializing attendance table:', error);
        alert('⚠️ Failed to initialize attendance table. Using default August 2025.');
        // Fallback to August 2025
        const month = 8;
        const year = 2025;
        const trackerTitle = document.getElementById('trackerTitle');
        trackerTitle.textContent = `Attendance Tracker - ${getMonthName(month)} ${year}`;
        const daysInMonth = getDaysInMonth(month, year);
        const tbody = document.getElementById('attendanceTableBody');
        tbody.innerHTML = '';
        for (let day = 1; day <= daysInMonth; day++) {
            const dateStr = `${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}-${year}`;
            const dateForDay = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
            const dayOfWeek = getDayOfWeek(dateForDay);
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${dateStr} ${dayOfWeek}</td>
                <td><input type="time" name="checkIn_${day}"></td>
                <td><input type="time" name="checkOut_${day}"></td>
            `;
            tbody.appendChild(row);
        }
    } finally {
        hideLoadingAnimation();
    }
}

// Function to check user permission by matching username in Credential sheet and returning column M departments
async function userPermission(username, token) {
    try {
        const sheetIdResult = await new Promise((resolve, reject) => {
            if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
                reject(new Error('Chrome storage API not available.'));
            }
            chrome.storage.local.get("sheetId", (result) => {
                if (chrome.runtime.lastError || !result.sheetId) {
                    reject(new Error(`Failed to get sheetId: ${chrome.runtime.lastError?.message || 'No sheetId found in storage'}`));
                } else {
                    resolve(result.sheetId);
                }
            });
        });
        const sheetId = sheetIdResult;
        const sheetName = 'Credential';
        
        const response = await fetchWithRetry(
            `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!A2:M`,
            {
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        if (!response.ok) {
            const errorData = await response.json();
            console.error('Error fetching usernames for permission check:', errorData);
            throw new Error(`Failed to fetch usernames: ${errorData.error?.message || 'Unknown error'}`);
        }

        const data = await response.json();
        const rows = data.values || [];
        console.log('Fetched usernames and departments from A2:M (Credential):', rows);

        const matchedRowIndex = rows.findIndex(row => 
            row[0] && row[0].trim().toLowerCase() === username.trim().toLowerCase()
        );

        if (matchedRowIndex === -1) {
            console.warn(`Username "${username}" not found in column A of Credential sheet ${sheetId}.`);
            return null;
        }

        const departmentValue = rows[matchedRowIndex][12] ? rows[matchedRowIndex][12].trim() : '';
        console.log(`Department for username "${username}" found at row ${matchedRowIndex + 2}: ${departmentValue}`);
        return departmentValue || null;
    } catch (error) {
        console.error('Error checking user permission:', error);
        return null;
    }
}

// Function to populate employee dropdown from ATTENDENCE_LIST sheet
async function populateEmployeeDropdown(token, userDepartment = null, username = null) {
    try {
        const sheetIdResult = await new Promise((resolve, reject) => {
            if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
                reject(new Error('Chrome storage API not available.'));
            }
            chrome.storage.local.get("sheetId2", (result) => {
                if (chrome.runtime.lastError || !result.sheetId2) {
                    reject(new Error(`Failed to get sheetId2: ${chrome.runtime.lastError?.message || 'No sheetId2 found in storage'}`));
                } else {
                    resolve(result.sheetId2);
                }
            });
        });
        const sheetId = sheetIdResult;
        const sheetName = 'ATTENDENCE_LIST';
        const employeeSelect = document.getElementById('employeeName');

        if (!userDepartment && username) {
            console.log(`No department permission for "${username}". Populating dropdown with only username.`);
            employeeSelect.innerHTML = '<option value="" disabled>Select an employee</option>';
            const option = document.createElement('option');
            option.value = username.toUpperCase();
            option.textContent = username.toUpperCase();
            employeeSelect.appendChild(option);
            employeeSelect.value = username.toUpperCase();
            console.log('Employee dropdown populated with single option:', username.toUpperCase());
            return;
        }

        const response = await fetchWithRetry(
            `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!A2:C`,
            {
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        if (!response.ok) {
            const errorData = await response.json();
            console.error('Error fetching employee names and departments:', errorData);
            throw new Error(`Failed to fetch employee data: ${errorData.error?.message || 'Unknown error'}`);
        }

        const data = await response.json();
        const employees = data.values ? data.values.map(row => ({
            name: row[0] ? row[0].trim().toUpperCase() : '',
            department: row[2] ? row[2].trim() : ''
        })).filter(employee => employee.name) : [];
        console.log('Fetched employee data from ATTENDENCE_LIST:', employees);

        employeeSelect.innerHTML = '<option value="" disabled selected>Select an employee</option>';

        let filteredEmployees = employees;
        if (userDepartment) {
            const allowedDepartments = userDepartment.split(',').map(dep => dep.trim().toLowerCase());
            console.log('Filtering employees by allowed departments:', allowedDepartments);
            filteredEmployees = employees.filter(employee => 
                employee.department && 
                allowedDepartments.includes(employee.department.toLowerCase())
            );
            console.log('Filtered employees:', filteredEmployees);
        }

        filteredEmployees.forEach(employee => {
            const option = document.createElement('option');
            option.value = employee.name;
            option.textContent = employee.name;
            employeeSelect.appendChild(option);
        });

        console.log('Employee dropdown populated with', filteredEmployees.length, 'options.');
    } catch (error) {
        console.error('Error populating employee dropdown:', error);
        alert('⚠️ Failed to load employee names from Google Sheet. Check console for details.');
    }
}

// Function to load attendance data from Google Sheet
async function loadAttendanceData(employeeName, token, hasPermission = false, month, year) {
    try {
        showLoadingAnimation();
        setTimeInputsReadOnly(true);
        const sheetIdResult = await new Promise((resolve, reject) => {
            if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
                reject(new Error('Chrome storage API not available.'));
            }
            chrome.storage.local.get("sheetId4", (result) => {
                if (chrome.runtime.lastError || !result.sheetId4) {
                    reject(new Error(`Failed to get sheetId4: ${chrome.runtime.lastError?.message || 'No sheetId4 found in storage'}`));
                } else {
                    resolve(result.sheetId4);
                }
            });
        });
        const sheetId = sheetIdResult;
        const sheetName = 'Sheet1';

        // Clear all time inputs before loading
        const form = document.getElementById('attendanceForm');
        const inputs = form.querySelectorAll('input[type="time"]');
        inputs.forEach(input => input.value = '');
        console.log('Cleared all time inputs before loading.');

        // Fetch row 1 (A1:AFW1) to find the username column
        const headerResponse = await fetchWithRetry(
            `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!A1:AFW1`,
            {
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        if (!headerResponse.ok) {
            const errorData = await headerResponse.json();
            console.error('Header fetch response error:', errorData);
            throw new Error(`Failed to fetch row 1: ${errorData.error?.message || 'Unknown error'}`);
        }

        const headerData = await headerResponse.json();
        const headerValues = headerData.values ? headerData.values[0] : [];
        console.log('Fetched headers from row 1 (A1:AFW1):', headerValues);

        const usernameColumnIndex = headerValues.findIndex(val => val && val.trim().toLowerCase() === employeeName.toLowerCase());
        if (usernameColumnIndex === -1) {
            console.error('Username not found in row 1 (A1:AFW1):', employeeName);
            return;
        }

        const checkInColumn = getColumnLetter(usernameColumnIndex + 1);
        const checkOutColumn = getColumnLetter(usernameColumnIndex + 2);
        console.log(`Username found in column ${getColumnLetter(usernameColumnIndex)} (index ${usernameColumnIndex}).`);
        console.log(`Check-in column: ${checkInColumn}, Check-out column: ${checkOutColumn}`);

        // Fetch dates and times from B5:[checkOutColumn]35
        const dataResponse = await fetchWithRetry(
            `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!B5:${checkOutColumn}35`,
            {
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        if (!dataResponse.ok) {
            const errorData = await dataResponse.json();
            console.error('Data fetch response error:', errorData);
            throw new Error(`Failed to fetch attendance data: ${errorData.error?.message || 'Unknown error'}`);
        }

        const sheetData = await dataResponse.json();
        const rows = sheetData.values || [];
        console.log('Fetched attendance data (B5:' + checkOutColumn + '35):', rows);

        // Get days in the specified month
        const daysInMonth = getDaysInMonth(month, year);

        // Map sheet dates to form inputs
        rows.forEach((row, index) => {
            if (index >= daysInMonth) return; // Skip rows beyond the month's days
            const sheetDate = row[0] ? row[0].trim() : '';
            const checkInTime = row[usernameColumnIndex] ? row[usernameColumnIndex].trim() : '';
            const checkOutTime = row[usernameColumnIndex + 1] ? row[usernameColumnIndex + 1].trim() : '';
            const formDate = `${month.toString().padStart(2, '0')}-${(index + 1).toString().padStart(2, '0')}-${year}`;

            console.log(`Row ${index + 5}: Sheet date="${sheetDate}", Form date="${formDate}"`);
            console.log(`Check-In (column ${checkInColumn}): "${checkInTime}"`);
            console.log(`Check-Out (column ${checkOutColumn}): "${checkOutTime}"`);

            if (sheetDate === formDate) {
                const checkInInput = document.querySelector(`input[name="checkIn_${index + 1}"]`);
                const checkOutInput = document.querySelector(`input[name="checkOut_${index + 1}"]`);
                
                if (checkInInput) {
                    const formattedCheckIn = to24HourFormat(checkInTime);
                    checkInInput.value = formattedCheckIn;
                    console.log(`Set checkIn_${index + 1} to "${formattedCheckIn}" for date ${formDate}`);
                } else {
                    console.warn(`checkIn_${index + 1} input not found for date ${formDate}`);
                }
                if (checkOutInput) {
                    const formattedCheckOut = to24HourFormat(checkOutTime);
                    checkOutInput.value = formattedCheckOut;
                    console.log(`Set checkOut_${index + 1} to "${formattedCheckOut}" for date ${formDate}`);
                } else {
                    console.warn(`checkOut_${index + 1} input not found for date ${formDate}`);
                }
            } else {
                console.warn(`Date mismatch for row ${index + 5}: Sheet date="${sheetDate}" != Form date="${formDate}"`);
            }
        });

    } catch (error) {
        console.error('Error loading attendance data:', error);
    } finally {
        hideLoadingAnimation();
        setTimeInputsReadOnly(!hasPermission);
    }
}

// Initialize username and load data on page load
document.addEventListener('DOMContentLoaded', async () => {
    const employeeNameSelect = document.getElementById('employeeName');
    const form = document.getElementById('attendanceForm');
    const submitButton = form ? form.querySelector('button[type="submit"]') : null;

    try {
        const token = await new Promise((resolve, reject) => {
            if (typeof chrome === 'undefined' || !chrome.identity) {
                reject(new Error('Chrome identity API not available.'));
            }
            chrome.identity.getAuthToken({ interactive: false }, function (token) {
                if (chrome.runtime.lastError || !token) {
                    reject(new Error(`Failed to get auth token: ${chrome.runtime.lastError?.message || 'Unknown error'}`));
                } else {
                    resolve(token);
                }
            });
        });
        console.log('Obtained auth token for initial load.');

        // Initialize the attendance table
        let month, year;
        try {
            const sheetIdResult = await new Promise((resolve, reject) => {
                chrome.storage.local.get("sheetId2", (result) => {
                    if (chrome.runtime.lastError || !result.sheetId2) {
                        reject(new Error(`Failed to get sheetId2: ${chrome.runtime.lastError?.message || 'No sheetId2 found in storage'}`));
                    } else {
                        resolve(result.sheetId2);
                    }
                });
            });
            const sheetId = sheetIdResult;
            const response = await fetchWithRetry(
                `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/ATTENDENCE_LIST!M1`,
                {
                    method: 'GET',
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                }
            );
            const data = await response.json();
            const m1Value = data.values && data.values[0] && data.values[0][0] ? data.values[0][0].trim() : '';
            if (m1Value.includes(' ')) {
                [month, year] = m1Value.split(' ').map(val => parseInt(val));
            } else {
                month = parseInt(m1Value);
                year = 2025;
            }
            if (isNaN(month) || month < 1 || month > 12) {
                month = 8;
                year = 2025;
            }
            if (isNaN(year)) {
                year = 2025;
            }
        } catch (error) {
            console.error('Error fetching M1 for initialization:', error);
            month = 8;
            year = 2025;
        }
        await initializeAttendanceTable(token);

        // Load stored username and check permission
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            chrome.storage.local.get("username", async (userResult) => {
                const username = userResult.username?.toUpperCase();
                if (!username) {
                    console.warn('No stored username found.');
                    alert('⚠️ No username found in storage. Please authenticate.');
                    employeeNameSelect.disabled = true;
                    if (form) form.style.display = 'none';
                    return;
                }
                console.log('Loaded stored username:', username);

                const department = await userPermission(username, token);
                window.permittedDepartments = department;

                if (department) {
                    console.log(`User department permission: ${department}`);
                    await populateEmployeeDropdown(token, department);
                    if (employeeNameSelect.querySelector(`option[value="${username}"]`)) {
                        employeeNameSelect.value = username;
                        console.log('Set dropdown to stored username:', username);
                        await loadAttendanceData(username, token, true, month, year);
                        if (submitButton) submitButton.style.display = 'block';
                    } else {
                        console.warn(`Username "${username}" not found in filtered dropdown for department "${department}".`);
                        alert(`⚠️ Your username "${username}" does not match any employee in the allowed department(s): ${department}.`);
                        employeeNameSelect.disabled = true;
                        if (form) form.style.display = 'none';
                    }
                } else {
                    console.log(`No department permission for username "${username}". Restricting to view-only mode.`);
                    await populateEmployeeDropdown(token, null, username);
                    employeeNameSelect.value = username;
                    employeeNameSelect.disabled = true;
                    await loadAttendanceData(username, token, false, month, year);
                    setTimeInputsReadOnly(true);
                    if (submitButton) submitButton.style.display = 'none';
                }
            });
        } else {
            console.warn('Chrome storage API not available.');
            alert('⚠️ Chrome storage API not available.');
            employeeNameSelect.disabled = true;
            if (form) form.style.display = 'none';
        }

        employeeNameSelect.addEventListener('change', async () => {
            if (!window.permittedDepartments) {
                console.log('Dropdown change ignored: User has no permission.');
                return;
            }
            const employeeName = employeeNameSelect.value;
            console.log('Dropdown changed to:', employeeName);
            if (employeeName) {
                try {
                    const token = await new Promise((resolve, reject) => {
                        chrome.identity.getAuthToken({ interactive: true }, function (token) {
                            if (chrome.runtime.lastError || !token) {
                                reject(new Error(`Failed to get auth token: ${chrome.runtime.lastError?.message || 'Unknown error'}`));
                            } else {
                                resolve(token);
                            }
                        });
                    });
                    await loadAttendanceData(employeeName, token, true, month, year);
                    if (submitButton) submitButton.style.display = 'block';
                } catch (error) {
                    console.error('Error loading attendance data on dropdown change:', error);
                    alert('⚠️ Failed to load attendance data. Check console for details.');
                }
            }
        });

        if (form) {
            form.addEventListener('submit', (event) => {
                event.preventDefault();
                event.stopPropagation();
                console.log('Form submitted.');
                submitAttendance(month, year);
            });
        } else {
            console.error('Form with ID "attendanceForm" not found.');
        }

    } catch (error) {
        console.error('Error initializing page:', error);
        alert('⚠️ Failed to initialize page. Check console for details.');
    }
});

async function submitAttendance(month, year) {
    try {
        if (!window.permittedDepartments) {
            alert('⚠️ You do not have permission to submit attendance.');
            console.log('Submission blocked: User has no department permission.');
            return;
        }

        const employeeName = document.getElementById('employeeName').value.trim();
        console.log('Submitting attendance for:', employeeName);
        if (!employeeName) {
            alert('⚠️ Please select an employee name.');
            console.error('Employee name is not selected.');
            return;
        }

        const department = window.permittedDepartments;
        console.log(`User department permission: ${department}`);

        const token = await new Promise((resolve, reject) => {
            if (typeof chrome === 'undefined' || !chrome.identity) {
                reject(new Error('Chrome identity API not available.'));
            }
            chrome.identity.getAuthToken({ interactive: true }, function (token) {
                if (chrome.runtime.lastError || !token) {
                    reject(new Error(`Failed to get auth token: ${chrome.runtime.lastError?.message || 'Unknown error'}`));
                } else {
                    resolve(token);
                }
            });
        });
        console.log('Obtained auth token for submission.');

        const sheetIdResult2 = await new Promise((resolve, reject) => {
            if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
                reject(new Error('Chrome storage API not available.'));
            }
            chrome.storage.local.get("sheetId2", (result) => {
                if (chrome.runtime.lastError || !result.sheetId2) {
                    reject(new Error(`Failed to get sheetId2: ${chrome.runtime.lastError?.message || 'No sheetId2 found in storage'}`));
                } else {
                    resolve(result.sheetId2);
                }
            });
        });
        const sheetIdEmployee = sheetIdResult2;

        const employeeDepartmentResponse = await fetchWithRetry(
            `https://sheets.googleapis.com/v4/spreadsheets/${sheetIdEmployee}/values/ATTENDENCE_LIST!A2:C`,
            {
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        if (!employeeDepartmentResponse.ok) {
            const errorData = await employeeDepartmentResponse.json();
            console.error('Error fetching employee departments:', errorData);
            throw new Error(`Failed to fetch employee data: ${errorData.error?.message || 'Unknown error'}`);
        }

        const employeeData = await employeeDepartmentResponse.json();
        const employees = employeeData.values ? employeeData.values.map(row => ({
            name: row[0] ? row[0].trim().toUpperCase() : '',
            department: row[2] ? row[2].trim() : ''
        })).filter(employee => employee.name) : [];

        const allowedDepartments = department.split(',').map(dep => dep.trim().toLowerCase());
        const selectedEmployee = employees.find(emp => emp.name.toLowerCase() === employeeName.toLowerCase());
        if (!selectedEmployee || !selectedEmployee.department || !allowedDepartments.includes(selectedEmployee.department.toLowerCase())) {
            alert(`⚠️ You do not have permission to submit attendance for "${employeeName}" (department: ${selectedEmployee?.department || 'none'}). Allowed department(s): ${department}.`);
            console.log('Submission blocked: Selected employee not in allowed department.');
            return;
        }

        const daysInMonth = getDaysInMonth(month, year);
        const attendanceData = [];
        for (let i = 1; i <= daysInMonth; i++) {
            const checkIn = document.querySelector(`input[name="checkIn_${i}"]`)?.value || '';
            const checkOut = document.querySelector(`input[name="checkOut_${i}"]`)?.value || '';
            attendanceData.push({
                date: `${month.toString().padStart(2, '0')}-${i.toString().padStart(2, '0')}-${year}`,
                checkIn: checkIn,
                checkOut: checkOut
            });
        }

        console.log('Collected attendance data:', attendanceData);

        if (attendanceData.every(entry => !entry.checkIn && !entry.checkOut)) {
            alert('⚠️ Please fill in at least one check-in or check-out time.');
            console.error('No attendance data provided.');
            return;
        }

        const sheetIdResult4 = await new Promise((resolve, reject) => {
            if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
                reject(new Error('Chrome storage API not available.'));
            }
            chrome.storage.local.get("sheetId4", (result) => {
                if (chrome.runtime.lastError || !result.sheetId4) {
                    reject(new Error(`Failed to get sheetId4: ${chrome.runtime.lastError?.message || 'No sheetId4 found in storage'}`));
                } else {
                    resolve(result.sheetId4);
                }
            });
        });
        const sheetIdAttendance = sheetIdResult4;
        const sheetName = 'Sheet1';

        const headerResponse = await fetchWithRetry(
            `https://sheets.googleapis.com/v4/spreadsheets/${sheetIdAttendance}/values/${sheetName}!A1:AFW1`,
            {
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        if (!headerResponse.ok) {
            const errorData = await headerResponse.json();
            console.error('Header fetch response error:', errorData);
            throw new Error(`Failed to fetch row 1 from Google Sheet: ${errorData.error?.message || 'Unknown error'}`);
        }

        const headerData = await headerResponse.json();
        const headerValues = headerData.values ? headerData.values[0] : [];
        console.log('Fetched headers from row 1 (A1:AFW1):', headerValues);

        const usernameColumnIndex = headerValues.findIndex(val => val && val.trim().toLowerCase() === employeeName.toLowerCase());
        if (usernameColumnIndex === -1) {
            console.error('Username not found in row 1 (A1:AFW1):', employeeName);
            alert(`⚠️ Username "${employeeName}" not found in row 1 of the Google Sheet (A1:AFW1).`);
            return;
        }

        const checkInColumn = getColumnLetter(usernameColumnIndex + 1);
        const checkOutColumn = getColumnLetter(usernameColumnIndex + 2);
        console.log(`Username found in column ${getColumnLetter(usernameColumnIndex)} (index ${usernameColumnIndex}). Using ${checkInColumn} for check-in, ${checkOutColumn} for check-out.`);

        const fetchResponse = await fetchWithRetry(
            `https://sheets.googleapis.com/v4/spreadsheets/${sheetIdAttendance}/values/${sheetName}!B5:B35`,
            {
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        if (!fetchResponse.ok) {
            const errorData = await fetchResponse.json();
            console.error('Fetch response error:', errorData);
            throw new Error(`Failed to fetch dates from Google Sheet: ${errorData.error?.message || 'Unknown error'}`);
        }

        const sheetData = await fetchResponse.json();
        const sheetDates = sheetData.values ? sheetData.values.flat().map(date => date.trim()) : [];
        console.log('Fetched dates from column B (B5:B35):', sheetDates);

        console.log('Form dates:', attendanceData.map(entry => entry.date));

        const updates = [];
        attendanceData.forEach(entry => {
            const rowIndex = sheetDates.findIndex(sheetDate => {
                const isMatch = sheetDate === entry.date;
                console.log(`Comparing form date "${entry.date}" with sheet date "${sheetDate}": ${isMatch}`);
                return isMatch;
            });
            if (rowIndex !== -1) {
                const rowNumber = 5 + rowIndex;
                updates.push({
                    range: `${sheetName}!${checkInColumn}${rowNumber}:${checkOutColumn}${rowNumber}`,
                    values: [[to12HourFormat(entry.checkIn || 'N/A'), to12HourFormat(entry.checkOut || 'N/A')]]
                });
            }
        });

        console.log('Prepared updates:', updates);

        if (updates.length === 0) {
            console.error('No matching dates found. Sheet dates:', sheetDates, 'Form dates:', attendanceData.map(entry => entry.date));
            alert('⚠️ No matching dates found in column B of the Google Sheet. Check console for details.');
            return;
        }

        const batchUpdateResponse = await fetchWithRetry(
            `https://sheets.googleapis.com/v4/spreadsheets/${sheetIdAttendance}/values:batchUpdate`,
            {
                method: 'POST',
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    valueInputOption: 'RAW',
                    data: updates
                })
            }
        );

        if (!batchUpdateResponse.ok) {
            const errorData = await batchUpdateResponse.json();
            console.error('Batch update response error:', errorData);
            throw new Error(`Failed to update attendance data: ${errorData.error?.message || 'Unknown error'}`);
        }

        let message = `✅ Attendance recorded for ${employeeName} in Google Sheet:\n\n`;
        attendanceData.forEach(entry => {
            message += `Date: ${entry.date}\nCheck-In: ${to12HourFormat(entry.checkIn || 'N/A')}\nCheck-Out: ${to12HourFormat(entry.checkOut || 'N/A')}\n\n`;
        });
        alert(message);
        console.log('Attendance data successfully uploaded:', updates);

        const form = document.getElementById('attendanceForm');
        const inputs = form.querySelectorAll('input[type="time"]');
        inputs.forEach(input => input.value = '');
        console.log('Cleared form inputs after submission.');
        await loadAttendanceData(employeeName, token, true, month, year);

    } catch (error) {
        console.error('⚠️ Error in submitAttendance:', error);
        alert(`Error: ${error.message || 'An unexpected error occurred while uploading to Google Sheets. Check console for details.'}`);
    }
}