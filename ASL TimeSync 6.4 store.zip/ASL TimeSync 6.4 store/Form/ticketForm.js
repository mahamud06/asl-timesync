function disableConsoleLog() {
    console.log = function() {};
}
// Call disableConsoleLog() to disable console logging
disableConsoleLog();

async function getFingerIdFromSheet(username) {
    return new Promise(async (resolve, reject) => {
        chrome.storage.local.get(['sheetId2', 'apiKey'], async (result) => {
            const sheetId = result.sheetId2;
            const apiKey = result.apiKey || "AIzaSyDIuRc7QsUTJ8C5-0yzXeY9bM79-jxyTFY"; // Ensure a fallback API key

            if (!sheetId) {
                return reject(new Error("Sheet ID not found for Finger ID retrieval."));
            }

            const sheetName = "Employee_Management";
            const range = "A:F"; // Assuming Username is in column A and Finger ID is in column F
            const url = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${encodeURIComponent(sheetName)}!${range}?key=${apiKey}`;

            try {
                const response = await fetch(url);
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const data = await response.json();

                if (data.values && data.values.length > 1) { // Assuming first row is headers
                    const rows = data.values;
                    const usernameColumnIndex = 0; // Assuming username is in column A (index 0)
                    const fingerIdColumnIndex = 4; // Assuming Finger ID is in column E (index 4)

                    for (let i = 1; i < rows.length; i++) { // Start from the second row to skip headers
                        const rowUsername = rows[i][usernameColumnIndex]?.toUpperCase();
                        if (rowUsername === username?.toUpperCase()) {
                            const fingerId = rows[i][fingerIdColumnIndex];
                            return resolve(fingerId || ""); // Resolve with the finger ID or an empty string if not found
                        }
                    }
                    resolve(""); // Username not found
                } else {
                    resolve(""); // No data or only headers
                }
            } catch (error) {
                console.error("Error fetching Finger ID:", error);
                reject(error);
            }
        });
    });
}


async function displayReportedDataTicket() {
    const dataDisplayBox = document.getElementById("historyContent");
    dataDisplayBox.innerHTML = "Loading...";

    chrome.storage.local.get("username", async (userResult) => {
        const username = userResult.username?.toUpperCase();
        if (!username) {
            dataDisplayBox.innerHTML = "Please login to view your submissions.";
            return;
        }

        try {
            const result = await new Promise((resolve) => {
                chrome.storage.local.get(['sheetId2', 'apiKey'], (result) => {
                    resolve(result);
                });
            });
            const sheetId = result.sheetId2;
            const apiKey = result.apiKey || "AIzaSyDIuRc7QsUTJ8C5-0yzXeY9bM79-jxyTFY";

            if (!sheetId) {
                throw new Error("Sheet ID not found in storage.");
            }

            const sheetName = "SALARY ISSUES";
            const url = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${encodeURIComponent(sheetName)}?key=${apiKey}`;

            const response = await fetch(url);
            const resultData = await response.json();

            if (!resultData.values || resultData.values.length === 0) {
                dataDisplayBox.innerHTML = "No data found.";
                return;
            }

            const [headers, ...rows] = resultData.values;
            const filteredRows = rows.filter(row => row[0]?.toUpperCase() === username);

            if (filteredRows.length === 0) {
                dataDisplayBox.innerHTML = `<div style="text-align: center;">No reported data found for your account.</div>`;
                return;
            }

            filteredRows.sort((a, b) => {
                const dateA = new Date(a[1] || "1/1/1970");
                const dateB = new Date(b[1] || "1/1/1970");
                return dateB - dateA;
            });

            let tableHTML = "<table border='1' cellpadding='5' cellspacing='0' style='width: 100%; border-collapse: collapse;'>";
            // RESTORED: Original ticketHeaders and columnIndices (without Finger ID) for the table display
            const ticketHeaders = ["Username", "Timestamp", "Issue Topic", "Effective Date", "Description", "Attachment", "Status", "Remark"];
            const columnIndices = [0, 1, 6, 7, 2, 3, 4, 5]; // Original indices for table display
            tableHTML += "<thead><tr style='background-color: #f9f9f9;'>" +
                ticketHeaders.map(h => `<th>${h}</th>`).join("") +
                `<th class="action-column">Action</th></tr></thead>`;
            tableHTML += "<tbody>";
            filteredRows.forEach((row, index) => {
                tableHTML += "<tr>" + columnIndices.map((colIndex, i) => {
                    const cellData = row[colIndex] || "";
                    const truncatedData = cellData.length > 10 ? cellData.substring(0, 10) + "..." : cellData;
                    if (i === 5 && cellData.startsWith("http")) { // Attachment column (index 5 in original headers)
                        return `<td style="text-align: center;"><a href="${cellData}" target="_blank" style="color: blue;">View</a></td>`;
                    }
                    return `<td>${truncatedData}</td>`;
                }).join("") +
                `<td class="action-column"><a href="#" class="view-details" data-row="${index}" data-form-type="ticket" style="color: blue;">View Details</a></td></tr>`;
            });
            tableHTML += "</tbody></table>";

            dataDisplayBox.innerHTML = tableHTML;

            const modal = document.getElementById("leaveDetailModal");
            const modalContent = document.getElementById("modalContent");
            const closeBtn = document.querySelector(".close-btn");

            document.querySelectorAll(".view-details").forEach(link => {
                link.addEventListener("click", (e) => {
                    e.preventDefault();
                    const rowIndex = parseInt(e.target.getAttribute("data-row"));
                    const formType = e.target.getAttribute("data-form-type");
                    const row = filteredRows[rowIndex];

                    let modalHTML = `<div style="position: relative;">`;
                    // Kept: fullHeaders and modalIndices to include "Finger ID" for modal, positioned after Username
                    const fullHeaders = ["Username", "Finger ID", "Timestamp", "Issue Topic", "Effective Date", "Description", "Attachment", "Status", "Remark"];
                    // Adjusted order for modal display to put Finger ID after Username
                    const modalIndices = [0, 8, 1, 6, 7, 2, 3, 4, 5]; // Finger ID is at index 8 in the submitted row data

                    fullHeaders.forEach((header, i) => {
                        let cellData = row[modalIndices[i]] || "";
                        if (header === "Description") {
                            cellData = cellData.replace(/\n/g, "<br>");
                        }
                        if (header === "Attachment") {
                            if (cellData.startsWith("http")) {
                                const fileIdMatch = cellData.match(/\/d\/([a-zA-Z0-9_-]{33})\/view/);
                                if (fileIdMatch && fileIdMatch[1]) {
                                    const fileId = fileIdMatch[1];
                                    modalHTML += `
                                        <p>
                                            <strong>${header}:</strong>
                                            <img src="https://drive.google.com/thumbnail?id=${fileId}&sz=w100"
                                                 style="width: 100px; height: auto; border: 1px solid #ccc; margin: 5px;"
                                                 class="loading"
                                                 onload="this.classList.remove('loading');"
                                                 onerror="this.src='https://via.placeholder.com/100?text=Image+Not+Available';this.classList.remove('loading');console.error('Thumbnail load failed for URL: ${cellData}');">
                                            <a href="${cellData}" target="_blank" style="color: blue;">View Full File</a>
                                        </p>`;
                                } else {
                                    console.error("Invalid Google Drive URL:", cellData);
                                    modalHTML += `<p><strong>${header}:</strong> <a href="${cellData}" target="_blank" style="color: blue;">View File</a></p>`;
                                }
                            } else {
                                modalHTML += `<p><strong>${header}:</strong> No attachment</p>`;
                            }
                        } else {
                            modalHTML += `<p><strong>${header}:</strong> ${cellData}</p>`;
                        }
                    });

                    modalHTML += `
                        <button id="printDetailsBtn" style="position: absolute; top: 10px; right: 10px; padding: 5px 10px; font-size: 14px; background-color: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer;">
                            Print/Save as PDF
                        </button>
                    `;
                    modalHTML += `</div>`;

                    modalContent.innerHTML = modalHTML;
                    modal.style.display = "flex";

                    const printBtn = document.getElementById("printDetailsBtn");
                    printBtn.addEventListener("click", () => {
                        const printContent = modalContent.cloneNode(true);
                        printContent.querySelector("#printDetailsBtn").remove();

                        const printWindow = window.open('', '_blank');
                        printWindow.document.write(`
                            <html>
                                <head>
                                    <title>Ticket Details</title>
                                    <style>
                                        body { font-family: Arial, sans-serif; padding: 20px; }
                                        p { margin: 10px 0; }
                                        strong { display: inline-block; width: 150px; }
                                        img { max-width: 100px; height: auto; border: 1px solid #ccc; margin: 5px; }
                                    </style>
                                </head>
                                <body>
                                    <div id="printContent">${printContent.innerHTML}</div>
                                    <script>
                                        window.print();
                                    </script>
                                </body>
                            </html>
                        `);
                        printWindow.document.close();
                    });
                });
            });

            closeBtn.removeEventListener("click", closeModal);
            closeBtn.addEventListener("click", closeModal);

            window.removeEventListener("click", windowClickHandler);
            window.addEventListener("click", windowClickHandler);

            function closeModal() {
                modal.style.display = "none";
            }

            function windowClickHandler(e) {
                if (e.target === modal) {
                    modal.style.display = "none";
                }
            }
        } catch (error) {
            console.error("Error loading reported data:", error);
            dataDisplayBox.innerHTML = "Failed to load data.";
        }
    });
}

document.addEventListener("DOMContentLoaded", () => {
    populateUsernameFromStorage(); // This function should be defined elsewhere (e.g., control.js)
    displayReportedDataTicket();

    const ticketForm = document.getElementById("ticketForm");
    const leaveForm = document.getElementById("leaveForm");
    const salaryRecalculationForm = document.getElementById("salaryRecalculationForm");
    const ticketHistoryBox = document.getElementById("ticketHistoryBox");
    const leaveHistoryBox = document.getElementById("leaveHistoryBox");
    const salaryHistoryBox = document.getElementById("salaryHistoryBox");
    const submitTicketBtn = document.getElementById("submitTicketBtn");
    const paidLeaveBtn = document.getElementById("paidLeaveBtn");
    const salaryRecalculationBtn = document.getElementById("salaryRecalculationBtn");
    const adminLoginBtn = document.getElementById("adminLoginBtn");
    const viewsalarysheet = document.getElementById("allSalarySheetBtn");
    const uploadBtn = document.getElementById("uploadBtn");
    const status = document.getElementById("status");
    const statsTableContainer = document.querySelector(".stats-table-container");
    const eligibilityIndicator = document.getElementById("eligibilityIndicator");
    const issueUsernameInput = document.getElementById("issueUsername");
    const fingerIdInput = document.getElementById("fingerId");

    // Function to populate username and then fetch Finger ID
    async function setupTicketForm() {
        chrome.storage.local.get("username", async (userResult) => {
            const username = userResult.username || "";
            issueUsernameInput.value = username;

            if (username) {
                try {
                    const fingerId = await getFingerIdFromSheet(username);
                    fingerIdInput.value = fingerId;
                } catch (error) {
                    console.error("Error fetching Finger ID for current user:", error);
                    fingerIdInput.value = "Error fetching ID"; // Indicate an error
                }
            }
        });
    }

    // Call the setup function when the DOM is ready
    setupTicketForm();

    getAgentPermission() // This function should be defined elsewhere (e.g., control.js)
        .then(permission => {
            const allowedRoles = ["admin", "manager", "teamcoordinator", "hr", "teamlead", "ceo", "assistant", "accountant"];
            if (allowedRoles.includes(permission?.toLowerCase())) {
                adminLoginBtn.classList.remove("hidden");
            }
        })
        .catch(error => {
            console.error("Error checking permission:", error);
        });

    submitTicketBtn.addEventListener("click", () => {
        ticketForm.classList.remove("hidden");
        leaveForm.classList.add("hidden");
        salaryRecalculationForm.classList.add("hidden");
        ticketHistoryBox.classList.remove("hidden");
        leaveHistoryBox.classList.add("hidden");
        salaryHistoryBox.classList.add("hidden");
        statsTableContainer.classList.add("hidden");
        eligibilityIndicator.classList.add("hidden");
        displayReportedDataTicket();
        setupTicketForm(); // Re-fetch Finger ID in case username changed
    });

    paidLeaveBtn.addEventListener("click", () => {
        ticketForm.classList.add("hidden");
        leaveForm.classList.remove("hidden");
        salaryRecalculationForm.classList.add("hidden");
        ticketHistoryBox.classList.add("hidden");
        leaveHistoryBox.classList.remove("hidden");
        salaryHistoryBox.classList.add("hidden");
        statsTableContainer.classList.remove("hidden");
        eligibilityIndicator.classList.remove("hidden");
        displayReportedDataLeave(); // This function should be defined elsewhere (e.g., leaveForm.js)
        fetchLeaveStats(); // This function should be defined elsewhere (e.g., leaveForm.js)
    });

    salaryRecalculationBtn.addEventListener("click", () => {
        ticketForm.classList.add("hidden");
        leaveForm.classList.add("hidden");
        salaryRecalculationForm.classList.remove("hidden");
        ticketHistoryBox.classList.add("hidden");
        leaveHistoryBox.classList.add("hidden");
        salaryHistoryBox.classList.remove("hidden");
        statsTableContainer.classList.add("hidden");
        eligibilityIndicator.classList.add("hidden");
        displaySalaryRecalculationData(); // This function should be defined elsewhere (e.g., salaryRecalculation.js)
    });

    adminLoginBtn.addEventListener("click", () => {
        window.open("Dashboard/admin_dashboard.html", "_blank");
    });
	
	    viewsalarysheet.addEventListener("click", () => {
        window.open("Dashboard/View_salaey.html", "_blank");
    });


uploadBtn.addEventListener("click", async () => {
    chrome.storage.local.get("username", async (userResult) => {
        const username = (userResult.username || "").trim();
        const fingerId = document.getElementById("fingerId").value.trim(); // Get fingerId
        const issueTopic = document.getElementById("issueTopic").value.trim();
        const ticketEffectiveDate = document.getElementById("ticketEffectiveDate").value.trim();
        const description = document.getElementById("issueDescription").value.trim();
        const file = document.getElementById("fileInput").files[0];

        if (!username || !fingerId || !issueTopic || !ticketEffectiveDate || !description) { // Add fingerId to validation
            showStatus(status, "Please fill in all required fields: Username, Finger ID, Issue Topic, Effective Date, and Description.", "red");
            return;
        }

        showStatus(status, "Submitting your issue, please wait...", "blue");

        chrome.identity.getAuthToken({ interactive: true }, async (token) => {
            if (chrome.runtime.lastError || !token) {
                showStatus(status, "Authentication failed: " + chrome.runtime.lastError?.message, "red");
                return;
            }

            try {
                let imageUrl = "";
                if (file) {
                    const uploaded = await uploadToDrive(token, file); // This function should be defined elsewhere
                    imageUrl = `https://drive.google.com/file/d/${uploaded.id}/view`;
                }

                // --- CHANGE STARTS HERE ---
                const now = new Date();
                const formattedTimestamp = now.toLocaleString('en-US', {
                    month: '2-digit',
                    day: '2-digit',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: true // Ensures AM/PM
                });
                // --- CHANGE ENDS HERE ---

                // Ensure the order matches the sheet columns:
                // Username, Timestamp, Description, Attachment, Status, Remark, Issue Topic, Effective Date, Finger ID
                // The order here should match your "SALARY ISSUES" sheet columns.
                // If your sheet has Finger ID as the 9th column (index 8), this is correct.
                const values = [username, formattedTimestamp, description, imageUrl, "Pending", "", issueTopic, ticketEffectiveDate, fingerId];
                await appendToSheet(token, "ticket", values); // This function should be defined elsewhere
                showStatus(status, "Issue submitted successfully.", "green");

                // Clear form fields
                document.getElementById("issueTopic").value = "";
                document.getElementById("ticketEffectiveDate").value = "";
                document.getElementById("issueDescription").value = "";
                document.getElementById("fileInput").value = "";
                // Keep username and fingerId as they are auto-populated
                displayReportedDataTicket();
            } catch (error) {
                console.error("Error:", error);
                showStatus(status, `Error: ${error.message}`, "red");
            }
        });
    });
});
	
	
});