     function disableConsoleLog() {
    console.log = function() {};
}
// Call disableConsoleLog() to disable console logging
disableConsoleLog();


async function showModalLeave(row, sheetRowIndex, userPermission) {
  const modal = document.getElementById("detailModal");
  const modalContent = document.getElementById("modalContent");
  const headers = ["Username", "Full Name", "Leave Type", "Timestamp", "Effective Date", "Number of Days", "Department", "Designation", "Subject", "Description", "Attachment", "Total Availed", "Outstanding", "Status", "Remark", "Assistant Remark"];
  let modalHTML = `<div style="position: relative;">`;

  headers.forEach((header, i) => {
    if (i === 15) return; // Skip Assistant Remark for now, as it's handled separately
    if (i === 6 || i === 7) {
      if (i === 6) {
        modalHTML += `<div class="modal-input-row">`;
        modalHTML += `<div><label>${headers[6]}:</label> <span>${row[6] || ""}</span></div>`;
        modalHTML += `<div><label>${headers[7]}:</label> <span>${row[7] || ""}</span></div>`;
        modalHTML += `</div>`;
      }
    } else {
      const cellData = row[i] || "";
      if (i === 10) {
        if (cellData.startsWith("http")) {
          const fileIdMatch = cellData.match(/\/d\/([a-zA-Z0-9_-]{33})\/view/);
          if (fileIdMatch && fileIdMatch[1]) {
            const fileId = fileIdMatch[1];
            modalHTML += `
              <p>
                <strong>${header}:</strong>
                <img src="https://drive.google.com/thumbnail?id=${fileId}&sz=w100" 
                     style="width: 100px; height: auto; border: 1px solid #ccc; margin: 5px;" 
                     class="loading" 
                     onload="this.classList.remove('loading');" 
                     onerror="this.src='https://via.placeholder.com/100?text=Image+Not+Available';this.classList.remove('loading');console.error('Thumbnail load failed for URL: ${cellData}');">
                <a href="${cellData}" target="_blank" style="color: blue;">View Full File</a>
              </p>`;
          } else {
            console.error("Invalid Google Drive URL:", cellData);
            modalHTML += `<p><strong>${header}:</strong> <a href="${cellData}" target="_blank" style="color: blue;">View File</a></p>`;
          }
        } else {
          modalHTML += `<p><strong>${header}:</strong> No attachment</p>`;
        }
      } else if (header === "Description") {
        modalHTML += `
          <p>
            <strong>${header}:</strong>
            <div style="white-space: pre-wrap; display: inline-block;">${cellData}</div>
          </p>`;
      } else {
        modalHTML += `<p><strong>${header}:</strong> ${cellData}</p>`;
      }
    }
  });

  modalHTML += `
    <button id="printDetailsBtn" style="position: absolute; top: 10px; right: 10px; padding: 5px 10px; font-size: 14px; background-color: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer;">
      Print/Save as PDF
    </button>
  `;
  modalHTML += `</div>`;

  modalContent.innerHTML = modalHTML;
  const statusSelect = document.getElementById("statusSelect");
  const remarkInput = document.getElementById("remarkInput");
  const updateStatusBtn = document.getElementById("updateStatusBtn");
  const currentStatus = row[13] || "Pending";
  const currentRemark = row[14] || "";
  const currentAssistantRemark = row[15] || "";

  const existingStatusText = document.getElementById("statusText");
  const existingRemarkText = document.getElementById("remarkText");
  const existingAssistantRemarkInput = document.getElementById("assistantRemarkInput");
  if (existingStatusText) existingStatusText.remove();
  if (existingRemarkText) existingRemarkText.remove();
  if (existingAssistantRemarkInput) existingAssistantRemarkInput.remove();

  const statusOptions = [
    "Pending",
    "Approved by Admin",
    "Approved by HR",
    "Approved by Manager",
    "Approved by CEO",
    "Approved by Teamlead",
    "Approved by Team Coordinator",
    "Rejected by Admin",
    "Rejected by HR",
    "Rejected by Manager",
    "Rejected by CEO",
    "Rejected by Teamlead",
    "Rejected by Team Coordinator"
  ];

  const permissionTiers = {
    admin: 1,
    ceo: 2,
    manager: 3,
    hr: 4,
    teamlead: 5,
    teamcoordinator: 6,
    accountant: 7,
    assistant: 7,
    viewer: 8
  };

  const statusToTier = {
    "Approved by Admin": 1,
    "Rejected by Admin": 1,
    "Approved by CEO": 2,
    "Rejected by CEO": 2,
    "Approved by Manager": 3,
    "Rejected by Manager": 3,
    "Approved by HR": 4,
    "Rejected by HR": 4,
    "Approved by Teamlead": 5,
    "Rejected by Teamlead": 5,
    "Approved by Team Coordinator": 6,
    "Rejected by Team Coordinator": 6,
    "Pending": 7
  };

  const currentStatusTier = statusToTier[currentStatus] || 7;
  const userTier = permissionTiers[userPermission] || 8;
  let canUpdate = false;
  if (["admin", "ceo", "manager", "hr", "teamlead", "teamcoordinator"].includes(userPermission)) {
    canUpdate = currentStatusTier >= userTier;
  } else if (userPermission === "assistant") {
    canUpdate = true;
  }

  if (userPermission === "admin" && canUpdate) {
    statusSelect.innerHTML = statusOptions.map(opt => `<option value="${opt}">${opt}</option>`).join("");
    statusSelect.value = currentStatus;
    statusSelect.disabled = false;
    statusSelect.style.display = "inline-block";
    remarkInput.value = currentRemark;
    remarkInput.style.display = "inline-block";
    remarkInput.disabled = false;
    updateStatusBtn.style.display = "inline-block";
    updateStatusBtn.disabled = false;
  } else if (userPermission === "hr" && canUpdate) {
    statusSelect.innerHTML = [
      `<option value="Approved by HR">Approved by HR</option>`,
      `<option value="Rejected by HR">Rejected by HR</option>`
    ].join("");
    statusSelect.value = ["Approved by HR", "Rejected by HR"].includes(currentStatus) ? currentStatus : "Approved by HR";
    statusSelect.disabled = false;
    statusSelect.style.display = "inline-block";
    remarkInput.value = currentRemark;
    remarkInput.style.display = "inline-block";
    remarkInput.disabled = false;
    updateStatusBtn.style.display = "inline-block";
    updateStatusBtn.disabled = false;
  } else if (userPermission === "manager" && canUpdate) {
    statusSelect.innerHTML = [
      `<option value="Approved by Manager">Approved by Manager</option>`,
      `<option value="Rejected by Manager">Rejected by Manager</option>`
    ].join("");
    statusSelect.value = ["Approved by Manager", "Rejected by Manager"].includes(currentStatus) ? currentStatus : "Approved by Manager";
    statusSelect.disabled = false;
    statusSelect.style.display = "inline-block";
    remarkInput.value = currentRemark;
    remarkInput.style.display = "inline-block";
    remarkInput.disabled = false;
    updateStatusBtn.style.display = "inline-block";
    updateStatusBtn.disabled = false;
  } else if (userPermission === "ceo" && canUpdate) {
    statusSelect.innerHTML = [
      `<option value="Approved by CEO">Approved by CEO</option>`,
      `<option value="Rejected by CEO">Rejected by CEO</option>`
    ].join("");
    statusSelect.value = ["Approved by CEO", "Rejected by CEO"].includes(currentStatus) ? currentStatus : "Approved by CEO";
    statusSelect.disabled = false;
    statusSelect.style.display = "inline-block";
    remarkInput.value = currentRemark;
    remarkInput.style.display = "inline-block";
    remarkInput.disabled = false;
    updateStatusBtn.style.display = "inline-block";
    updateStatusBtn.disabled = false;
  } else if (userPermission === "teamlead" && canUpdate) {
    statusSelect.innerHTML = [
      `<option value="Approved by Teamlead">Approved by Teamlead</option>`,
      `<option value="Rejected by Teamlead">Rejected by Teamlead</option>`
    ].join("");
    statusSelect.value = ["Approved by Teamlead", "Rejected by Teamlead"].includes(currentStatus) ? currentStatus : "Approved by Teamlead";
    statusSelect.disabled = false;
    statusSelect.style.display = "inline-block";
    remarkInput.value = currentRemark;
    remarkInput.style.display = "inline-block";
    remarkInput.disabled = false;
    updateStatusBtn.style.display = "inline-block";
    updateStatusBtn.disabled = false;
  } else if (userPermission === "teamcoordinator" && canUpdate) {
    statusSelect.innerHTML = [
      `<option value="Approved by Team Coordinator">Approved by Team Coordinator</option>`,
      `<option value="Rejected by Team Coordinator">Rejected by Team Coordinator</option>`
    ].join("");
    statusSelect.value = ["Approved by Team Coordinator", "Rejected by Team Coordinator"].includes(currentStatus) ? currentStatus : "Approved by Team Coordinator";
    statusSelect.disabled = false;
    statusSelect.style.display = "inline-block";
    remarkInput.value = currentRemark;
    remarkInput.style.display = "inline-block";
    remarkInput.disabled = false;
    updateStatusBtn.style.display = "inline-block";
    updateStatusBtn.disabled = false;
  } else if (userPermission === "accountant") {
    statusSelect.style.display = "none";
    remarkInput.style.display = "none";

    updateStatusBtn.style.display = "none";
  } else if (userPermission === "assistant") {
    statusSelect.style.display = "none";
    remarkInput.style.display = "none";
    const assistantRemarkInput = document.createElement("input");
    assistantRemarkInput.id = "assistantRemarkInput";
    assistantRemarkInput.type = "text";
    assistantRemarkInput.value = currentAssistantRemark;
    assistantRemarkInput.placeholder = "Enter assistant remark (optional)";
    remarkInput.parentNode.insertBefore(assistantRemarkInput, remarkInput);
    updateStatusBtn.style.display = "inline-block";
    updateStatusBtn.disabled = false;
  } else {
    statusSelect.innerHTML = `<option value="${currentStatus}">${currentStatus}</option>`;
    statusSelect.disabled = true;
    statusSelect.style.display = "inline-block";
    remarkInput.value = currentRemark;
    remarkInput.style.display = "inline-block";
    remarkInput.disabled = true;
    updateStatusBtn.style.display = "none";
  }

  const printBtn = document.getElementById("printDetailsBtn");
  if (printBtn) {
    printBtn.addEventListener("click", () => {
      const printContent = modalContent.cloneNode(true);
      printContent.querySelector("#printDetailsBtn")?.remove();
      printContent.querySelector("#statusSelect")?.remove();
      printContent.querySelector("#remarkInput")?.remove();
      printContent.querySelector("#assistantRemarkInput")?.remove();
      printContent.querySelector("#updateStatusBtn")?.remove();
      printContent.querySelector("#statusText")?.remove();
      printContent.querySelector("#remarkText")?.remove();

      const printWindow = window.open('', '_blank');
      printWindow.document.write(`
        <html>
          <head>
            <title>Leave Application Details</title>
            <style>
              body { font-family: Arial, sans-serif; padding: 20px; }
              p { margin: 10px 0; }
              strong { display: inline-block; width: 150px; }
              img { max-width: 100px; height: auto; border: 1px solid #ccc; margin: 5px; }
              .modal-input-row { display: flex; gap: 20px; }
              .modal-input-row div { flex: 1; }
              div[style*="white-space: pre-wrap"] { max-width: 500px; }
            </style>
          </head>
          <body>
            <div id="printContent">${printContent.innerHTML}</div>
            <script>
              window.print();
            </script>
          </body>
        </html>
      `);
      printWindow.document.close();
    });
  }
  modal.style.display = "flex";

  updateStatusBtn.onclick = async () => {
    const status = statusSelect.style.display === "none" ? currentStatus : statusSelect.value;
    const remark = remarkInput.style.display !== "none" ? remarkInput.value.trim() : undefined;
    const assistantRemark = document.getElementById("assistantRemarkInput") ? document.getElementById("assistantRemarkInput").value.trim() : undefined;

    const allowedStatuses = {
      admin: statusOptions,
      hr: ["Approved by HR", "Rejected by HR"],
      manager: ["Approved by Manager", "Rejected by Manager"],
      ceo: ["Approved by CEO", "Rejected by CEO"],
      teamlead: ["Approved by Teamlead", "Rejected by Teamlead"],
      teamcoordinator: ["Approved by Team Coordinator", "Rejected by Team Coordinator"]
    };

    if (userPermission === "assistant") {
      if (assistantRemark === undefined) {
        alert("Please enter an assistant remark.");
        return;
      }
    } else if (!["admin", "hr", "manager", "ceo", "teamlead", "teamcoordinator"].includes(userPermission)) {
      alert("You do not have permission to update status or remarks.");
      return;
    } else if (!allowedStatuses[userPermission].includes(status)) {
      alert(`You can only set status to ${allowedStatuses[userPermission].join(" or ")}.`);
      return;
    } else if (!canUpdate) {
      alert("You cannot update this entry as it has been processed by a higher tier.");
      return;
    }

    try {
      const token = await new Promise((resolve, reject) => {
        chrome.identity.getAuthToken({ interactive: true }, (token) => {
          if (chrome.runtime.lastError || !token) {
            reject(new Error(chrome.runtime.lastError?.message || "Authentication failed"));
          } else {
            resolve(token);
          }
        });
      });

      await updateSheet(token, "leave", sheetRowIndex, status, userPermission === "assistant" ? assistantRemark : remark, userPermission);
      alert(userPermission === "assistant" ? "Assistant remark updated successfully." : "Status and remark updated successfully.");
      modal.style.display = "none";
      displayDataLeave(document.getElementById("usernameFilter").value, document.getElementById("statusFilter").value, document.getElementById("leaveTypeFilter").value, document.getElementById("departmentFilter").value, document.getElementById("monthFilter").value, userPermission);
    } catch (error) {
      console.error(`Error updating ${userPermission === "assistant" ? "assistant remark" : "status and remark"}:`, error);
      alert(`Error updating ${userPermission === "assistant" ? "assistant remark" : "status and remark"}: ${error.message}`);
    }
  };
}

async function displayDataLeave(usernameFilter = "", statusFilter = "", leaveTypeFilter = "", departmentFilter = "", monthFilter = "", userPermission = "") {
  const tableBody = document.querySelector("#leaveTable tbody");
  const allowedRoles = ["admin", "hr", "manager", "ceo", "teamlead", "teamcoordinator", "accountant", "assistant"];
  if (!allowedRoles.includes(userPermission)) {
    tableBody.innerHTML = "<tr><td colspan='13'>No permission to view data.</td></tr>";
    return;
  }

  const rows = await fetchData("leave");
  let filteredRows = rows;

  if (usernameFilter) {
    filteredRows = filteredRows.filter(row => row.data[0]?.toUpperCase().includes(usernameFilter.toUpperCase()));
  }
  if (statusFilter) {
    filteredRows = filteredRows.filter(row => row.data[13] === statusFilter);
  }
  if (leaveTypeFilter) {
    filteredRows = filteredRows.filter(row => row.data[2] === leaveTypeFilter);
  }
  if (departmentFilter) {
    filteredRows = filteredRows.filter(row => row.data[6]?.toUpperCase().includes(departmentFilter.toUpperCase()));
  }
  if (monthFilter) {
    const [monthName, year] = monthFilter.split("_");
    const monthIndex = [
      "January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"
    ].indexOf(monthName);
    const targetYear = parseInt(year);
    filteredRows = filteredRows.filter(row => {
      const dateInfo = getMonthYearFromTimestamp(row.data[3]);
      if (!dateInfo) return false;
      return dateInfo.month === monthIndex && dateInfo.year === targetYear;
    });
  }

  if (filteredRows.length === 0) {
    tableBody.innerHTML = "<tr><td colspan='14'>No matching data found.</td></tr>"; // Adjusted colspan
    return;
  }

  tableBody.innerHTML = "";
  filteredRows.forEach((row, index) => {
    const tr = document.createElement("tr");
    const cells = [
      index + 1, // S/N
      row.data[0] || "", // Username
      row.data[1] || "", // Full Name
      row.data[2] || "", // Leave Type
      row.data[3] || "", // Timestamp
      row.data[4] || "", // Effective Date
      row.data[5] || "", // Number of Days
      row.data[8] || "", // Subject
      row.data[10] ? `<a href="${row.data[10]}" target="_blank">View</a>` : "", // Attachment
      row.data[13] || "", // Status
      row.data[14] || "", // Remark
      row.data[15] || "", // Approved Paid Days
      ["admin", "hr", "manager", "ceo", "teamlead", "teamcoordinator", "accountant", "assistant"].includes(userPermission)
        ? `<span class="${iconConfig.edit.class}" style="${iconConfig.edit.style}" data-row="${index}" data-sheet-row="${row.sheetRowIndex}" data-type="leave" aria-label="Edit entry">${iconConfig.edit.content}</span>`
        : "", // Edit
      userPermission === "admin"
        ? `<span class="${iconConfig.delete.class}" style="${iconConfig.delete.style}" data-row="${index}" data-sheet-row="${row.sheetRowIndex}" data-type="leave" aria-label="Delete entry">${iconConfig.delete.content}</span>`
        : "" // Delete
    ];
    tr.innerHTML = cells.map(cell => `<td>${cell}</td>`).join("");
    tableBody.appendChild(tr);
  });

  document.querySelectorAll(".edit-action").forEach(action => {
    action.addEventListener("click", (e) => {
      e.preventDefault();
      const rowIndex = parseInt(e.target.getAttribute("data-row"));
      const sheetRowIndex = parseInt(e.target.getAttribute("data-sheet-row"));
      const row = filteredRows[rowIndex].data;
      showModalLeave(row, sheetRowIndex, userPermission);
    });
  });

  document.querySelectorAll(".delete-action").forEach(action => {
    action.addEventListener("click", async (e) => {
      e.preventDefault();
      const rowIndex = parseInt(e.target.getAttribute("data-row"));
      const sheetRowIndex = parseInt(e.target.getAttribute("data-sheet-row"));

      if (userPermission !== "admin") {
        alert("Only Admins can delete entries.");
        return;
      }

      if (!confirm("Are you sure you want to delete this leave application? This action cannot be undone.")) {
        return;
      }

      try {
        const token = await new Promise((resolve, reject) => {
          chrome.identity.getAuthToken({ interactive: true }, (token) => {
            if (chrome.runtime.lastError || !token) {
              reject(new Error(chrome.runtime.lastError?.message || "Authentication failed"));
            } else {
              resolve(token);
            }
          });
        });

        await deleteSheetRow(token, "leave", sheetRowIndex);
        alert("Leave application deleted successfully.");
        displayDataLeave(document.getElementById("usernameFilter").value, document.getElementById("statusFilter").value, document.getElementById("leaveTypeFilter").value, document.getElementById("departmentFilter").value, document.getElementById("monthFilter").value, userPermission);
      } catch (error) {
        console.error("Error deleting leave application:", error);
        alert(`Error deleting leave application: ${error.message}`);
      }
    });
  });
}