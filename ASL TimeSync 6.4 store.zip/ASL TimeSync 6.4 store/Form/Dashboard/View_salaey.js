// ------------------------------------------------------------
// salaryDashboard.js – VIEWER MODE: "Please wait..." message
// ------------------------------------------------------------
const API_KEY = "AIzaSyDIuRc7QsUTJ8C5-0yzXeY9bM79-jxyTFY";
const FOLDER_ID = "1JY0Bh4p_7YX_d5YNVtSb5cojKuHXfIt9";
let employeeRows = [];
let filteredRows = [];
let currentUsername = "";
let currentUserFromStorage = "";
let currentUserLevel = 999;
let currentEmployeeFullName = "";
let viewerAllowedMonths = [];
let employeeSalaryRow = []; // New global variable to store the employee's salary row data

// DOM Elements
const empList = document.getElementById("employee-list");
const monthsGrid = document.getElementById("months-grid");
const rightPanel = document.getElementById("right-panel");
const selectPrompt = document.getElementById("select-prompt");
const searchInput = document.getElementById("search-input");
const clearSearch = document.getElementById("clear-search");
const deptFilter = document.getElementById("dept-filter");
const monthFilter = document.getElementById("month-visibility-filter");
const clearMonthsBtn = document.getElementById("clear-months-filter");
const rightPanelLoader = document.getElementById("right-panel-loader");
const MONTHS = [
  "Nov 2025","Dec 2025",
  "Jan 2026","Feb 2026","Mar 2026","Apr 2026","May 2026","Jun 2026",
  "Jul 2026","Aug 2026","Sep 2026","Oct 2026","Nov 2026","Dec 2026"
];

// ------------------------------------------------------------
// UTILITY FUNCTIONS 
// ------------------------------------------------------------

/**
 * Utility to convert 0-based column index (0=A, 25=Z, 26=AA) to Excel column letter.
 * FIX for 'Unable to parse range' error on columns past Z.
 */
function getColumnLetter(colIndex) {
    let result = '';
    while (colIndex >= 0) {
        // Find remainder (0-25)
        const remainder = colIndex % 26;
        // Convert to character ('A' + remainder)
        result = String.fromCharCode(65 + remainder) + result;
        // Move to the next "digit"
        colIndex = Math.floor(colIndex / 26) - 1;
    }
    return result;
}

/**
 * Fetches the file name from Google Drive using the file ID.
 */
async function getDriveFileDetails(driveLink) {
    const fileId = getDriveFileId(driveLink);
    if (!fileId) return { fileName: null };
    const token = await getAuthToken();
    // Use v3 API for file metadata
    const url = `https://www.googleapis.com/drive/v3/files/${fileId}?fields=name&key=${API_KEY}`; 
    try {
        const response = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
        if (!response.ok) {
            console.warn("Could not fetch file details from Drive API.");
            return { fileName: null };
        }
        const data = await response.json();
        return { fileName: data.name };
    } catch (e) {
        console.warn("Failed to fetch Drive file name. Error:", e);
        return { fileName: null };
    }
}

async function fetchViewerAllowedMonths(sheetId, token) {
  try {
    const response = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/Credential!G10?key=${API_KEY}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    if (!response.ok) return [];
    const data = await response.json();
    const cellValue = (data.values?.[0]?.[0] || "").trim();
    if (!cellValue) return [];
    const parts = cellValue.split(",").map(s => s.trim());
    const allowed = [];
    const monthMap = {
      "1": "Jan", "2": "Feb", "3": "Mar", "4": "Apr", "5": "May", "6": "Jun",
      "7": "Jul", "8": "Aug", "9": "Sep", "10": "Oct", "11": "Nov", "12": "Dec",
      "01": "Jan", "02": "Feb", "03": "Mar", "04": "Apr", "05": "May", "06": "Jun",
      "07": "Jul", "08": "Aug", "09": "Sep"
    };
    parts.forEach(part => {
      const numMatch = part.match(/^(\d{1,2})[\/\-]?(\d{4})$/);
      if (numMatch) {
        const monthNum = numMatch[1].padStart(2, '0');
        const year = numMatch[2];
        const monthName = monthMap[monthNum];
        if (monthName) {
          const full = `${monthName} ${year}`;
          if (MONTHS.includes(full)) allowed.push(full);
        }
      }
      else if (/^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{4}$/i.test(part)) {
        const formatted = part.charAt(0).toUpperCase() + part.slice(1);
        if (MONTHS.includes(formatted)) allowed.push(formatted);
      }
    });
    return [...new Set(allowed)];
  } catch (err) {
    console.warn("Could not fetch viewer months from G10:", err);
    return [];
  }
}
async function getAgentPermission(){
  return new Promise((resolve,reject)=>{
    chrome.identity.getAuthToken({interactive:true},token=>{
      if(chrome.runtime.lastError||!token){
        reject(new Error("Failed to get auth token: "+(chrome.runtime.lastError?.message||"Unknown error")));
        return;
      }
      chrome.storage.local.get(['sheetId','apiKey'],result=>{
        const sheetId=result.sheetId;
        const googleSheetsApiKey=result.apiKey||API_KEY;
        if(!sheetId){ reject(new Error("Sheet ID not found in storage.")); return; }
        chrome.storage.local.get("username",userResult=>{
          const savedUsername=userResult.username?.trim().toUpperCase();
          if(!savedUsername){ reject(new Error("Username not found in storage.")); return; }
          const sheetName="Credential";
          fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!A:M?key=${googleSheetsApiKey}`,{
            method:"GET",
            headers:{Authorization:`Bearer ${token}`}
          })
          .then(r=>r.json())
          .then(async data=>{
            if(!data.values||data.values.length<=1){ reject(new Error("No data found in Credential sheet.")); return; }
            const headers=data.values[0].map(h=>h?.toString().toLowerCase());
            const rows=data.values.slice(1);
            const foundUser=rows.find(row=>(row[0]||"").trim().toUpperCase()===savedUsername);
            if(!foundUser){ reject(new Error("Username not found in Credential sheet.")); return; }
            const permColIndex=headers.findIndex(h=>h==="permission");
            const permValue=permColIndex!==-1?(foundUser[permColIndex]||"").trim().toLowerCase():"viewer";
            const level=({admin:1,ceo:2,manager:3,hr:4})[permValue]||999;
            if (level > 4) {
              viewerAllowedMonths = await fetchViewerAllowedMonths(sheetId, token);
            } else {
              viewerAllowedMonths = MONTHS;
            }
            resolve({username:savedUsername,permission:permValue,level});
          })
          .catch(err=>reject(new Error(`Failed to fetch permissions: ${err.message}`)));
        });
      });
    });
  });
}
function getSheetId(){
  return new Promise((resolve,reject)=>{
    chrome.storage.local.get(['sheetId2'],r=>{
      if(!r.sheetId2) reject(new Error("sheetId2 missing"));
      else resolve(r.sheetId2);
    });
  });
}
async function getAuthToken(){
  return new Promise((resolve,reject)=>{
    chrome.identity.getAuthToken({interactive:false},t=>{
      if(chrome.runtime.lastError||!t) reject(new Error("no token"));
      else resolve(t);
    });
  });
}
async function fetchEmployees(){
  const sheetId=await getSheetId();
  const range=`Employee_Management!A:ZZ`;
  const url=`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${range}?key=${API_KEY}`;
  let token=null; try{token=await getAuthToken();}catch{}
  const resp=await fetch(url,{headers:token?{Authorization:`Bearer ${token}`}:{}});
  if(!resp.ok) throw new Error(`API ${resp.status}`);
  const json=await resp.json();
  if(!json.values||json.values.length<2) return [];
  return json.values.slice(1).map((row,i)=>({
    sheetRowIndex:i+2,
    data:row,
    isActive:(row[30]||"").trim().toLowerCase()==="active"
  }));
}

// ------------------------------------------------------------
// INITIALIZATION AND LIST RENDERING (UNMODIFIED)
// ------------------------------------------------------------
(async function init(){
  try{
    empList.innerHTML="Loading permissions...";
    const {username:loggedInUser,permission,level}=await getAgentPermission();
    currentUserFromStorage=loggedInUser;
    currentUserLevel=level;
    localStorage.setItem('lastKnownUsername',loggedInUser);
    empList.innerHTML="Loading Employee_Management...";
    employeeRows=await fetchEmployees();
    if(!employeeRows.length){ empList.innerHTML="<p>No employees found.</p>"; return; }
    filteredRows = employeeRows.filter(r=>{
      if(!r.isActive) return false;
      if(level>4){
        const username=(r.data[0]||"").trim().toUpperCase();
        return username===loggedInUser;
      }
      return true;
    });
    if(filteredRows.length===0){
      if(level>4){
        empList.innerHTML="<p style='color:orange;'>Your profile is not active.</p>";
      }else{
        empList.innerHTML="<p>No active employees found.</p>";
      }
      return;
    }
    populateDeptFilter();
    renderEmployeeList(level);
    renderMonthCards(level);
    renderMonthVisibilityFilter(level);
    setupPasteUpload(level);
    setupSearchAndFilter(level,loggedInUser);
    selectFirstVisibleEmployee();
  }catch(e){
    console.error("Init failed:",e);
    empList.innerHTML=`<p style="color:red;">Error: ${e.message}</p>`;
  }
})();
function populateDeptFilter(){
  const depts=new Set();
  filteredRows.forEach(r=>{ const d=(r.data[7]||"").trim(); if(d) depts.add(d); });
  Array.from(depts).sort().forEach(d=>{
    const opt=document.createElement("option"); opt.value=d; opt.textContent=d;
    deptFilter.appendChild(opt);
  });
}
function renderEmployeeList(userLevel=999){
  empList.innerHTML="";
  filteredRows.forEach((r)=>{
    const d=r.data;
    const username = d[0]||"—";
    const fullName = d[1]||"—";
    const id = d[3]||"—";
    const dept = d[7]||"—";
    const imgUrl = d[21]||"";
    let photo = `<img src="https://placehold.co/60x60/cccccc/666666/png?text=No+Img" style="width:60px;height:60px;border-radius:50%;object-fit:cover;" onerror="this.src='https://placehold.co/60x60/cccccc/666666/png?text=No+Img'">`;
    if(imgUrl?.includes("drive.google.com")){
      const m=imgUrl.match(/\/d\/([a-zA-Z0-9_-]{33})/)||imgUrl.match(/id=([a-zA-Z0-9_-]{33})/);
      if(m?.[1]) photo=`<img src="https://drive.google.com/thumbnail?id=${m[1]}&sz=w120" style="width:60px;height:60px;border-radius:50%;object-fit:cover;" onerror="this.src='https://placehold.co/60x60/cccccc/666666/png?text=No+Img'">`;
    }
    const div=document.createElement("div");
    div.className="employee-item";
    div.dataset.username = username;
    div.dataset.fullname = fullName;
    div.innerHTML=`
      <div class="employee-photo" data-row="${r.sheetRowIndex}">${photo}</div>
      <div class="employee-info">
        <div class="employee-name">${fullName}</div>
        <div class="employee-username">Username: ${username}</div>
        <div class="employee-id">ID: ${id}</div>
        <div class="employee-dept">Dept: ${dept}</div>
      </div>
    `;
    div.onclick=e=>{
      if(e.target.closest('.employee-photo')) return;
      currentUsername=username;
      currentEmployeeFullName = fullName;
      loadEmployeeSalaryLinks(username);
      highlightSelected(div);
      rightPanel.classList.add('visible');
      selectPrompt.style.display='none';
    };
    div.querySelector('.employee-photo').onclick=e=>{
      e.stopPropagation();
      showModalEmployee(d,r.sheetRowIndex);
    };
    empList.appendChild(div);
  });
  const addBtn=document.createElement("button");
  addBtn.textContent="+ Add New Employee";
  addBtn.className="add-employee-btn";
  addBtn.onclick=()=>showModalEmployee([], employeeRows.length?Math.max(...employeeRows.map(r=>r.sheetRowIndex))+1:2);
  if(userLevel>4) addBtn.style.display='none';
  empList.appendChild(addBtn);
}
function highlightSelected(el){
  document.querySelectorAll('.employee-item').forEach(i=>i.style.background='rgba(255,255,255,.1)');
  el.style.background='rgba(255,255,255,.25)';
}
function selectFirstVisibleEmployee(){
  const firstItem = empList.querySelector('.employee-item');
  if(!firstItem) return;
  const username = firstItem.dataset.username || firstItem.querySelector('.employee-username').textContent.replace('Username: ','').trim();
  const fullName = firstItem.dataset.fullname || "";
  currentUsername = username;
  currentEmployeeFullName = fullName;
  loadEmployeeSalaryLinks(username);
  highlightSelected(firstItem);
  rightPanel.classList.add('visible');
  selectPrompt.style.display='none';
}
function setupSearchAndFilter(userLevel=999, loggedInUser=""){
  const applyFilter=()=>{
    const query = searchInput.value.trim().toLowerCase();
    const selectedDept = deptFilter.value;
    filteredRows = employeeRows.filter(r=>{
      if(!r.isActive) return false;
      const d=r.data;
      const username = (d[0]||"").trim().toUpperCase();
      const name = (d[1]||"").toLowerCase();
      const dept = (d[7]||"").trim();
      if(userLevel>4 && username!==loggedInUser) return false;
      const matchesSearch = !query || name.includes(query) || (d[0]||"").toLowerCase().includes(query);
      const matchesDept = !selectedDept || dept===selectedDept;
      return matchesSearch && matchesDept;
    });
    renderEmployeeList(userLevel);
    if(filteredRows.length>0) selectFirstVisibleEmployee();
  };
  searchInput.addEventListener('input',applyFilter);
  deptFilter.addEventListener('change',applyFilter);
  clearSearch.onclick=()=>{ searchInput.value=""; deptFilter.value=""; applyFilter(); };
}

// ------------------------------------------------------------
// MONTH CARDS & VISIBILITY (MODIFIED: HTML structure updated)
// ------------------------------------------------------------
function renderMonthCards(userLevel=999){
  monthsGrid.innerHTML="";
  const isViewer = userLevel>4;

  const buttonStyle = `
    background-color: #27ae60;
    color: white;
    margin: 8px 5px 0;
    padding: 9px 16px;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    transition: .3s;
  `;
  MONTHS.forEach((m,i)=>{
    const card=document.createElement("div");
    card.className="month-card";

    // Viewer sees "Please wait..." instead of upload prompt
    const uploadText = isViewer 
      ? "Please wait, it will appear soon" 
      : "Click or Paste Image Here";

    card.innerHTML=`
      <h3>${m}</h3>
      <div class="upload-zone" id="zone-${i}" data-idx="${i}">
        <div class="plus-icon" style="${isViewer ? 'display:none;' : ''}">+</div>
        <div class="upload-text">${uploadText}</div>
        <img class="preview-img" id="prev-${i}" src="" alt="Salary slip">
      </div>
      <input type="file" id="file-${i}" accept="image/jpeg,image/png" style="display:none;" ${isViewer?'disabled':''}>
      <div class="month-actions">
        <button class="download-btn" data-idx="${i}" style="${buttonStyle}; display:none;">Download</button>
        <button class="clear-btn" data-idx="${i}" style="display:none;" ${isViewer?'disabled':''}>Clear</button>
        <span class="view-count-display" id="view-count-${i}" style="margin-left:10px; font-size: 0.9em; display: none;">👁️ 0</span>
        <span class="download-count-display" id="download-count-${i}" style="margin-left:5px; font-size: 0.9em; display: none;">⬇️ 0</span>
      </div>
      <div class="status" id="status-${i}"></div>
    `;
    monthsGrid.appendChild(card);
  });
  setupUploadZoneHandlers(userLevel);
}

function setupUploadZoneHandlers(userLevel=999){
  const isViewer = userLevel>4;
  document.querySelectorAll(".upload-zone").forEach(zone=>{
    const idx=zone.dataset.idx;
    if(!isViewer){
      zone.onclick=e=>{ if(e.target.closest('.preview-img')) return; document.getElementById(`file-${idx}`).click(); };
      zone.addEventListener('mouseenter',()=>{ if(!zone.classList.contains('has-image')) zone.querySelector('.upload-text').textContent="Click or Paste (Ctrl+V)"; });
      zone.addEventListener('mouseleave',()=>{ if(!zone.classList.contains('has-image')) zone.querySelector('.upload-text').textContent="Click or Paste Image Here"; });
    }
    // MODIFIED: Added view count increment to image click
    document.getElementById(`prev-${idx}`).onclick=e=>{
      e.stopPropagation();
      const status=document.getElementById(`status-${idx}`);
      if(status.dataset.fullLink) {
        window.open(status.dataset.fullLink,'_blank');
        if(isViewer) {
          updateSalarySheetCounter(currentUsername, idx, 'view').catch(console.error);
        }
      }
    };
  });
  document.querySelectorAll('input[type="file"]').forEach(inp=>{ if(isViewer) return;
    inp.onchange=async e=>{ const file=e.target.files[0]; if(!file) return; const idx=e.target.id.split("-")[1]; await handleFile(file,idx); };
  });
  document.querySelectorAll(".clear-btn").forEach(btn=>{ if(isViewer) return;
    btn.onclick=async()=>{ const idx=btn.dataset.idx; const status=document.getElementById(`status-${idx}`);
      status.textContent="Clearing...";
      try{ await clearSalarySlip(currentUsername,idx); resetMonthCard(idx); status.textContent="Cleared"; status.style.color="#27ae60"; }
      catch(e){ status.textContent="Error: "+e.message; status.style.color="#e74c3c"; }
    };
  });
  // MODIFIED: Added download count increment to download button
  document.querySelectorAll(".download-btn").forEach(btn=>{
      btn.onclick=()=>{
          const idx = btn.dataset.idx;
          const status = document.getElementById(`status-${idx}`);
          const fileId = getDriveFileId(status.dataset.fullLink);
          const fileName = status.dataset.fileName;
          if (fileId && fileName) {
              const downloadUrl = `https://drive.google.com/uc?export=download&id=${fileId}&download=${encodeURIComponent(fileName)}`;
              window.open(downloadUrl, '_self');
              if(isViewer) {
                updateSalarySheetCounter(currentUsername, idx, 'download').catch(console.error);
              }
          } else {
              alert("File details not available for download.");
          }
      };
  });
}

// ------------------------------------------------------------
// DATA LOADING (MODIFIED: Reads all relevant salary sheet data)
// ------------------------------------------------------------

/**
 * Maps the month index (0-11) to the corresponding column index and letter in the sheet
 * where view and download counts are stored.
 */
function getCounterColumnIndices(monthIdx) {
  // Salary links start at column F (index 5).
  // Counts start at AA (index 26) and BB (index 27).
  const baseIndex = 26;
  // Each month takes 2 columns (View, Download)
  const offset = monthIdx * 2; 
  
  const viewColIndex = baseIndex + offset;
  const downloadColIndex = baseIndex + offset + 1;
  
  return {
    viewColIndex: viewColIndex,
    downloadColIndex: downloadColIndex,
    viewColLetter: getColumnLetter(viewColIndex),
    downloadColLetter: getColumnLetter(downloadColIndex),
  };
}

async function loadEmployeeSalaryLinks(username){
  currentUsername = username;
  rightPanelLoader.classList.add("active");
  try{
    const sheetId=await getSheetId();
    // Fetch a much wider range to include the new counter columns 
    const range=`Employee_salary_sheet!A:AZZ`; 
    const url=`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${range}?key=${API_KEY}`;
    let token=null; try{token=await getAuthToken();}catch{}
    const resp=await fetch(url,{headers:token?{Authorization:`Bearer ${token}`}:{}});
    if(!resp.ok) throw new Error("Failed to load salary sheet");
    const json=await resp.json();
    const rows=json.values||[];
    const rowIdx=rows.findIndex(r=>(r[0]||"").trim()===username);
    MONTHS.forEach((_,i)=>resetMonthCard(i));
    if(rowIdx===-1 || !rows[rowIdx]){
      rightPanelLoader.classList.remove("active");
      employeeSalaryRow = [];
      return;
    }
    const row = rows[rowIdx];
    employeeSalaryRow = row; // Save the entire row data

    let loadPromises = [];
    MONTHS.forEach((_, monthIdx) => {
      const link = (row[5 + monthIdx] || "").trim(); // Salary links start at column F (index 5)
      if(link){
        if (currentUserLevel > 4 && !viewerAllowedMonths.includes(MONTHS[monthIdx])) {
            return;
        }

        const { viewColIndex, downloadColIndex } = getCounterColumnIndices(monthIdx);
        
        // Get counts from the row data (default to 0 if not present)
        const viewCount = parseInt(row[viewColIndex]) || 0;
        const downloadCount = parseInt(row[downloadColIndex]) || 0;

        const loadPromise = getDriveFileDetails(link).then(details => {
            const thumbUrl = getThumbnailUrl(link);
            const img = new Image();
            return new Promise(resolve => {
                img.onload = img.onerror = () => {
                    // Pass the counts to the function
                    applyImageToCard(monthIdx, thumbUrl, link, details.fileName, viewCount, downloadCount); 
                    resolve();
                };
                img.src = thumbUrl;
            });
        }).catch(e => console.error("Error processing link:", e));
        loadPromises.push(loadPromise);
      }
    });
    await Promise.all(loadPromises);
    rightPanelLoader.classList.remove("active");
  }catch(e){
    console.error("loadEmployeeSalaryLinks error:", e);
    rightPanelLoader.classList.remove("active");
  }
}

// ------------------------------------------------------------
// UI & CARD MANAGEMENT (MODIFIED: Updated display logic)
// ------------------------------------------------------------
function applyImageToCard(monthIdx, thumbUrl, fullLink, fileName, viewCount = 0, downloadCount = 0){
  const zone = document.getElementById(`zone-${monthIdx}`);
  const prev = document.getElementById(`prev-${monthIdx}`);
  const clearBtn = document.querySelector(`.clear-btn[data-idx="${monthIdx}"]`);
  const downloadBtn = document.querySelector(`.download-btn[data-idx="${monthIdx}"]`);
  const status = document.getElementById(`status-${monthIdx}`);
  
  // NEW: Get the count displays
  const viewCountEl = document.getElementById(`view-count-${monthIdx}`);
  const downloadCountEl = document.getElementById(`download-count-${monthIdx}`);
 
  prev.src = thumbUrl;
  zone.classList.add('has-image');
  zone.querySelector('.plus-icon').style.display = 'none';
  zone.querySelector('.upload-text').style.display = 'none';
  status.dataset.fullLink = fullLink;
  status.dataset.fileName = fileName;
  
  status.textContent = "";
  status.style.color = "transparent";
  status.style.cursor = "default";
  status.style.textDecoration = "none";
  status.title = "";
  
  prev.style.cursor = 'pointer';
  prev.title = 'Click to open full image';
  prev.onclick = e => {
    e.stopPropagation();
    window.open(fullLink, '_blank');
    // Call counter function on view click
    if(currentUserLevel > 4) {
      updateSalarySheetCounter(currentUsername, monthIdx, 'view').catch(console.error);
    }
  };

  downloadBtn.style.display = "inline-block";
  if(currentUserLevel <= 4) clearBtn.style.display = "inline-block";
  
  // NEW: Update and show view/download counts
  viewCountEl.textContent = `👁️ ${viewCount}`;
  viewCountEl.style.display = "inline-block"; // Always show when link is present
  downloadCountEl.textContent = `⬇️ ${downloadCount}`;
  downloadCountEl.style.display = "inline-block"; // Always show when link is present
}

function resetMonthCard(i){
  const zone=document.getElementById(`zone-${i}`);
  const prev=document.getElementById(`prev-${i}`);
  const clear=document.querySelector(`.clear-btn[data-idx="${i}"]`);
  const download=document.querySelector(`.download-btn[data-idx="${i}"]`);
  const status=document.getElementById(`status-${i}`);
  // NEW: Reset count displays
  const viewCountEl = document.getElementById(`view-count-${i}`);
  const downloadCountEl = document.getElementById(`download-count-${i}`);


  // Restore correct text for viewer vs admin
  const isViewer = currentUserLevel > 4;
  const defaultText = isViewer ? "Please wait, it will appear soon" : "Click or Paste Image Here";

  zone.classList.remove('has-image');
  zone.querySelector('.plus-icon').style.display = isViewer ? 'none' : 'block';
  zone.querySelector('.upload-text').style.display = 'block';
  zone.querySelector('.upload-text').textContent = defaultText;
  prev.src=""; prev.onclick=null; prev.style.cursor='default'; prev.title='';
  if(currentUserLevel<=4) clear.style.display="none";
  download.style.display="none";
  status.textContent=""; status.dataset.fullLink=""; status.dataset.fileName="";
  status.style.cursor = "default";
  status.style.textDecoration = "none";
  status.title = "";
  // NEW: Hide count displays
  viewCountEl.style.display = "none";
  downloadCountEl.style.display = "none";
}

function renderMonthVisibilityFilter(userLevel=999){
  monthFilter.innerHTML="";
  const isViewer = userLevel > 4;
  const monthsToShow = isViewer ? viewerAllowedMonths : MONTHS;
  const defaultSelectedIndexes = monthsToShow.map(month => MONTHS.indexOf(month)).filter(index => index !== -1);
  monthsToShow.forEach(month => {
    const opt=document.createElement("option");
    opt.value=MONTHS.indexOf(month); opt.textContent=month;
    opt.selected = defaultSelectedIndexes.includes(MONTHS.indexOf(month));
    monthFilter.appendChild(opt);
  });
  const applyVisibility=()=>{
    const selected=Array.from(monthFilter.selectedOptions).map(o=>parseInt(o.value));
    MONTHS.forEach((_,i)=>{
      const card=monthsGrid.children[i];
      if(card){
        const shouldShow = selected.includes(i);
        card.style.display = shouldShow ? "block" : "none";
      }
    });
    if (!isViewer) { saveMonthVisibility(); }
  };
  monthFilter.addEventListener("change",applyVisibility);
  clearMonthsBtn.onclick=()=>{
    monthFilter.selectedIndex=-1;
    Array.from(monthFilter.options).forEach(o => o.selected = false);
    applyVisibility();
  };
  loadMonthVisibility(isViewer);
  applyVisibility();
}
function loadMonthVisibility(isViewer = false){
  if (isViewer) { return; }
  const s=localStorage.getItem("salaryMonthVisibility_v3");
  if(!s) return;
  try{
    const sel=JSON.parse(s);
    Array.from(monthFilter.options).forEach(o => {
        const isSelectedInSaved = sel.includes(o.value);
        o.selected = isSelectedInSaved;
    });
  }catch(e){console.warn(e);}
}
function saveMonthVisibility(){
  const s=Array.from(monthFilter.selectedOptions).map(o=>o.value);
  localStorage.setItem("salaryMonthVisibility_v3",JSON.stringify(s));
}

// ------------------------------------------------------------
// FILE HANDLING & UPLOAD (UNMODIFIED)
// ------------------------------------------------------------
async function handleFile(file,monthIdx){
  const ext=(file.name.split('.').pop()||'').toLowerCase();
  if(!['jpg','jpeg','png'].includes(ext)){ alert("Only JPG/PNG allowed"); return; }
  const mime=ext==='jpg'||ext==='jpeg'?'image/jpeg':'image/png';
  const monthName=MONTHS[monthIdx];
  const safeFullName = currentEmployeeFullName.replace(/\s/g, '_');
  const safeName=`${safeFullName}_${monthName}.${ext==='jpeg'?'jpg':ext}`;
  const fixedFile=new File([file],safeName,{type:mime});
  const reader=new FileReader();
  reader.onload=e=>{
    const zone=document.getElementById(`zone-${monthIdx}`);
    const prev=document.getElementById(`prev-${monthIdx}`);
    prev.src=e.target.result;
    zone.classList.add('has-image');
    zone.querySelector('.plus-icon').style.display='none';
    zone.querySelector('.upload-text').style.display='none';
    if(currentUserLevel<=4) document.querySelector(`.clear-btn[data-idx="${monthIdx}"]`).style.display="inline-block";
  };
  reader.readAsDataURL(fixedFile);
  await uploadAndSave(fixedFile,monthIdx);
}
function setupPasteUpload(userLevel=999){
  const isViewer=userLevel>4;
  document.addEventListener('paste',async e=>{
    if(isViewer) return;
    const items=(e.clipboardData||e.originalEvent.clipboardData).items;
    let blob=null;
    for(let it of items){ if(it.type.includes('image')){ blob=it.getAsFile(); break; } }
    if(!blob||!currentUsername) return;
    e.preventDefault();
    let target=-1;
    for(let i=0;i<MONTHS.length;i++){ if(!document.getElementById(`zone-${i}`).classList.contains('has-image')){ target=i; break; } }
    if(target===-1) target=0;
    const safeFullName = currentEmployeeFullName.replace(/\s/g, '_');
    const file=new File([blob],`${safeFullName}_${MONTHS[target]}.png`,{type:'image/png'});
    await handleFile(file,target);
  });
}
async function uploadAndSave(file,monthIdx){
  const status=document.getElementById(`status-${monthIdx}`);
  status.textContent="Uploading…";
  status.style.color="#e67e22";
  status.style.cursor = "default";
  status.style.textDecoration = "none";
  try{
    const url=await uploadImageToDrive(file);
    await updateSalarySheetCell(currentUsername,monthIdx,url);
    // After upload, reset counts to 0 by updating the sheet.
    const { viewColIndex, downloadColIndex } = getCounterColumnIndices(monthIdx);
    await updateSalarySheetCounter(currentUsername, monthIdx, 'view', 0, viewColIndex);
    await updateSalarySheetCounter(currentUsername, monthIdx, 'download', 0, downloadColIndex);


    const thumbUrl=getThumbnailUrl(url);
    const zone=document.getElementById(`zone-${monthIdx}`);
    const prev=document.getElementById(`prev-${monthIdx}`);
    const clear=document.querySelector(`.clear-btn[data-idx="${monthIdx}"]`);
    const download=document.querySelector(`.download-btn[data-idx="${monthIdx}"]`);
    
    prev.src=thumbUrl;
    zone.classList.add('has-image');
    zone.querySelector('.plus-icon').style.display='none';
    zone.querySelector('.upload-text').style.display='none';
    
    status.dataset.fullLink=url;
    status.dataset.fileName=file.name;
    
    status.textContent="";
    status.style.color="transparent";
    status.style.cursor = "default";
    status.style.textDecoration = "none";
    status.title = "";
    prev.style.cursor='pointer';
    prev.title='Click to open full image';
    prev.onclick=e=>{ e.stopPropagation(); window.open(url,'_blank'); };
    download.style.display = "inline-block";
    if(currentUserLevel<=4) clear.style.display="inline-block";

    // Update the UI with the reset counts (0)
    const viewCountEl = document.getElementById(`view-count-${monthIdx}`);
    const downloadCountEl = document.getElementById(`download-count-${monthIdx}`);
    viewCountEl.textContent = `👁️ 0`;
    viewCountEl.style.display = "inline-block";
    downloadCountEl.textContent = `⬇️ 0`;
    downloadCountEl.style.display = "inline-block";
  }catch(e){
    status.textContent="Error: "+e.message;
    status.style.color="#e74c3c";
    status.style.cursor = "default";
    status.style.textDecoration = "none";
    status.title = "";
  }
}

// ------------------------------------------------------------
// GOOGLE SHEETS & DRIVE FUNCTIONS (FIXED)
// ------------------------------------------------------------

/**
 * Updates a cell in the Employee_salary_sheet.
 * Used for setting the salary slip link.
 */
async function updateSalarySheetCell(username,monthIdx,value){
  const sheetId=await getSheetId();
  const token=await getAuthToken();
  // Fetch only the A:S range to quickly get the row index
  const readUrl=`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/Employee_salary_sheet!A:S?key=${API_KEY}`;
  const resp=await fetch(readUrl,{headers:{Authorization:`Bearer ${token}`}});
  if(!resp.ok) throw new Error("Failed to read sheet");
  const json=await resp.json();
  const rows=json.values||[];
  const rowIdx=rows.findIndex(r=>r[0]===username);
  if(rowIdx===-1) throw new Error("User not found");
  const colIndex=5+parseInt(monthIdx); // Salary link columns start at F (index 5)
  // Use robust column letter utility
  const colLetter = getColumnLetter(colIndex); 
  const cell=`Employee_salary_sheet!${colLetter}${rowIdx+1}`;
  const putUrl=`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${encodeURIComponent(cell)}?valueInputOption=RAW`;
  const putResp=await fetch(putUrl,{method:'PUT',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify({values:[[value]]})});
  if(!putResp.ok){ const err=await putResp.text(); throw new Error(`PUT failed: ${putResp.status} – ${err}`); }
}

async function clearSalarySlip(username,monthIdx){ 
  await updateSalarySheetCell(username,monthIdx,""); 
  // Also clear the counts when clearing the slip
  const { viewColIndex, downloadColIndex } = getCounterColumnIndices(monthIdx);
  // Pass 0 as specificValue to reset the count
  await updateSalarySheetCounter(currentUsername, monthIdx, 'view', 0, viewColIndex);
  await updateSalarySheetCounter(currentUsername, monthIdx, 'download', 0, downloadColIndex);
}

/**
 * Updates or increments the View/Download counter in the sheet.
 */
async function updateSalarySheetCounter(username, monthIdx, type, specificValue = null, forcedColIndex = null){
  if(currentUserLevel <= 4) return; // Only Viewers should trigger the counter
  
  const sheetId=await getSheetId();
  const token=await getAuthToken();
  
  // Find the row index from the employeeSalaryRow, which was loaded previously
  const readUrl=`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/Employee_salary_sheet!A:B?key=${API_KEY}`;
  const resp=await fetch(readUrl,{headers:{Authorization:`Bearer ${token}`}});
  if(!resp.ok) throw new Error("Failed to read sheet for counter update");
  const json=await resp.json();
  const rows=json.values||[];
  const rowIdx=rows.findIndex(r=>r[0]===username); // Row index is 0-based
  if(rowIdx===-1) throw new Error("User not found for counter update");
  
  const { viewColIndex, downloadColIndex, viewColLetter, downloadColLetter } = getCounterColumnIndices(monthIdx);
  
  let targetColIndex;
  let currentColLetter;
  
  if (forcedColIndex !== null) {
      // If forced index is used (e.g., for clearing), use it and calculate the letter
      targetColIndex = forcedColIndex;
      currentColLetter = getColumnLetter(targetColIndex);
  } else {
      // Use the pre-calculated index and letter for standard view/download increment
      targetColIndex = (type === 'view' ? viewColIndex : downloadColIndex);
      currentColLetter = (type === 'view' ? viewColLetter : downloadColLetter);
  }

  // Construct the cell address using the robust column letter and 1-based row index
  const cellAddress = `Employee_salary_sheet!${currentColLetter}${rowIdx + 1}`; 

  let newValue;
  if (specificValue !== null) {
    newValue = specificValue;
  } else {
    // Read the current value from the specific cell
    const readCellUrl=`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${encodeURIComponent(cellAddress)}?key=${API_KEY}`;
    const readResp=await fetch(readCellUrl,{headers:{Authorization:`Bearer ${token}`}});
    const readJson=await readResp.json();
    const currentValue = parseInt(readJson.values?.[0]?.[0]) || 0;
    newValue = currentValue + 1;
  }
  
  // Write the new value back to the cell
  const putUrl=`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${encodeURIComponent(cellAddress)}?valueInputOption=RAW`;
  const putResp=await fetch(putUrl,{
    method:'PUT',
    headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},
    body:JSON.stringify({values:[[newValue]]})
  });

  if(!putResp.ok){ 
    const err=await putResp.text(); 
    throw new Error(`Counter PUT failed: ${putResp.status} – ${err}`); 
  }
  
  // Update the UI with the new count
  const countEl = document.getElementById(`${type}-count-${monthIdx}`);
  if (countEl) {
    const icon = type === 'view' ? '👁️' : '⬇️';
    countEl.textContent = `${icon} ${newValue}`;
  }
}


async function uploadImageToDrive(file){
  const token=await getAuthToken();
  const metadata={name:file.name,parents:[FOLDER_ID],mimeType:file.type};
  const form=new FormData();
  form.append('metadata',new Blob([JSON.stringify(metadata)],{type:'application/json'}));
  form.append('file',file);
  const resp=await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart',{method:'POST',headers:{Authorization:`Bearer ${token}`},body:form});
  if(!resp.ok){ const err=await resp.json().catch(()=>{}); throw new Error(err.error?.message||`Upload failed: ${resp.status}`); }
  const data=await resp.json();
  await fetch(`https://www.googleapis.com/drive/v3/files/${data.id}/permissions`,{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify({role:'reader',type:'anyone'})});
  return `https://drive.google.com/uc?id=${data.id}`;
}
function getDriveFileId(driveLink){
  const m=driveLink.match(/uc\?id=([a-zA-Z0-9_-]{33})|\/d\/([a-zA-Z0-9_-]{33})|open\?id=([a-zA-Z0-9_-]{33})/);
  return m?m[1]||m[2]||m[3]:null;
}
function getThumbnailUrl(driveLink){
  const id=getDriveFileId(driveLink);
  return id?`https://drive.google.com/thumbnail?id=${id}&sz=w600`:"";
}
function showModalEmployee(rowData,sheetRowIndex){
  sessionStorage.setItem('employeeData',JSON.stringify({row:rowData,sheetRowIndex,userPermission:currentUserLevel<=4?'admin':'viewer'}));
  window.open('employeeDetails.html','_blank');
}