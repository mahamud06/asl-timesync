     function disableConsoleLog() {
    console.log = function() {};
}
// Call disableConsoleLog() to disable console logging
disableConsoleLog();


async function showModalSalary(row, sheetRowIndex, userPermission) {
  const modal = document.getElementById("detailModal");
  const modalContent = document.getElementById("modalContent");
  const headers = ["Username", "Full Name", "Department", "Timestamp", "Pay Period", "Amount Received", "Amount Requested", "Reason", "Description", "Attachment", "Status", "Remark"];
  const modalIndices = [0, 1, 2, 3, 4, 5, 6, 7, 11, 8, 9, 10]; // Match Google Sheet order
  let modalHTML = `<div style="position: relative;">`;

  headers.forEach((header, i) => {
    const cellData = row[modalIndices[i]] || "";
    if (header === "Attachment") {
      if (cellData.startsWith("http")) {
        const fileIdMatch = cellData.match(/\/d\/([a-zA-Z0-9_-]{33})\/view/);
        if (fileIdMatch && fileIdMatch[1]) {
          const fileId = fileIdMatch[1];
          modalHTML += `
            <p>
              <strong>${header}:</strong>
              <img src="https://drive.google.com/thumbnail?id=${fileId}&sz=w100" 
                   style="width: 100px; height: auto; border: 1px solid #ccc; margin: 5px;" 
                   class="loading" 
                   onload="this.classList.remove('loading');" 
                   onerror="this.src='https://via.placeholder.com/100?text=Image+Not+Available';this.classList.remove('loading');console.error('Thumbnail load failed for URL: ${cellData}');">
              <a href="${cellData}" target="_blank" style="color: blue;">View Full File</a>
            </p>`;
        } else {
          console.error("Invalid Google Drive URL:", cellData);
          modalHTML += `<p><strong>${header}:</strong> <a href="${cellData}" target="_blank" style="color: blue;">View File</a></p>`;
        }
      } else {
        modalHTML += `<p><strong>${header}:</strong> No attachment</p>`;
      }
    } else if (header === "Description" || header === "Reason") {
      modalHTML += `
        <p>
          <strong>${header}:</strong>
          <div style="white-space: pre-wrap; display: inline-block;">${cellData}</div>
        </p>`;
    } else {
      modalHTML += `<p><strong>${header}:</strong> ${cellData}</p>`;
    }
  });

  modalHTML += `
    <button id="printDetailsBtn" style="position: absolute; top: 10px; right: 10px; padding: 5px 10px; font-size: 14px; background-color: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer;">
      Print/Save as PDF
    </button>
  `;
  modalHTML += `</div>`;

  modalContent.innerHTML = modalHTML;
  const statusSelect = document.getElementById("statusSelect");
  const remarkInput = document.getElementById("remarkInput");
  const updateStatusBtn = document.getElementById("updateStatusBtn");
  const currentStatus = row[9] || "Pending";
  const currentRemark = row[10] || "";

  const existingStatusText = document.getElementById("statusText");
  const existingRemarkText = document.getElementById("remarkText");
  const existingAssistantRemarkInput = document.getElementById("assistantRemarkInput");
  if (existingStatusText) existingStatusText.remove();
  if (existingRemarkText) existingRemarkText.remove();
  if (existingAssistantRemarkInput) existingAssistantRemarkInput.remove();

  const statusOptions = [
    "Pending",
    "Approved by Admin",
    "Approved by HR",
    "Approved by Manager",
    "Approved by CEO",
    "Approved by Teamlead",
    "Approved by Team Coordinator",
    "Rejected by Admin",
    "Rejected by HR",
    "Rejected by Manager",
    "Rejected by CEO",
    "Rejected by Teamlead",
    "Rejected by Team Coordinator"
  ];

  const permissionTiers = {
    admin: 1,
    ceo: 2,
    manager: 3,
    hr: 4,
    teamlead: 5,
    teamcoordinator: 6,
    accountant: 7,
    assistant: 7,
    viewer: 8
  };

  const statusToTier = {
    "Approved by Admin": 1,
    "Rejected by Admin": 1,
    "Approved by CEO": 2,
    "Rejected by CEO": 2,
    "Approved by Manager": 3,
    "Rejected by Manager": 3,
    "Approved by HR": 4,
    "Rejected by HR": 4,
    "Approved by Teamlead": 5,
    "Rejected by Teamlead": 5,
    "Approved by Team Coordinator": 6,
    "Rejected by Team Coordinator": 6,
    "Pending": 7
  };

  const currentStatusTier = statusToTier[currentStatus] || 7;
  const userTier = permissionTiers[userPermission] || 8;
  let canUpdate = ["admin", "ceo", "manager", "hr", "teamlead"].includes(userPermission) && currentStatusTier >= userTier;

  // Disable update functionality for teamcoordinator
  if (userPermission === "teamcoordinator") {
    statusSelect.innerHTML = `<option value="${currentStatus}">${currentStatus}</option>`;
    statusSelect.disabled = true;
    statusSelect.style.display = "inline-block";
    remarkInput.value = currentRemark;
    remarkInput.style.display = "inline-block";
    remarkInput.disabled = true;
    updateStatusBtn.style.display = "inline-block";
    updateStatusBtn.disabled = true;
    updateStatusBtn.style.opacity = "0.5";
    updateStatusBtn.style.cursor = "not-allowed";
  } else if (userPermission === "admin" && canUpdate) {
    statusSelect.innerHTML = statusOptions.map(opt => `<option value="${opt}">${opt}</option>`).join("");
    statusSelect.value = currentStatus;
    statusSelect.disabled = false;
    statusSelect.style.display = "inline-block";
    remarkInput.value = currentRemark;
    remarkInput.style.display = "inline-block";
    remarkInput.disabled = false;
    updateStatusBtn.style.display = "inline-block";
    updateStatusBtn.disabled = false;
  } else if (userPermission === "hr" && canUpdate) {
    statusSelect.innerHTML = [
      `<option value="Approved by HR">Approved by HR</option>`,
      `<option value="Rejected by HR">Rejected by HR</option>`
    ].join("");
    statusSelect.value = ["Approved by HR", "Rejected by HR"].includes(currentStatus) ? currentStatus : "Approved by HR";
    statusSelect.disabled = false;
    statusSelect.style.display = "inline-block";
    remarkInput.value = currentRemark;
    remarkInput.style.display = "inline-block";
    remarkInput.disabled = false;
    updateStatusBtn.style.display = "inline-block";
    updateStatusBtn.disabled = false;
  } else if (userPermission === "manager" && canUpdate) {
    statusSelect.innerHTML = [
      `<option value="Approved by Manager">Approved by Manager</option>`,
      `<option value="Rejected by Manager">Rejected by Manager</option>`
    ].join("");
    statusSelect.value = ["Approved by Manager", "Rejected by Manager"].includes(currentStatus) ? currentStatus : "Approved by Manager";
    statusSelect.disabled = false;
    statusSelect.style.display = "inline-block";
    remarkInput.value = currentRemark;
    remarkInput.style.display = "inline-block";
    remarkInput.disabled = false;
    updateStatusBtn.style.display = "inline-block";
    updateStatusBtn.disabled = false;
  } else if (userPermission === "ceo" && canUpdate) {
    statusSelect.innerHTML = [
      `<option value="Approved by CEO">Approved by CEO</option>`,
      `<option value="Rejected by CEO">Rejected by CEO</option>`
    ].join("");
    statusSelect.value = ["Approved by CEO", "Rejected by CEO"].includes(currentStatus) ? currentStatus : "Approved by CEO";
    statusSelect.disabled = false;
    statusSelect.style.display = "inline-block";
    remarkInput.value = currentRemark;
    remarkInput.style.display = "inline-block";
    remarkInput.disabled = false;
    updateStatusBtn.style.display = "inline-block";
    updateStatusBtn.disabled = false;
  } else if (userPermission === "teamlead" && canUpdate) {
    statusSelect.innerHTML = [
      `<option value="Approved by Teamlead">Approved by Teamlead</option>`,
      `<option value="Rejected by Teamlead">Rejected by Teamlead</option>`
    ].join("");
    statusSelect.value = ["Approved by Teamlead", "Rejected by Teamlead"].includes(currentStatus) ? currentStatus : "Approved by Teamlead";
    statusSelect.disabled = false;
    statusSelect.style.display = "inline-block";
    remarkInput.value = currentRemark;
    remarkInput.style.display = "inline-block";
    remarkInput.disabled = false;
    updateStatusBtn.style.display = "inline-block";
    updateStatusBtn.disabled = false;
  } else {
    statusSelect.innerHTML = `<option value="${currentStatus}">${currentStatus}</option>`;
    statusSelect.disabled = true;
    statusSelect.style.display = "inline-block";
    remarkInput.value = currentRemark;
    remarkInput.style.display = "inline-block";
    remarkInput.disabled = true;
    updateStatusBtn.style.display = "inline-block";
    updateStatusBtn.disabled = true;
    updateStatusBtn.style.opacity = "0.5";
    updateStatusBtn.style.cursor = "not-allowed";
  }

  const printBtn = document.getElementById("printDetailsBtn");
  if (printBtn) {
    printBtn.addEventListener("click", () => {
      const printContent = modalContent.cloneNode(true);
      printContent.querySelector("#printDetailsBtn")?.remove();
      printContent.querySelector("#statusSelect")?.remove();
      printContent.querySelector("#remarkInput")?.remove();
      printContent.querySelector("#updateStatusBtn")?.remove();

      const printWindow = window.open('', '_blank');
      printWindow.document.write(`
        <html>
          <head>
            <title>Salary Recalculation Details</title>
            <style>
              body { font-family: Arial, sans-serif; padding: 20px; }
              p { margin: 10px 0; }
              strong { display: inline-block; width: 150px; }
              img { max-width: 100px; height: auto; border: 1px solid #ccc; margin: 5px; }
              div[style*="white-space: pre-wrap"] { max-width: 500px; }
            </style>
          </head>
          <body>
            <div id="printContent">${printContent.innerHTML}</div>
            <script>
              window.print();
            </script>
          </body>
        </html>
      `);
      printWindow.document.close();
    });
  }
  modal.style.display = "flex";

  updateStatusBtn.onclick = async () => {
    const status = statusSelect.value;
    const remark = remarkInput.value.trim();

    const allowedStatuses = {
      admin: statusOptions,
      hr: ["Approved by HR", "Rejected by HR"],
      manager: ["Approved by Manager", "Rejected by Manager"],
      ceo: ["Approved by CEO", "Rejected by CEO"],
      teamlead: ["Approved by Teamlead", "Rejected by Teamlead"]
    };

    if (userPermission === "teamcoordinator") {
      return; // Button is disabled, so this is a fallback
    } else if (!["admin", "hr", "manager", "ceo", "teamlead"].includes(userPermission)) {
      alert("You do not have permission to update status or remarks.");
      return;
    } else if (!allowedStatuses[userPermission].includes(status)) {
      alert(`You can only set status to ${allowedStatuses[userPermission].join(" or ")}.`);
      return;
    } else if (!canUpdate) {
      alert("You cannot update this entry as it has been processed by a higher tier.");
      return;
    }

    try {
      const token = await new Promise((resolve, reject) => {
        chrome.identity.getAuthToken({ interactive: true }, (token) => {
          if (chrome.runtime.lastError || !token) {
            reject(new Error(chrome.runtime.lastError?.message || "Authentication failed"));
          } else {
            resolve(token);
          }
        });
      });

      await updateSheet(token, "salary", sheetRowIndex, status, remark, userPermission);
      alert("Status and remark updated successfully.");
      modal.style.display = "none";
      displayDataSalary(
        document.getElementById("usernameFilter").value,
        document.getElementById("statusFilter").value,
        document.getElementById("reasonFilter").value,
        document.getElementById("monthFilter").value,
        userPermission
      );
    } catch (error) {
      console.error("Error updating status and remark:", error);
      alert(`Error updating status and remark: ${error.message}`);
    }
  };
}

async function displayDataSalary(usernameFilter = "", statusFilter = "", reasonFilter = "", monthFilter = "", userPermission = "") {
  const tableBody = document.querySelector("#salaryTable tbody");
  const allowedRoles = ["admin", "hr", "manager", "ceo", "teamlead", "accountant"];
  if (!allowedRoles.includes(userPermission)) {
    // Adjusted colspan from 13 to 14 to account for the new S/N column
    tableBody.innerHTML = "<tr><td colspan='14'>You do not have permission to view Salary Recalculation Requests.</td></tr>";
    return;
  }

  const rows = await fetchData("salary");
  let filteredRows = rows;

  if (usernameFilter) {
    filteredRows = filteredRows.filter(row => row.data[0]?.toUpperCase().includes(usernameFilter.toUpperCase()));
  }
  if (statusFilter) {
    filteredRows = filteredRows.filter(row => row.data[9] === statusFilter);
  }
  if (reasonFilter) {
    filteredRows = filteredRows.filter(row => row.data[7] === reasonFilter);
  }
  if (monthFilter) {
    const [monthName, year] = monthFilter.split("_");
    const monthIndex = [
      "January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"
    ].indexOf(monthName);
    const targetYear = parseInt(year);
    filteredRows = filteredRows.filter(row => {
      const dateInfo = getMonthYearFromTimestamp(row.data[3]);
      if (!dateInfo) return false;
      return dateInfo.month === monthIndex && dateInfo.year === targetYear;
    });
  }

  if (filteredRows.length === 0) {
    // Adjusted colspan from 13 to 14 to account for the new S/N column
    tableBody.innerHTML = "<tr><td colspan='14'>No matching data found.</td></tr>";
    return;
  }

  tableBody.innerHTML = "";
  filteredRows.forEach((row, index) => {
    const tr = document.createElement("tr");
    const cells = [
      index + 1, // **S/N - Added dynamic serial number**
      row.data[0] || "", // Username
      row.data[1] || "", // Full Name
      row.data[2] || "", // Department
      row.data[7] || "", // Reason
      row.data[3] || "", // Timestamp
      row.data[4] || "", // Pay Period
      row.data[5] || "", // Amount Received
      row.data[6] || "", // Amount Requested
      row.data[8] ? `<a href="${row.data[8]}" target="_blank" style="color: blue;">View</a>` : "", // Attachment
      row.data[9] || "", // Status
      row.data[10] || "", // Remark
      ["admin", "hr", "manager", "ceo", "teamlead", "accountant"].includes(userPermission)
        ? `<span class="${iconConfig.edit.class}" style="${iconConfig.edit.style}" data-row="${index}" data-sheet-row="${row.sheetRowIndex}" data-type="salary" aria-label="Edit entry">${iconConfig.edit.content}</span>`
        : "", // Edit
      userPermission === "admin"
        ? `<span class="${iconConfig.delete.class}" style="${iconConfig.delete.style}" data-row="${index}" data-sheet-row="${row.sheetRowIndex}" data-type="salary" aria-label="Delete entry">${iconConfig.delete.content}</span>`
        : "" // Delete
    ];
    tr.innerHTML = cells.map(cell => `<td>${cell}</td>`).join("");
    tableBody.appendChild(tr);
  });

  document.querySelectorAll(".edit-action").forEach(action => {
    action.addEventListener("click", (e) => {
      e.preventDefault();
      const rowIndex = parseInt(e.target.getAttribute("data-row"));
      const sheetRowIndex = parseInt(e.target.getAttribute("data-sheet-row"));
      const row = filteredRows[rowIndex].data;
      showModalSalary(row, sheetRowIndex, userPermission);
    });
  });

  document.querySelectorAll(".delete-action").forEach(action => {
    action.addEventListener("click", async (e) => {
      e.preventDefault();
      const rowIndex = parseInt(e.target.getAttribute("data-row"));
      const sheetRowIndex = parseInt(e.target.getAttribute("data-sheet-row"));

      if (userPermission !== "admin") {
        alert("Only Admins can delete entries.");
        return;
      }

      if (!confirm("Are you sure you want to delete this salary entry? This action cannot be undone.")) {
        e.preventDefault();
        return;
      }

      try {
        const token = await new Promise((resolve, reject) => {
          chrome.identity.getAuthToken({ interactive: true }, (token) => {
            if (chrome.runtime.lastError || !token) {
              reject(new Error(chrome.runtime.lastError?.message || ""));
            } else {
              resolve(token);
            }
          });
        });

        await deleteSheetRow(token, "salary", sheetRowIndex);
        alert("Salary entry deleted successfully.");
        displayDataSalary(
          document.getElementById("usernameFilter").value,
          document.getElementById("statusFilter").value,
          document.getElementById("reasonFilter").value,
          document.getElementById("monthFilter").value,
          userPermission
        );
      } catch (error) {
        console.error("Error deleting salary entry:", error);
        alert(`Error deleting salary entry: ${error.message}`);
      }
    });
  });
}