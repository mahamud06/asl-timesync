function disableConsoleLog() {
  console.log = function() {};
}
// Call disableConsoleLog() to disable console logging
disableConsoleLog();

async function showModalEmployee(row, sheetRowIndex, userPermission) {
  console.log('showModalEmployee called with:', { row, sheetRowIndex, userPermission });

  try {
    // Store data in sessionStorage
    sessionStorage.setItem('employeeData', JSON.stringify({
      row,
      sheetRowIndex,
      userPermission
    }));
    console.log('sessionStorage set:', sessionStorage.getItem('employeeData'));

    // Attempt to open the new window
    const employeeDetailsWindow = window.open('employeeDetails.html', '_blank');
    if (!employeeDetailsWindow) {
      console.error('Failed to open employeeDetails.html. Pop-ups may be blocked.');
      alert('Failed to open details page. Please allow pop-ups for this site.');
      return;
    }
    console.log('employeeDetails.html opened successfully');
  } catch (error) {
    console.error('Error in showModalEmployee:', error);
    alert('Error opening employee details: ' + error.message);
  }
}

async function displayDataEmployee(usernameFilter = "", statusFilter = "", departmentFilter = "", designationFilter = "", joinedByMonthFilter = "", terminatedByMonthFilter = "", userPermission = "") {
  const tableBody = document.querySelector("#employeeTable tbody");
  const employeeTableContainer = document.getElementById("employeeTableContainer");
  const allowedRoles = ["admin", "accountant", "teamlead", "assistant", "hr", "manager", "ceo"];
  const addEmployeeRoles = ["admin", "hr", "manager", "ceo", "assistant"];

  // Adjusted colspan to 11 to account for the new S/N column
  if (employeeTableContainer.classList.contains("hidden") || !allowedRoles.includes(userPermission)) {
    tableBody.innerHTML = "<tr><td colspan='11'>No permission to view employee data.</td></tr>";
    return;
  }

  try {
    const rows = await fetchData("employee");
    let filteredRows = rows;

    // Calculate next available sheetRowIndex
    const nextRowIndex = rows.length > 0 ? Math.max(...rows.map(row => row.sheetRowIndex)) + 1 : 2;
    console.log('Next row index:', nextRowIndex);

    if (addEmployeeRoles.includes(userPermission)) {
      const addButton = document.querySelector(".add-employee-btn");

      if (addButton) {
        addButton.classList.remove("hidden"); // Ensure button is visible if user has permission
        console.log('Add New Employee button found and made visible');

        addButton.addEventListener("click", () => {
          console.log('Add New Employee button clicked');
          showModalEmployee([], nextRowIndex, userPermission);
        });
      } else {
        console.log('Add New Employee button not found');
      }
    }

    // Filtering logic
    if (usernameFilter) {
      filteredRows = filteredRows.filter(row => row.data[0]?.toUpperCase().includes(usernameFilter.toUpperCase()));
    }
    if (statusFilter) {
      filteredRows = filteredRows.filter(row => {
        const employmentStatus = row.data[30]?.trim().toUpperCase();
        const filterValue = statusFilter.toUpperCase();
        if (!employmentStatus) {
          console.warn(`Employment status missing for row ${row.sheetRowIndex}`);
          return false;
        }
        return employmentStatus === filterValue;
      });
    }
    if (departmentFilter) {
      filteredRows = filteredRows.filter(row => row.data[7]?.toUpperCase().includes(departmentFilter.toUpperCase()));
    }
    if (designationFilter) {
      filteredRows = filteredRows.filter(row => row.data[9]?.toUpperCase().includes(designationFilter.toUpperCase()));
    }
    if (joinedByMonthFilter) {
      filteredRows = filteredRows.filter(row => {
        const joinDate = row.data[6];
        if (!joinDate) {
          console.warn(`Join date missing for row ${row.sheetRowIndex}`);
          return false;
        }
        const monthYear = parseJoinDate(joinDate);
        if (!monthYear) return false;
        return monthYear === joinedByMonthFilter;
      });
    }
    if (terminatedByMonthFilter) {
      filteredRows = filteredRows.filter(row => {
        const terminationDate = row.data[31];
        const monthYear = parseTerminationDate(terminationDate);
        return monthYear === terminatedByMonthFilter;
      });
    }

    if (filteredRows.length === 0) {
      // Adjusted colspan to 11 to account for the new S/N column
      tableBody.innerHTML = "<tr><td colspan='11'>No matching data found.</td></tr>";
      return;
    }

    tableBody.innerHTML = "";

    filteredRows.forEach((row, index) => { // Added index parameter here
      const tr = document.createElement("tr");
      const profilePic = row.data[21] || "";
      let imageCell = "";

      if (profilePic && profilePic.startsWith("http")) {
        const fileIdMatch = profilePic.match(/\/d\/([a-zA-Z0-9_-]{33})\/view/) || profilePic.match(/mock\/([a-zA-Z0-9_-]+)/);
        if (fileIdMatch && fileIdMatch[1]) {
          const fileId = fileIdMatch[1];
          imageCell = `<a href="${profilePic}" target="_blank">
            <img src="https://drive.google.com/thumbnail?id=${fileId}&sz=w80"
              style="width: 50px; height: 50px; object-fit: cover; border-radius: 50%;"
              onerror="this.src='https://via.placeholder.com/50?text=No+Image';">
            </a>`;
        } else {
          imageCell = `<span>No image</span>`;
        }
      } else {
        imageCell = `<span>No image</span>`;
      }

      const editButton = allowedRoles.includes(userPermission)
        ? `<span class="${iconConfig.edit.class} edit-action" style="${iconConfig.edit.style}" aria-label="Edit entry">${iconConfig.edit.content}</span>`
        : "";

      const deleteButton = userPermission === "admin"
        ? `<span class="${iconConfig.delete.class} delete-action" style="${iconConfig.delete.style}" aria-label="Delete entry">${iconConfig.delete.content}</span>`
        : "";

      const cells = [
        index + 1, // **S/N - Added dynamic serial number**
        row.data[0] || "",
        row.data[3] || "",
        row.data[1] || "",
        row.data[7] || "",
        row.data[9] || "",
        row.data[8] || "",
        imageCell,
        row.data[30] || "",
        editButton,
        deleteButton
      ];

      tr.innerHTML = cells.map(cell => `<td>${cell}</td>`).join("");
      tableBody.appendChild(tr);

      if (editButton) {
        const editAction = tr.querySelector(".edit-action");
        if (editAction) {
          editAction.addEventListener("click", (e) => {
            e.preventDefault();
            console.log('Edit button clicked for row:', row.sheetRowIndex);
            showModalEmployee(row.data, row.sheetRowIndex, userPermission);
          });
        } else {
          console.warn('Edit button not found for row:', row.sheetRowIndex);
        }
      }

      if (deleteButton) {
        tr.querySelector(".delete-action")?.addEventListener("click", async (e) => {
          e.preventDefault();

          if (userPermission !== "admin") {
            alert("Only Admins can delete entries.");
            return;
          }

          if (!confirm("Are you sure you want to delete this employee record? This action cannot be undone.")) {
            return;
          }

          try {
            const token = await new Promise((resolve, reject) => {
              chrome.identity.getAuthToken({ interactive: true }, (token) => {
                if (chrome.runtime.lastError || !token) {
                  reject(new Error(chrome.runtime.lastError?.message || "Authentication failed"));
                } else {
                  resolve(token);
                }
              });
            });

            await deleteSheetRow(token, "employee", row.sheetRowIndex);
            alert("Employee record deleted successfully.");

            displayDataEmployee(
              document.getElementById("usernameFilter")?.value || "",
              document.getElementById("employmentStatusFilter")?.value || "",
              document.getElementById("departmentFilter")?.value || "",
              document.getElementById("designationFilter")?.value || "",
              document.getElementById("joinedByMonthFilter")?.value || "",
              document.getElementById("terminatedByMonthFilter")?.value || "",
              userPermission
            );
          } catch (error) {
            console.error("Error deleting employee record:", error);
            alert(`Error deleting employee record: ${error.message}`);
          }
        });
      }
    });
  } catch (error) {
    console.error("Error displaying employee data:", error);
    tableBody.innerHTML = "<tr><td colspan='11'>Error loading data. Please try again later.</td></tr>"; // Adjusted colspan
  }
}