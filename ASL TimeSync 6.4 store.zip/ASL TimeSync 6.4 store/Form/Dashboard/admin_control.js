function disableConsoleLog() {
    console.log = function() {};
}
// Call disableConsoleLog() to disable console logging
disableConsoleLog();

const iconConfig = {
  edit: {
    type: "text",
    content: "Edit",
    class: "edit-action",
    style: "background-color: #007bff; color: white; padding: 4px 8px; border-radius: 4px; cursor: pointer; margin: 0 5px;"
  },
  delete: {
    type: "text",
    content: "Delete",
    class: "delete-action",
    style: "background-color: #dc3545; color: white; padding: 4px 8px; border-radius: 4px; cursor: pointer; margin: 0 5px;"
  }
};

async function getAgentPermission() {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive: true }, (token) => {
      if (chrome.runtime.lastError || !token) {
        reject(new Error("Failed to get auth token: " + (chrome.runtime.lastError?.message || "Unknown error")));
        return;
      }

      chrome.storage.local.get(['sheetId', 'apiKey'], (result) => {
        const sheetId = result.sheetId;
        const googleSheetsApiKey = result.apiKey || "AIzaSyDIuRc7QsUTJ8C5-0yzXeY9bM79-jxyTFY";

        if (!sheetId) {
          reject(new Error("Sheet ID not found in storage."));
          return;
        }

        chrome.storage.local.get("username", (userResult) => {
          const savedUsername = userResult.username?.trim().toUpperCase();
          if (!savedUsername) {
            reject(new Error("Username not found in storage."));
            return;
          }

          const sheetName = "Credential";
          fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!A:M?key=${googleSheetsApiKey}`, {
            method: "GET",
            headers: {
              Authorization: `Bearer ${token}`
            }
          })
          .then(response => response.json())
          .then(data => {
            if (!data.values) {
              reject(new Error("No data found in Credential sheet."));
              return;
            }
            const foundUsername = data.values.find(row => row[0]?.trim().toUpperCase() === savedUsername);
            if (foundUsername) {
              const permission = foundUsername[11]?.trim().toLowerCase() || "viewer";
              resolve(permission);
            } else {
              reject(new Error("Username not found in Credential sheet."));
            }
          })
          .catch(error => reject(new Error(`Failed to fetch permissions: ${error.message}`)));
        });
      });
    });
  });
}

async function getAgentTeamName() {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive: true }, (token) => {
      if (chrome.runtime.lastError || !token) {
        reject(new Error("Failed to get auth token: " + (chrome.runtime.lastError?.message || "Unknown error")));
        return;
      }

      chrome.storage.local.get(['sheetId', 'apiKey'], (result) => {
        const sheetId = result.sheetId;
        const googleSheetsApiKey = result.apiKey || "AIzaSyDIuRc7QsUTJ8C5-0yzXeY9bM79-jxyTFY";

        if (!sheetId) {
          reject(new Error("Sheet ID not found in storage."));
          return;
        }

        chrome.storage.local.get("username", (userResult) => {
          const savedUsername = userResult.username?.trim().toUpperCase();
          if (!savedUsername) {
            reject(new Error("Username not found in storage."));
            return;
          }

          const sheetName = "Credential";
          fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!A:M?key=${googleSheetsApiKey}`, {
            method: "GET",
            headers: {
              Authorization: `Bearer ${token}`
            }
          })
          .then(response => response.json())
          .then(data => {
            if (!data.values) {
              reject(new Error("No data found in Credential sheet."));
              return;
            }
            const foundUsername = data.values.find(row => row[0]?.trim().toUpperCase() === savedUsername);
            if (foundUsername) {
              const teamName = foundUsername[12]?.trim() || "";
              resolve(teamName.split(',').map(team => team.trim())); // Split team names into an array
            } else {
              reject(new Error("Username not found in Credential sheet."));
            }
          })
          .catch(error => reject(new Error(`Failed to fetch team name: ${error.message}`)));
        });
      });
    });
  });
}

async function fetchData(formType) {
  const tableBody = document.querySelector(`#${formType}Table tbody`);
  tableBody.innerHTML = "<tr><td colspan='100'>Loading...</td></tr>";

  try {
    const result = await new Promise((resolve) => {
      chrome.storage.local.get(['sheetId2', 'apiKey'], (result) => {
        resolve(result);
      });
    });
    const sheetId = result.sheetId2;
    const apiKey = result.apiKey || "AIzaSyDIuRc7QsUTJ8C5-0yzXeY9bM79-jxyTFY";

    if (!sheetId) {
      throw new Error("Sheet ID not found in storage.");
    }

    let sheetName;
    if (formType === "ticket") {
      sheetName = "SALARY ISSUES";
    } else if (formType === "leave") {
      sheetName = "PAID_LEAVE_APPLICATIONS";
    } else if (formType === "salary") {
      sheetName = "SALARY_RECALCULATION";
    } else if (formType === "employee") {
      sheetName = "Employee_Management";
    } else if (formType === "agentsMissing") {
      sheetName = "AGENTS_MISSING_DATA";
    } else {
      throw new Error("Invalid form type.");
    }

    const url = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${encodeURIComponent(sheetName)}?key=${apiKey}`;
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`HTTP error ${response.status}: ${response.statusText}`);
    }
    const resultData = await response.json();

    if (!resultData.values || resultData.values.length <= 1) {
      tableBody.innerHTML = "<tr><td colspan='100'>No data found.</td></tr>";
      return [];
    }

    const [headers, ...rows] = resultData.values;
    return rows.map((row, index) => ({ data: row, sheetRowIndex: index + 2 }));
  } catch (error) {
    console.error(`Error fetching ${formType} data:`, error);
    tableBody.innerHTML = `<tr><td colspan='100'>Failed to load data: ${error.message}</td></tr>`;
    return [];
  }
}

async function getSheetId(sheetId, sheetName, apiKey) {
  try {
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}?key=${apiKey}`;
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`HTTP error ${response.status}: ${response.statusText}`);
    }
    const result = await response.json();
    const sheet = result.sheets.find(s => s.properties.title === sheetName);
    if (!sheet) {
      throw new Error(`Sheet ${sheetName} not found`);
    }
    return sheet.properties.sheetId;
  } catch (error) {
    throw new Error(`Failed to get sheet ID for ${sheetName}: ${error.message}`);
  }
}

async function updateSheet(token, formType, sheetRowIndex, status, remark, userPermission) {
  try {
    const result = await new Promise((resolve) => {
      chrome.storage.local.get(['sheetId2', 'apiKey'], (result) => {
        resolve(result);
      });
    });
    const sheetId = result.sheetId2;
    const apiKey = result.apiKey || "AIzaSyDIuRc7QsUTJ8C5-0yzXeY9bM79-jxyTFY";

    if (!sheetId) {
      throw new Error("Sheet ID not found in storage.");
    }

    let sheetName, statusColumn, remarkColumn, assistantRemarkColumn;
    if (formType === "ticket") {
      sheetName = "SALARY ISSUES";
      statusColumn = "E";
      remarkColumn = "F";
      assistantRemarkColumn = null;
    } else if (formType === "leave") {
      sheetName = "PAID_LEAVE_APPLICATIONS";
      statusColumn = "N";
      remarkColumn = "O";
      assistantRemarkColumn = "P";
    } else if (formType === "salary") {
      sheetName = "SALARY_RECALCULATION";
      statusColumn = "J";
      remarkColumn = "K";
      assistantRemarkColumn = null;
    } else if (formType === "employee") {
      sheetName = "Employee_Management";
      statusColumn = "I";
      remarkColumn = "J";
      assistantRemarkColumn = null;
    } else if (formType === "agentsMissing") {
      sheetName = "AGENTS_MISSING_DATA";
      statusColumn = "F";
      remarkColumn = "G";
      assistantRemarkColumn = null;
    } else {
      throw new Error("Invalid form type.");
    }

    const url = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!${statusColumn}${sheetRowIndex}?key=${apiKey}`;
    const response = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    if (!response.ok) {
      throw new Error(`Failed to fetch current status: ${response.status}`);
    }
    const currentData = await response.json();
    const currentStatus = currentData.values?.[0]?.[0] || "Pending";

    const permissionTiers = {
      admin: 1,
      ceo: 2,
      manager: 3,
      hr: 4,
      teamlead: 5,
      teamcoordinator: 6,
      accountant: 7,
      assistant: 7,
      viewer: 8
    };

    const statusToTier = {
      "Approved by Admin": 1,
      "Rejected by Admin": 1,
      "Approved by CEO": 2,
      "Rejected by CEO": 2,
      "Approved by Manager": 3,
      "Rejected by Manager": 3,
      "Approved by HR": 4,
      "Rejected by HR": 4,
      "Approved by Teamlead": 5,
      "Rejected by Teamlead": 5,
      "Approved by Team Coordinator": 6,
      "Rejected by Team Coordinator": 6,
      "Pending": 7
    };

    const currentStatusTier = statusToTier[currentStatus] || 7;
    const userTier = permissionTiers[userPermission] || 8;

    let canUpdate = false;
    if (["admin", "ceo", "manager", "hr", "teamlead", "teamcoordinator"].includes(userPermission)) {
      canUpdate = currentStatusTier >= userTier;
    } else if (userPermission === "assistant" && formType === "leave") {
      canUpdate = true;
    }

    if (!canUpdate) {
      throw new Error("You cannot update this entry as it has been processed.");
    }

    let range, values = "";
    if (formType === "leave" && userPermission === "assistant") {
      range = `${sheetName}!${assistantRemarkColumn}${sheetRowIndex}`;
      values = [[remark]];
    } else if ((formType === "leave" || formType === "ticket" || formType === "salary" || formType === "employee" || formType === "agentsMissing") && remark !== undefined) {
      range = `${sheetName}!${statusColumn}${sheetRowIndex}:${remarkColumn}${sheetRowIndex}`;
      values = [[status, remark]];
    } else {
      range = `${sheetName}!${statusColumn}${sheetRowIndex}`;
      values = [[status]];
    }

    const updateResponse = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${range}?valueInputOption=USER_ENTERED`, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ values })
    });
    if (!updateResponse.ok) {
      const error = await updateResponse.json().catch(() => ({}));
      throw new Error(error.error?.message || `Sheet update failed: ${updateResponse.status}`);
    }
    return await updateResponse.json();
  } catch (error) {
    throw new Error(`Sheet update failed: ${error.message}`);
  }
}

async function deleteSheetRow(token, formType, sheetRowIndex) {
  try {
    const result = await new Promise((resolve) => {
      chrome.storage.local.get(['sheetId2', 'apiKey'], (result) => {
        resolve(result);
      });
    });
    const sheetId = result.sheetId2;
    const apiKey = result.apiKey || "AIzaSyDIuRc7QsUTJ8C5-0yzXeY9bM79-jxyTFY";

    if (!sheetId) {
      throw new Error("Sheet ID not found in storage.");
    }

    let sheetName;
    if (formType === "ticket") {
      sheetName = "SALARY ISSUES";
    } else if (formType === "leave") {
      sheetName = "PAID_LEAVE_APPLICATIONS";
    } else if (formType === "salary") {
      sheetName = "SALARY_RECALCULATION";
    } else if (formType === "employee") {
      sheetName = "Employee_Management";
    } else if (formType === "agentsMissing") {
      sheetName = "AGENTS_MISSING_DATA";
    } else {
      throw new Error("Invalid form type.");
    }

    let gridId;
    try {
      gridId = await getSheetId(sheetId, sheetName, apiKey);
    } catch (error) {
      throw new Error(`Failed to get sheet ID: ${error.message}`);
    }

    const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}:batchUpdate`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        requests: [{
          deleteDimension: {
            range: {
              sheetId: gridId,
              dimension: "ROWS",
              startIndex: sheetRowIndex - 1,
              endIndex: sheetRowIndex
            }
          }
        }]
      })
    });
    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error?.message || `Sheet row deletion failed: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    throw new Error(`Sheet row deletion failed: ${error.message}`);
  }
}

function getMonthYearFromTimestamp(timestamp) {
  if (!timestamp) return null;
  try {
    const date = new Date(timestamp);
    if (isNaN(date)) return null;
    return { month: date.getMonth(), year: date.getFullYear() };
  } catch (error) {
    return null;
  }
}

function parseJoinDate(dateStr) {
  if (!dateStr) return null;
  try {
    // Expecting mm/dd/yyyy format
    const [month, day, year] = dateStr.split("/").map(Number);
    if (!month || !day || !year || isNaN(month) || isNaN(day) || isNaN(year)) {
      return null;
    }
    const monthNames = [
      "January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"
    ];
    return `${monthNames[month - 1]}_${year}`;
  } catch (error) {
    console.warn(`Invalid join date format: ${dateStr}`);
    return null;
  }
}

function parseTerminationDate(dateStr) {
  if (!dateStr) return "";
  try {
    // Expecting mm/dd/yyyy format
    const [month, day, year] = dateStr.split("/").map(Number);
    if (!month || !day || !year || isNaN(month) || isNaN(day) || isNaN(year)) {
      return null;
    }
    const monthNames = [
      "January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"
    ];
    return `${monthNames[month - 1]}_${year}`;
  } catch (error) {
    console.warn(`Invalid termination date format: ${dateStr}`);
    return null;
  }
}

function debounce(func, wait) {
  let timeout;
  return function (...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(this, args), wait);
  };
}

const debouncedDisplayData = debounce((formType, username, status, issueTopic, leaveType, department, designation, reason, month, joinedByMonth, terminatedByMonth, missedStatus, missedDepartment, permission, allowedTeams) => {
  if ((permission === "teamcoordinator" || permission === "assistant") && formType === "ticket") return;
  if ((permission === "teamcoordinator" || permission === "teamlead" || permission === "assistant") && formType === "salary") return;
  if (!["admin", "hr", "manager", "ceo", "assistant", "accountant"].includes(permission) && formType === "employee") return;
  if (formType === "salary") {
    displayDataSalary(username, status, reason, month, permission);
  } else if (formType === "ticket") {
    displayDataTicket(username, status, issueTopic, month, permission);
  } else if (formType === "employee") {
    displayDataEmployee(username, status, department, designation, joinedByMonth, terminatedByMonth, permission);
  } else if (formType === "agentsMissing") {
    displayDataAgentsMissing(username, missedStatus, missedDepartment, permission, allowedTeams);
  } else {
    displayDataLeave(username, status, leaveType, department, month, permission);
  }
}, 300);

document.addEventListener("DOMContentLoaded", () => {
  const ticketTab = document.getElementById("ticketTab");
  const leaveTab = document.getElementById("leaveTab");
  const salaryTab = document.getElementById("salaryTab");
  const employeeTab = document.getElementById("employeeTab");
  const agentsMissingTab = document.getElementById("agentsMissingTab");
  const ticketTableContainer = document.getElementById("ticketTableContainer");
  const leaveTableContainer = document.getElementById("leaveTableContainer");
  const salaryTableContainer = document.getElementById("salaryTableContainer");
  const employeeTableContainer = document.getElementById("employeeTableContainer");
  const agentsMissingTableContainer = document.getElementById("agentsMissingTableContainer");
  const usernameFilter = document.getElementById("usernameFilter");
  const statusFilter = document.getElementById("statusFilter");
  const issueTopicFilter = document.getElementById("issueTopicFilter");
  const leaveTypeFilter = document.getElementById("leaveTypeFilter");
  const departmentFilter = document.getElementById("departmentFilter");
  const designationFilter = document.getElementById("designationFilter");
  const employmentStatusFilter = document.getElementById("employmentStatusFilter");
  const reasonFilter = document.getElementById("reasonFilter");
  const monthFilter = document.getElementById("monthFilter");
  const joinedByMonthFilter = document.getElementById("joinedByMonthFilter");
  const terminatedByMonthFilter = document.getElementById("terminatedByMonthFilter");
  const missedStatusFilter = document.getElementById("missedStatusFilter");
  const missedDepartmentFilter = document.getElementById("missedDepartmentFilter");
  const modal = document.getElementById("detailModal");
  const closeBtn = document.querySelector(".close-btn");

  const now = new Date();
  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];
  const currentMonth = monthNames[now.getMonth()];
  const currentYear = now.getFullYear();
  const dynamicMonthValue = `${currentMonth}_${currentYear}`;
  monthFilter.value = dynamicMonthValue;

  let userPermission = "viewer";
  let allowedTeams = [];

  const populateMissedDepartmentFilter = (teams) => {
    missedDepartmentFilter.innerHTML = '<option value="">All Departments</option>'; // Reset options
    teams.forEach(team => {
      const option = document.createElement("option");
      option.value = team;
      option.textContent = team;
      missedDepartmentFilter.appendChild(option);
    });
  };

const showTab = (tab, tableContainer, filterClass, formType) => {
  [ticketTab, leaveTab, salaryTab, employeeTab, agentsMissingTab].forEach(t => t.classList.remove("active"));
  tab.classList.add("active");
  [ticketTableContainer, leaveTableContainer, salaryTableContainer, employeeTableContainer, agentsMissingTableContainer].forEach(c => c.classList.add("hidden"));
  tableContainer.classList.remove("hidden");
  document.querySelectorAll(".ticket-filter, .leave-filter, .salary-filter, .employee-filter, .agents-missing-filter").forEach(el => el.classList.add("hidden"));
  document.querySelectorAll(`.${filterClass}`).forEach(el => el.classList.remove("hidden"));

  // Use the current missedDepartmentFilter value if available, otherwise use empty string
  const currentMissedDepartment = formType === "agentsMissing" ? missedDepartmentFilter.value : "";

  debouncedDisplayData(
    formType,
    usernameFilter.value,
    formType === "employee" ? employmentStatusFilter.value : statusFilter.value,
    formType === "ticket" ? issueTopicFilter.value : "",
    formType === "leave" ? leaveTypeFilter.value : "",
    formType === "leave" || formType === "employee" || formType === "agentsMissing" ? departmentFilter.value : "",
    formType === "employee" ? designationFilter.value : "",
    formType === "salary" ? reasonFilter.value : "",
    formType !== "employee" ? monthFilter.value : "",
    formType === "employee" ? joinedByMonthFilter.value : "",
    formType === "employee" ? terminatedByMonthFilter.value : "",
    formType === "agentsMissing" ? missedStatusFilter.value : "",
    formType === "agentsMissing" ? currentMissedDepartment : "", // Use current dropdown value
    userPermission,
    allowedTeams
  );
};

  const initializeDashboard = async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const defaultTab = urlParams.get("tab") || localStorage.getItem("defaultTab") || "leave";

    try {
      allowedTeams = await getAgentTeamName();
    } catch (error) {
      console.error("Failed to fetch team names:", error);
      allowedTeams = [];
    }

    // Populate missedDepartmentFilter with allowed teams
    populateMissedDepartmentFilter(allowedTeams);

    // Hide tabs based on user permissions
    if (userPermission === "teamcoordinator" || userPermission === "assistant") {
      ticketTab.style.display = "none";
    }
    if (userPermission === "teamcoordinator" || userPermission === "teamlead" || userPermission === "assistant") {
      salaryTab.style.display = "none";
    }
    if (!["admin", "hr", "manager", "ceo", "assistant", "accountant"].includes(userPermission)) {
      employeeTab.style.display = "none";
    }

    // Initialize the default tab
    if (defaultTab === "ticket" && ticketTab.style.display !== "none") {
      showTab(ticketTab, ticketTableContainer, "ticket-filter", "ticket");
    } else if (defaultTab === "salary" && salaryTab.style.display !== "none") {
      showTab(salaryTab, salaryTableContainer, "salary-filter", "salary");
    } else if (defaultTab === "employee" && employeeTab.style.display !== "none") {
      showTab(employeeTab, employeeTableContainer, "employee-filter", "employee");
    } else if (defaultTab === "agentsMissing" && agentsMissingTab.style.display !== "none") {
      showTab(agentsMissingTab, agentsMissingTableContainer, "agents-missing-filter", "agentsMissing");
    } else {
      showTab(leaveTab, leaveTableContainer, "leave-filter", "leave");
    }
  };

  Promise.all([getAgentPermission(), getAgentTeamName()])
    .then(([permission, teams]) => {
      userPermission = permission || "viewer";
      allowedTeams = teams || [];
      initializeDashboard();
    })
    .catch(error => {
      userPermission = "viewer";
      allowedTeams = [];
      initializeDashboard();
    });

  leaveTab.addEventListener("click", () => {
    showTab(leaveTab, leaveTableContainer, "leave-filter", "leave");
  });

  ticketTab.addEventListener("click", () => {
    if (ticketTab.style.display === "none") {
      return;
    }
    showTab(ticketTab, ticketTableContainer, "ticket-filter", "ticket");
  });

  salaryTab.addEventListener("click", () => {
    if (salaryTab.style.display === "none") {
      return;
    }
    showTab(salaryTab, salaryTableContainer, "salary-filter", "salary");
  });

  employeeTab.addEventListener("click", () => {
    if (employeeTab.style.display === "none") {
      return;
    }
    showTab(employeeTab, employeeTableContainer, "employee-filter", "employee");
  });

  agentsMissingTab.addEventListener("click", () => {
    if (agentsMissingTab.style.display === "none") {
      return;
    }
    showTab(agentsMissingTab, agentsMissingTableContainer, "agents-missing-filter", "agentsMissing");
  });

  usernameFilter.addEventListener("input", () => {
    const activeTab = salaryTab.classList.contains("active") ? "salary" :
                     ticketTab.classList.contains("active") ? "ticket" :
                     employeeTab.classList.contains("active") ? "employee" :
                     agentsMissingTab.classList.contains("active") ? "agentsMissing" : "leave";
    showTab(
      activeTab === "salary" ? salaryTab :
      activeTab === "ticket" ? ticketTab :
      activeTab === "employee" ? employeeTab :
      activeTab === "agentsMissing" ? agentsMissingTab : leaveTab,
      activeTab === "salary" ? salaryTableContainer :
      activeTab === "ticket" ? ticketTableContainer :
      activeTab === "employee" ? employeeTableContainer :
      activeTab === "agentsMissing" ? agentsMissingTableContainer : leaveTableContainer,
      activeTab === "salary" ? "salary-filter" :
      activeTab === "ticket" ? "ticket-filter" :
      activeTab === "employee" ? "employee-filter" :
      activeTab === "agentsMissing" ? "agents-missing-filter" : "leave-filter",
      activeTab
    );
  });

  statusFilter.addEventListener("change", () => {
    const activeTab = salaryTab.classList.contains("active") ? "salary" :
                     ticketTab.classList.contains("active") ? "ticket" :
                     employeeTab.classList.contains("active") ? "employee" :
                     agentsMissingTab.classList.contains("active") ? "agentsMissing" : "leave";
    showTab(
      activeTab === "salary" ? salaryTab :
      activeTab === "ticket" ? ticketTab :
      activeTab === "employee" ? employeeTab :
      activeTab === "agentsMissing" ? agentsMissingTab : leaveTab,
      activeTab === "salary" ? salaryTableContainer :
      activeTab === "ticket" ? ticketTableContainer :
      activeTab === "employee" ? employeeTableContainer :
      activeTab === "agentsMissing" ? agentsMissingTableContainer : leaveTableContainer,
      activeTab === "salary" ? "salary-filter" :
      activeTab === "ticket" ? "ticket-filter" :
      activeTab === "employee" ? "employee-filter" :
      activeTab === "agentsMissing" ? "agents-missing-filter" : "leave-filter",
      activeTab
    );
  });

  employmentStatusFilter.addEventListener("change", () => {
    if (employeeTab.classList.contains("active")) {
      showTab(employeeTab, employeeTableContainer, "employee-filter", "employee");
    }
  });

  leaveTypeFilter.addEventListener("change", () => {
    if (leaveTab.classList.contains("active")) {
      showTab(leaveTab, leaveTableContainer, "leave-filter", "leave");
    }
  });

  departmentFilter.addEventListener("input", () => {
    if (leaveTab.classList.contains("active")) {
      showTab(leaveTab, leaveTableContainer, "leave-filter", "leave");
    } else if (employeeTab.classList.contains("active")) {
      showTab(employeeTab, employeeTableContainer, "employee-filter", "employee");
    } else if (agentsMissingTab.classList.contains("active")) {
      showTab(agentsMissingTab, agentsMissingTableContainer, "agents-missing-filter", "agentsMissing");
    }
  });

  designationFilter.addEventListener("input", () => {
    if (employeeTab.classList.contains("active")) {
      showTab(employeeTab, employeeTableContainer, "employee-filter", "employee");
    }
  });

  issueTopicFilter.addEventListener("change", () => {
    if (ticketTab.classList.contains("active")) {
      showTab(ticketTab, ticketTableContainer, "ticket-filter", "ticket");
    }
  });

  reasonFilter.addEventListener("change", () => {
    if (salaryTab.classList.contains("active")) {
      showTab(salaryTab, salaryTableContainer, "salary-filter", "salary");
    }
  });

  monthFilter.addEventListener("change", () => {
    const activeTab = salaryTab.classList.contains("active") ? "salary" :
                     ticketTab.classList.contains("active") ? "ticket" :
                     employeeTab.classList.contains("active") ? "employee" :
                     agentsMissingTab.classList.contains("active") ? "agentsMissing" : "leave";
    showTab(
      activeTab === "salary" ? salaryTab :
      activeTab === "ticket" ? ticketTab :
      activeTab === "employee" ? employeeTab :
      activeTab === "agentsMissing" ? agentsMissingTab : leaveTab,
      activeTab === "salary" ? salaryTableContainer :
      activeTab === "ticket" ? ticketTableContainer :
      activeTab === "employee" ? employeeTableContainer :
      activeTab === "agentsMissing" ? agentsMissingTableContainer : leaveTableContainer,
      activeTab === "salary" ? "salary-filter" :
      activeTab === "ticket" ? "ticket-filter" :
      activeTab === "employee" ? "employee-filter" :
      activeTab === "agentsMissing" ? "agents-missing-filter" : "leave-filter",
      activeTab
    );
  });

  joinedByMonthFilter.addEventListener("change", () => {
    if (employeeTab.classList.contains("active")) {
      showTab(employeeTab, employeeTableContainer, "employee-filter", "employee");
    }
  });

  terminatedByMonthFilter.addEventListener("change", () => {
    if (employeeTab.classList.contains("active")) {
      showTab(employeeTab, employeeTableContainer, "employee-filter", "employee");
    }
  });

  missedStatusFilter.addEventListener("change", () => {
    if (agentsMissingTab.classList.contains("active")) {
      showTab(agentsMissingTab, agentsMissingTableContainer, "agents-missing-filter", "agentsMissing");
    }
  });

  missedDepartmentFilter.addEventListener("change", () => {
    if (agentsMissingTab.classList.contains("active")) {
      showTab(agentsMissingTab, agentsMissingTableContainer, "agents-missing-filter", "agentsMissing");
    }
  });

  closeBtn.addEventListener("click", () => {
    modal.style.display = "none";
    modal.dispatchEvent(new Event("close"));
  });

  window.addEventListener("click", (e) => {
    if (e.target === modal) {
      modal.style.display = "none";
      modal.dispatchEvent(new Event("close"));
    }
  });

  modal.addEventListener("close", () => {
    const statusText = document.getElementById("statusText");
    const remarkText = document.getElementById("remarkText");
    const assistantRemarkInput = document.getElementById("assistantRemarkInput");
    if (statusText) statusText.remove();
    if (remarkText) remarkText.remove();
    if (assistantRemarkInput) assistantRemarkInput.remove();
  });
});