async function displayDataAgentsMissing(username, missedStatus, department, permission, allowedTeams) {
  const tableBody = document.querySelector("#agentsMissingTable tbody");
  tableBody.innerHTML = "<tr><td colspan='8'>Loading...</td></tr>";

  try {
    const rows = await fetchData("agentsMissing");
    if (rows.length === 0) {
      tableBody.innerHTML = "<tr><td colspan='8'>No data found in the sheet.</td></tr>";
      console.warn("No rows returned from fetchData for agentsMissing.");
      return;
    }

    // Log raw data for inspection
    console.log("Raw data from sheet:", rows.map(row => ({
      fingerPrint: row.data[0],
      fullName: row.data[1],
      department: row.data[2],
      checkInMiss: row.data[3],
      checkOutMiss: row.data[4],
      checkInViolation: row.data[5],
      checkOutViolation: row.data[6]
    })));

    // Use the provided department (from missedDepartmentFilter); treat "All-Teams" as empty string
    const filterDepartment = department === "All-Teams" ? "" : department;

    const filteredRows = rows.filter(row => {
      const data = row.data;
      const rowUsername = data[0]?.trim().toLowerCase() || ""; // FINGER PRINT
      const rowCheckInMiss = data[3]?.trim() || ""; // Check-in miss
      const rowCheckOutMiss = data[4]?.trim() || ""; // Check-out miss
      const rowDepartment = data[2]?.trim().toLowerCase() || ""; // Department

      // Department filter: match provided department or any allowed team
      const departmentMatch = filterDepartment
        ? rowDepartment.includes(filterDepartment.toLowerCase())
        : (allowedTeams ? allowedTeams.some(team => rowDepartment.includes(team.toLowerCase())) : true);

      // Missed status filter
      let missedStatusMatch = true;
      if (missedStatus) {
        if (missedStatus === "Check-in Missed") {
          missedStatusMatch = rowCheckInMiss !== "";
        } else if (missedStatus === "Check-out Missed") {
          missedStatusMatch = rowCheckOutMiss !== "";
        }
      }

      // Debugging: Log filter evaluation for each row
      console.log(`Row ${row.sheetRowIndex}:`, {
        username: rowUsername,
        checkInMiss: rowCheckInMiss,
        checkOutMiss: rowCheckOutMiss,
        department: rowDepartment,
        usernameMatch: !username || rowUsername.includes(username.toLowerCase()),
        missedStatusMatch,
        departmentMatch,
        filterValues: { username, missedStatus, filterDepartment, allowedTeams }
      });

      return (
        (!username || rowUsername.includes(username.toLowerCase())) &&
        missedStatusMatch &&
        departmentMatch
      );
    });

    tableBody.innerHTML = "";
    if (filteredRows.length === 0) {
      tableBody.innerHTML = "<tr><td colspan='8'>No data found for the selected filters.</td></tr>";
      console.warn("No rows matched the filters:", {
        username,
        missedStatus,
        filterDepartment,
        allowedTeams
      });
      return;
    }

    filteredRows.forEach((row, index) => {
      const data = row.data;
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${index + 1}</td>
        <td>${data[0] || ""}</td> <!-- FINGER PRINT -->
        <td>${data[1] || ""}</td> <!-- Full name -->
        <td>${data[2] || ""}</td> <!-- Department -->
        <td>${data[3] || ""}</td> <!-- Check-in miss -->
        <td>${data[4] || ""}</td> <!-- Check-out miss -->
        <td>${data[5] || ""}</td> <!-- Check-in time violation -->
        <td>${data[6] || ""}</td> <!-- Check-out time violation -->
      `;
      tableBody.appendChild(tr);
    });

    // Only set missedDepartmentFilter on initial load if no department is selected
    const missedDepartmentFilter = document.getElementById("missedDepartmentFilter");
    if (!department && missedDepartmentFilter.value === "" && allowedTeams && allowedTeams.length > 0) {
      missedDepartmentFilter.value = allowedTeams[0];
    }
  } catch (error) {
    tableBody.innerHTML = `<tr><td colspan='8'>Failed to load data: ${error.message}</td></tr>`;
    console.error("Error in displayDataAgentsMissing:", error);
  }
}