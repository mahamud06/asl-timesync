function disableConsoleLog() {
    console.log = function() {};
}

// Call disableConsoleLog() to disable console logging (centralized here)
disableConsoleLog();

function getAgentPermission() {
    return new Promise((resolve, reject) => {
        chrome.identity.getAuthToken({ interactive: true }, function (token) {
            if (chrome.runtime.lastError || !token) {
                reject(new Error("Failed to get auth token: " + (chrome.runtime.lastError?.message || "Unknown error")));
                return;
            }

            chrome.storage.local.get(['sheetId'], (result) => {
                const sheetId = result.sheetId;
                const googleSheetsApiKey = "AIzaSyDIuRc7QsUTJ8C5-0yzXeY9bM79-jxyTFY";

                if (!sheetId) {
                    reject(new Error("Sheet ID not found in chrome.storage.local."));
                    return;
                }

                chrome.storage.local.get("username", (userResult) => {
                    const savedUsername = userResult.username?.trim().toUpperCase();

                    if (!savedUsername) {
                        reject(new Error("Saved username not found in storage."));
                        return;
                    }

                    const sheetName = "Credential";

                    fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!A:L?key=${googleSheetsApiKey}`, {
                        method: "GET",
                        headers: {
                            Authorization: `Bearer ${token}`
                        }
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }
                        return response.json();
                    })
                    .then(data => {
                        const foundUsername = data.values?.find(row => row[0]?.trim().toUpperCase() === savedUsername);

                        if (foundUsername) {
                            const permission = foundUsername[11]?.trim().toLowerCase();
                            resolve(permission);
                        } else {
                            reject(new Error("Username not found in the spreadsheet."));
                        }
                    })
                    .catch(error => {
                        reject(error);
                    });
                });
            });
        });
    });
}

function populateUsernameFromStorage() {
    return new Promise((resolve) => {
        chrome.storage.local.get("username", (userResult) => {
            const username = userResult.username?.trim().toUpperCase();
            if (username) {
                const inputs = [
                    document.getElementById("issueUsername"),
                    document.getElementById("leaveUsername"),
                    document.getElementById("salaryUsername")
                ];
                inputs.forEach(input => {
                    if (input) {
                        input.value = username;
                        input.readOnly = true;
                    }
                });
            }
            resolve(username);
        });
    });
}

async function uploadToDrive(token, file) {
    const metadata = {
        name: file.name,
        mimeType: file.type,
        parents: ['1C25n7dRnlv4sPWWb5czho1p48FvieQje']
    };

    const form = new FormData();
    form.append("metadata", new Blob([JSON.stringify(metadata)], {
        type: "application/json"
    }));
    form.append("file", file);

    return fetch("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: form
    })
    .then(async (res) => {
        if (!res.ok) {
            const error = await res.json().catch(() => ({}));
            throw new Error(error.error?.message || `Drive upload failed: ${res.status}`);
        }
        return res.json();
    });
}

async function appendToSheet(token, formType, values) {
    try {
        const result = await new Promise((resolve) => {
            chrome.storage.local.get(['sheetId2', 'apiKey'], (result) => {
                resolve(result);
            });
        });
        const sheetId = result.sheetId2;
        const apiKey = result.apiKey || "AIzaSyDIuRc7QsUTJ8C5-0yzXeY9bM79-jxyTFY";

        if (!sheetId) {
            throw new Error("Sheet ID not found in storage.");
        }

        let sheetName;
        let range;
        switch (formType) {
            case "ticket":
                sheetName = "SALARY ISSUES";
                range = "A:I"; // Matches 8 columns: Username, Timestamp, Description, Attachment, Status, Remark, Issue Topic, Effective Date
                break;
            case "leave":
                sheetName = "PAID_LEAVE_APPLICATIONS";
                range = "A:O"; // Matches leave form fields
                break;
            case "salary":
                sheetName = "SALARY_RECALCULATION";
                range = "A:J"; // Matches 10 columns: Username, Full Name, Department, Effective Month, Received Amount, Expected Amount, Reason, Description, Attachment, Status
                break;
            default:
                throw new Error(`Invalid formType: ${formType}`);
        }

        console.debug(`Appending to sheet: ${sheetName} with range: ${range}, values:`, values);

        const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!${range}:append?valueInputOption=USER_ENTERED`, {
            method: "POST",
            headers: {
                Authorization: `Bearer ${token}`,
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ values: [values] })
        });

        if (!response.ok) {
            const error = await response.json().catch(() => ({}));
            throw new Error(error.error?.message || `Sheet append failed: ${response.status}`);
        }
        return response.json();
    } catch (error) {
        console.error(`Error appending to sheet (${formType}):`, error);
        throw error;
    }
}

function showStatus(statusElement, message, color) {
    if (statusElement) {
        statusElement.textContent = message;
        statusElement.style.color = color;
    }
}

function validateDateFormat(dateStr) {
    if (!dateStr) return false;
    const dates = dateStr.split(",");
    if (dates.length === 0) return false;
    return dates.every(date => {
        const trimmed = date.trim();
        return /^\d{2}\/\d{2}\/\d{4}$/.test(trimmed) && !isNaN(new Date(trimmed));
    });
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}




document.addEventListener("DOMContentLoaded", () => {
    populateUsernameFromStorage();

    const ticketForm = document.getElementById("ticketForm");
    const leaveForm = document.getElementById("leaveForm");
    const ticketHistoryBox = document.getElementById("ticketHistoryBox");
    const leaveHistoryBox = document.getElementById("leaveHistoryBox");
    const submitTicketBtn = document.getElementById("submitTicketBtn");
    const paidLeaveBtn = document.getElementById("paidLeaveBtn");
    const submitLeaveBtn = document.getElementById("submitLeaveBtn");
    const leaveStatus = document.getElementById("leaveStatus");
    const statsTableContainer = document.querySelector(".stats-table-container");
    const eligibilityIndicator = document.getElementById("eligibilityIndicator");
    const agentProfileBtn = document.getElementById("agentprofile"); // Add reference to My Profile button
    const agentattendence = document.getElementById("Attendence_sheet"); // Add reference to My Profile button

    // Event listener for My Profile button
    agentProfileBtn.addEventListener("click", () => {
        window.open('employeeDetails.html', '_blank');
    });

    agentattendence.addEventListener("click", () => {
        window.open('Attendence.html', '_blank');
    });
    submitTicketBtn.addEventListener("click", () => {
        ticketForm.classList.remove("hidden");
        leaveForm.classList.add("hidden");
        // Note: There seems to be an issue in your code where salaryForm is referenced but not defined
        // salaryForm.classList.remove("hidden"); // Fix or remove this line
        ticketHistoryBox.classList.remove("hidden");
        leaveHistoryBox.classList.add("hidden");
        statsTableContainer.classList.add("hidden");
        eligibilityIndicator.classList.add("hidden");
        displayReportedDataTicket();
    });

    paidLeaveBtn.addEventListener("click", () => {
        ticketForm.classList.add("hidden");
        leaveForm.classList.remove("hidden");
        ticketHistoryBox.classList.add("hidden");
        leaveHistoryBox.classList.remove("hidden");
        statsTableContainer.classList.remove("hidden");
        eligibilityIndicator.classList.remove("hidden");
        displayReportedDataLeave();
        fetchLeaveStats();
    });

submitLeaveBtn.addEventListener("click", async () => {
    chrome.storage.local.get("username", async (userResult) => {
        const username = (userResult.username || "").trim();
        const fullName = document.getElementById("fullName").value.trim();
        const leaveType = document.getElementById("leaveType").value;
        const leaveEffectiveDate = document.getElementById("leaveEffectiveDate").value.trim();
        const department = document.getElementById("department").value.trim();
        const designation = document.getElementById("designation").value.trim();
        const subject = document.getElementById("leaveSubject").value.trim();
        const description = document.getElementById("leaveDescription").value.trim();
        const file = document.getElementById("leaveFileInput").files[0];

        if (!username || !fullName || !leaveType || !leaveEffectiveDate || !department || !designation || !subject || !description) {
            showStatus(leaveStatus, "Please fill in all required fields.", "red");
            return;
        }

        if (!["Sick", "Paid", "Unpaid"].includes(leaveType)) {
            showStatus(leaveStatus, "Please select a valid leave type.", "red");
            return;
        }

        if (!validateDateFormat(leaveEffectiveDate)) {
            showStatus(leaveStatus, "Please enter Effective Date(s) in mm/dd/yyyy,mm/dd/yyyy,... format.", "red");
            return;
        }

        const numberOfDays = calculateNumberOfDays(leaveEffectiveDate);
        if (numberOfDays === 0) {
            showStatus(leaveStatus, "No valid dates provided.", "red");
            return;
        }

        const daysPreview = document.getElementById("daysPreview");
        daysPreview.textContent = `Total days: ${numberOfDays}`;

        showStatus(leaveStatus, "Submitting your leave application, please wait...", "blue");

        chrome.identity.getAuthToken({ interactive: true }, async (token) => {
            if (chrome.runtime.lastError || !token) {
                showStatus(leaveStatus, "Authentication failed: " + chrome.runtime.lastError?.message, "red");
                return;
            }

            try {
                await writeUsernameToSheet(token); // Ensure this function is correctly defined and works

                const stats = await fetchLeaveStats(); // Ensure this function is correctly defined and works
                const totalAvailed = stats.totalAvailed;
                const outstanding = stats.outstanding;

                let imageUrl = "";
                if (file) {
                    const uploaded = await uploadToDrive(token, file); // Ensure this function is correctly defined and works
                    imageUrl = `https://drive.google.com/file/d/${uploaded.id}/view`;
                }

                // --- CHANGE STARTS HERE ---
                const now = new Date();
                const formattedTimestamp = now.toLocaleString('en-US', {
                    month: '2-digit',
                    day: '2-digit',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: true // Ensures AM/PM
                });
                // --- CHANGE ENDS HERE ---

                // Ensure the order matches your Google Sheet for leave applications
                // The values array should correspond to the exact columns in your "LEAVE APPLICATIONS" sheet.
                const values = [username, fullName, leaveType, formattedTimestamp, leaveEffectiveDate, numberOfDays, department, designation, subject, description, imageUrl, totalAvailed, outstanding, "Pending", ""];
                await appendToSheet(token, "leave", values); // Ensure appendToSheet is correctly defined and handles "leave" type
                showStatus(leaveStatus, "Leave application submitted successfully.", "green");

                document.getElementById("fullName").value = "";
                document.getElementById("leaveType").value = "";
                document.getElementById("leaveEffectiveDate").value = "";
                document.getElementById("department").value = "";
                document.getElementById("designation").value = "";
                document.getElementById("leaveSubject").value = "";
                document.getElementById("leaveDescription").value = "";
                document.getElementById("leaveFileInput").value = "";
                document.getElementById("daysPreview").textContent = "";
                displayReportedDataLeave(); // Ensure this function is correctly defined and works
            } catch (error) {
                console.error("Error:", error);
                showStatus(leaveStatus, `Error: ${error.message}`, "red");
            }
        });
    });
});
	
	
});