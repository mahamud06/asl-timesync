     function disableConsoleLog() {
    console.log = function() {};
}
// Call disableConsoleLog() to disable console logging
disableConsoleLog();

async function writeUsernameToSheet(token) {
    try {
        const result = await new Promise((resolve) => {
            chrome.storage.local.get(['sheetId2', 'username'], (result) => {
                resolve(result);
            });
        });
        const sheetId = result.sheetId2;
        const username = result.username?.trim().toUpperCase();
        const apiKey = "AIzaSyDIuRc7QsUTJ8C5-0yzXeY9bM79-jxyTFY";

        if (!sheetId) {
            throw new Error("Sheet ID not found in storage.");
        }
        if (!username) {
            throw new Error("Username not found in storage.");
        }

        const sheetName = "PAID_LEAVE_STATE";
        const range = "D2";
        const url = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${encodeURIComponent(sheetName)}!${range}?valueInputOption=USER_ENTERED`;

        const response = await fetch(url, {
            method: "PUT",
            headers: {
                Authorization: `Bearer ${token}`,
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                values: [[username]]
            })
        });

        if (!response.ok) {
            const error = await response.json().catch(() => ({}));
            throw new Error(error.error?.message || `Failed to write username to sheet: ${response.status}`);
        }

        console.log(`Username ${username} written to ${sheetName}!${range}`);
        return true;
    } catch (error) {
        console.error("Error writing username to sheet:", error);
        return false;
    }
}

async function fetchLeaveStats() {
    const statsTableBody = document.querySelector("#statsTable tbody");
    const eligibilityIndicator = document.getElementById("eligibilityIndicator");

    statsTableBody.innerHTML = "<tr><td>Loading...</td><td></td></tr>";
    eligibilityIndicator.textContent = "Loading...";

    try {
        const token = await new Promise((resolve, reject) => {
            chrome.identity.getAuthToken({ interactive: true }, (token) => {
                if (chrome.runtime.lastError || !token) {
                    reject(new Error("Authentication failed: " + chrome.runtime.lastError?.message));
                } else {
                    resolve(token);
                }
            });
        });

        await writeUsernameToSheet(token);

        const result = await new Promise((resolve) => {
            chrome.storage.local.get(['sheetId2', 'apiKey'], (result) => {
                resolve(result);
            });
        });
        const sheetId = result.sheetId2;
        const apiKey = result.apiKey || "AIzaSyDIuRc7QsUTJ8C5-0yzXeY9bM79-jxyTFY";

        if (!sheetId) {
            throw new Error("Sheet ID not found in storage.");
        }

        const sheetName = "PAID_LEAVE_STATE";
        const range = "A1:E";
        const url = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${encodeURIComponent(sheetName)}!${range}?key=${apiKey}`;

        const response = await fetch(url);
        const resultData = await response.json();

        if (!resultData.values || resultData.values.length === 0) {
            statsTableBody.innerHTML = "<tr><td>No data found</td><td></td></tr>";
            eligibilityIndicator.textContent = "PAID LEAVE NOT ELIGIBLE";
            eligibilityIndicator.classList.add("not-eligible");
            return { totalAvailed: "0", outstanding: "0" };
        }

        const validRows = resultData.values.filter(row => row[0] && row[1]);
        if (validRows.length === 0) {
            statsTableBody.innerHTML = "<tr><td>No valid data found</td><td></td></tr>";
            eligibilityIndicator.textContent = "PAID LEAVE NOT ELIGIBLE";
            eligibilityIndicator.classList.add("not-eligible");
            return { totalAvailed: "0", outstanding: "0" };
        }

        statsTableBody.innerHTML = validRows.map(row => `
            <tr>
                <td>${row[0] || "Unknown Metric"}</td>
                <td>${row[1] || "0"}</td>
            </tr>
        `).join("");

        const c2Value = resultData.values[1] && resultData.values[1][2] ? parseFloat(resultData.values[1][2]) : 0;
        if (c2Value > 0) {
            eligibilityIndicator.textContent = "PAID LEAVE ELIGIBLE";
            eligibilityIndicator.classList.remove("not-eligible");
        } else {
            eligibilityIndicator.textContent = "PAID LEAVE NOT ELIGIBLE";
            eligibilityIndicator.classList.add("not-eligible");
        }

        return {
            totalAvailed: validRows[0] && validRows[0][1] || "0",
            outstanding: validRows[1] && validRows[1][1] || "0"
        };
    } catch (error) {
        console.error("Error fetching leave stats:", error);
        statsTableBody.innerHTML = "<tr><td>Failed to load data</td><td></td></tr>";
        eligibilityIndicator.textContent = "PAID LEAVE NOT ELIGIBLE";
        eligibilityIndicator.classList.add("not-eligible");
        return { totalAvailed: "0", outstanding: "0" };
    }
}

function calculateNumberOfDays(leaveEffectiveDate) {
    if (!leaveEffectiveDate) return 0;
    const dates = leaveEffectiveDate.split(",");
    const validDates = dates.filter(date => /^\d{2}\/\d{2}\/\d{4}$/.test(date.trim()) && !isNaN(new Date(date.trim())));
    return validDates.length;
}

async function displayReportedDataLeave() {
    const dataDisplayBox = document.getElementById("leaveHistoryContent");
    dataDisplayBox.innerHTML = "Loading...";

    chrome.storage.local.get("username", async (userResult) => {
        const username = userResult.username?.toUpperCase();
        if (!username) {
            dataDisplayBox.innerHTML = "Please login to view your submissions.";
            return;
        }

        try {
            const result = await new Promise((resolve) => {
                chrome.storage.local.get(['sheetId2', 'apiKey'], (result) => {
                    resolve(result);
                });
            });
            const sheetId = result.sheetId2;
            const apiKey = result.apiKey || "AIzaSyDIuRc7QsUTJ8C5-0yzXeY9bM79-jxyTFY";

            if (!sheetId) {
                throw new Error("Sheet ID not found in storage.");
            }

            const sheetName = "PAID_LEAVE_APPLICATIONS";
            const url = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${encodeURIComponent(sheetName)}?key=${apiKey}`;

            const response = await fetch(url);
            const resultData = await response.json();

            if (!resultData.values || resultData.values.length === 0) {
                dataDisplayBox.innerHTML = "No data found.";
                return;
            }

            const [headers, ...rows] = resultData.values;
            const filteredRows = rows.filter(row => row[0]?.toUpperCase() === username);

            if (filteredRows.length === 0) {
                dataDisplayBox.innerHTML = `<div style="text-align: center;">No reported data found for your account.</div>`;
                return;
            }

            filteredRows.sort((a, b) => {
                const dateA = new Date(a[3] || "1/1/1970");
                const dateB = new Date(b[3] || "1/1/1970");
                return dateB - dateA;
            });

            let tableHTML = "<table border='1' cellpadding='5' cellspacing='0' style='width: 100%; border-collapse: collapse;'>";
            const leaveHeaders = ["Username", "Leave Type", "Timestamp", "Effective Date", "Subject", "Attachment", "Status", "Remark", "Approved Days"];
            const columnIndices = [0, 2, 3, 4, 8, 10, 13, 14, 15];
            tableHTML += "<thead><tr style='background-color: #f9f9f9;'>" + 
                leaveHeaders.map(h => `<th>${h}</th>`).join("") + 
                `<th class="action-column">Action</th></tr></thead>`;
            tableHTML += "<tbody>";
            filteredRows.forEach((row, index) => {
                tableHTML += "<tr>" + columnIndices.map((colIndex, i) => {
                    const cellData = row[colIndex] || "";
                    const truncatedData = cellData.length > 10 ? cellData.substring(0, 10) + "..." : cellData;
                    if (i === 5 && cellData.startsWith("http")) {
                        return `<td class="attachment-column" style="text-align: center;"><a href="${cellData}" target="_blank" style="color: blue;">View</a></td>`;
                    }
                    return `<td>${truncatedData}</td>`;
                }).join("") + 
                `<td class="action-column"><a href="#" class="view-details" data-row="${index}" data-form-type="leave" style="color: blue;">View Details</a></td></tr>`;
            });
            tableHTML += "</tbody></table>";

            dataDisplayBox.innerHTML = tableHTML;

            const modal = document.getElementById("leaveDetailModal");
            const modalContent = document.getElementById("modalContent");
            const closeBtn = document.querySelector(".close-btn");

            document.querySelectorAll(".view-details").forEach(link => {
                link.addEventListener("click", (e) => {
                    e.preventDefault();
                    const rowIndex = parseInt(e.target.getAttribute("data-row"));
                    const row = filteredRows[rowIndex];
                    
                    let modalHTML = `<div style="position: relative;">`;
                    const fullHeaders = ["Username", "Full Name", "Leave Type", "Timestamp", "Effective Date", "Number of Days", "Department", "Designation", "Subject", "Description", "Attachment", "Total Availed", "Outstanding", "Status", "Remark", "Approved Days"];
                    
                    fullHeaders.forEach((header, i) => {
                        let cellData = row[i] || "";
                        if (i === 9) {
                            cellData = cellData.replace(/\n/g, "<br>");
                        }
                        if (i === 6 || i === 7) {
                            if (i === 6) {
                                modalHTML += `<div class="modal-input-row">`;
                                modalHTML += `<div><label>${fullHeaders[6]}:</label> <span>${row[6] || ""}</span></div>`;
                                modalHTML += `<div><label>${fullHeaders[7]}:</label> <span>${row[7] || ""}</span></div>`;
                                modalHTML += `</div>`;
                            }
                        } else if (i === 10) {
                            if (cellData.startsWith("http")) {
                                const fileIdMatch = cellData.match(/\/d\/([a-zA-Z0-9_-]{33})\/view/);
                                if (fileIdMatch && fileIdMatch[1]) {
                                    const fileId = fileIdMatch[1];
                                    modalHTML += `
                                        <p>
                                            <strong>${header}:</strong>
                                            <img src="https://drive.google.com/thumbnail?id=${fileId}&sz=w100" 
                                                 style="width: 100px; height: auto; border: 1px solid #ccc; margin: 5px;" 
                                                 class="loading" 
                                                 onload="this.classList.remove('loading');" 
                                                 onerror="this.src='https://via.placeholder.com/100?text=Image+Not+Available';this.classList.remove('loading');console.error('Thumbnail load failed for URL: ${cellData}');">
                                            <a href="${cellData}" target="_blank" style="color: blue;">View Full File</a>
                                        </p>`;
                                } else {
                                    console.error("Invalid Google Drive URL:", cellData);
                                    modalHTML += `<p><strong>${header}:</strong> <a href="${cellData}" target="_blank" style="color: blue;">View File</a></p>`;
                                }
                            } else {
                                modalHTML += `<p><strong>${header}:</strong> No attachment</p>`;
                            }
                        } else if (i !== 7) {
                            modalHTML += `<p><strong>${header}:</strong> ${cellData}</p>`;
                        }
                    });

                    modalHTML += `
                        <button id="printDetailsBtn" style="position: absolute; top: 10px; right: 10px; padding: 5px 10px; font-size: 14px; background-color: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer;">
                            Print/Save as PDF
                        </button>
                    `;
                    modalHTML += `</div>`;

                    modalContent.innerHTML = modalHTML;
                    modal.style.display = "flex";

                    const printBtn = document.getElementById("printDetailsBtn");
                    printBtn.addEventListener("click", () => {
                        const printContent = modalContent.cloneNode(true);
                        printContent.querySelector("#printDetailsBtn").remove();
                        
                        const printWindow = window.open('', '_blank');
                        printWindow.document.write(`
                            <html>
                                <head>
                                    <title>Leave Application Details</title>
                                    <style>
                                        body { font-family: Arial, sans-serif; padding: 20px; }
                                        p { margin: 10px 0; }
                                        strong { display: inline-block; width: 150px; }
                                        img { max-width: 100px; height: auto; border: 1px solid #ccc; margin: 5px; }
                                        .modal-input-row { display: flex; gap: 20px; }
                                        .modal-input-row div { flex: 1; }
                                    </style>
                                </head>
                                <body>
                                    <div id="printContent">${printContent.innerHTML}</div>
                                    <script>
                                        window.print();
                                    </script>
                                </body>
                            </html>
                        `);
                        printWindow.document.close();
                    });
                });
            });

            closeBtn.removeEventListener("click", closeModal);
            closeBtn.addEventListener("click", closeModal);

            window.removeEventListener("click", windowClickHandler);
            window.addEventListener("click", windowClickHandler);

            function closeModal() {
                modal.style.display = "none";
            }

            function windowClickHandler(e) {
                if (e.target === modal) {
                    modal.style.display = "none";
                }
            }
        } catch (error) {
            console.error("Error loading reported data:", error);
            dataDisplayBox.innerHTML = "Failed to load data.";
        }
    });
}
