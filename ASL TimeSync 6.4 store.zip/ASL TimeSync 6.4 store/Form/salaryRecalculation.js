     function disableConsoleLog() {
    console.log = function() {};
}
// Call disableConsoleLog() to disable console logging
disableConsoleLog();


async function uploadToDrive(token, file) {
    try {
        const metadata = {
            name: file.name,
            mimeType: file.type
        };

        const formData = new FormData();
        formData.append("metadata", new Blob([JSON.stringify(metadata)], { type: "application/json" }));
        formData.append("file", file);

        const response = await fetch("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart", {
            method: "POST",
            headers: {
                Authorization: `Bearer ${token}`
            },
            body: formData
        });

        if (!response.ok) {
            const error = await response.json().catch(() => ({}));
            throw new Error(error.error?.message || `Failed to upload file: ${response.status}`);
        }

        const result = await response.json();
        return { id: result.id };
    } catch (error) {
        console.error("Error uploading file to Drive:", error);
        throw error;
    }
}


async function displaySalaryRecalculationData() {
    const dataDisplayBox = document.getElementById("salaryHistoryContent");
    if (!dataDisplayBox) {
        console.error("salaryHistoryContent element not found in DOM.");
        return;
    }
    dataDisplayBox.innerHTML = "Loading...";

    try {
        console.log("Fetching username from chrome.storage.local...");
        const userResult = await new Promise((resolve) => {
            chrome.storage.local.get("username", (result) => {
                resolve(result);
            });
        });
        const username = userResult.username?.toUpperCase();
        console.log("Username retrieved:", username);

        if (!username) {
            dataDisplayBox.innerHTML = "Please login to view your submissions.";
            console.warn("No username found in storage.");
            return;
        }

        console.log("Fetching sheetId2 and apiKey from chrome.storage.local...");
        const result = await new Promise((resolve) => {
            chrome.storage.local.get(['sheetId2', 'apiKey'], (result) => {
                resolve(result);
            });
        });
        const sheetId = result.sheetId2;
        const apiKey = result.apiKey || "AIzaSyDIuRc7QsUTJ8C5-0yzXeY9bM79-jxyTFY";
        console.log("Sheet ID:", sheetId, "API Key:", apiKey ? "Set" : "Default");

        if (!sheetId) {
            throw new Error("Sheet ID not found in storage.");
        }

        const sheetName = "Salary_Recalculation";
        const url = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${encodeURIComponent(sheetName)}?key=${apiKey}`;
        console.log("Fetching data from URL:", url);

        let response;
        try {
            response = await fetch(url);
        } catch (err) {
            console.error("Initial fetch failed, retrying once...", err);
            response = await fetch(url); // Retry once
        }

        if (!response.ok) {
            const error = await response.json().catch(() => ({}));
            const errorMessage = error.error?.message || `Failed to fetch data: ${response.status}`;
            console.error("Fetch error:", errorMessage);
            throw new Error(errorMessage);
        }

        const resultData = await response.json();
        console.log("Raw API response:", resultData);

        if (!resultData.values || resultData.values.length === 0) {
            dataDisplayBox.innerHTML = "No data found in the Salary_Recalculation sheet.";
            console.log("No values found in sheet.");
            return;
        }

        const [headers, ...rows] = resultData.values;
        console.log("Sheet headers:", headers);
        console.log("Rows:", rows);

        if (!headers || headers.length < 12) {
            dataDisplayBox.innerHTML = "Invalid sheet structure: insufficient headers.";
            console.error("Invalid headers:", headers);
            return;
        }

        const filteredRows = rows.filter(row => row[0]?.toUpperCase() === username);
        console.log("Filtered rows for username", username, ":", filteredRows);

        if (filteredRows.length === 0) {
            dataDisplayBox.innerHTML = `<div style="text-align: center;">No reported data found for your account.</div>`;
            console.log("No rows match username:", username);
            return;
        }

        filteredRows.sort((a, b) => {
            const dateA = new Date(a[3] || "1/1/1970");
            const dateB = new Date(b[3] || "1/1/1970");
            return dateB - dateA;
        });

        let tableHTML = "<table border='1' cellpadding='5' cellspacing='0' style='width: 100%; border-collapse: collapse;'>";
        const salaryHeaders = ["Username", "Department", "Reason", "Timestamp", "Effective Month", "Received Amount", "Expected Amount", "Attachment", "Status", "Remark"];
        const columnIndices = [0, 2, 7, 3, 4, 5, 6, 8, 9, 10];
        tableHTML += "<thead><tr style='background-color: #f9f9f9;'>" + 
            salaryHeaders.map(h => `<th>${h}</th>`).join("") + 
            `<th class="action-column">Action</th></tr></thead>`;
        tableHTML += "<tbody>";
        filteredRows.forEach((row, index) => {
            tableHTML += "<tr>" + columnIndices.map((colIndex, i) => {
                const cellData = row[colIndex] || "";
                const truncatedData = cellData.length > 10 ? cellData.substring(0, 10) + "..." : cellData;
                if (i === 7 && cellData.startsWith("http")) {
                    return `<td class="attachment-column" style="text-align: center;"><a href="${cellData}" target="_blank" style="color: blue;">View</a></td>`;
                }
                return `<td>${truncatedData}</td>`;
            }).join("") + 
            `<td class="action-column"><a href="#" class="view-details" data-row="${index}" data-form-type="salary" style="color: blue;">View Details</a></td></tr>`;
        });
        tableHTML += "</tbody></table>";

        dataDisplayBox.innerHTML = tableHTML;
        console.log("Table rendered successfully.");

        const modal = document.getElementById("leaveDetailModal");
        const modalContent = document.getElementById("modalContent");
        const closeBtn = document.querySelector(".close-btn");

        if (!modal || !modalContent || !closeBtn) {
            console.error("Modal elements not found:", { modal, modalContent, closeBtn });
            return;
        }

        document.querySelectorAll(".view-details").forEach(link => {
            link.addEventListener("click", (e) => {
                e.preventDefault();
                const rowIndex = parseInt(e.target.getAttribute("data-row"));
                const row = filteredRows[rowIndex];
                console.log("View details for row:", row);
                
                let modalHTML = `<div style="position: relative;">`;
                const fullHeaders = ["Username", "Full Name", "Department", "Timestamp", "Effective Month", "Received Amount", "Expected Amount", "Reason", "Description", "Attachment", "Status", "Remark"];
                const columnIndicesModal = [0, 1, 2, 3, 4, 5, 6, 7, 11, 8, 9, 10];

                columnIndicesModal.forEach((colIndex, i) => {
                    const header = fullHeaders[i];
                    let cellData = row[colIndex] || "";
                    if (i === 7 || i === 8) { // Reason or Description
                        cellData = cellData.replace(/\n/g, "<br>");
                    }
                    if (i === 9) { // Attachment
                        if (cellData.startsWith("http")) {
                            const fileIdMatch = cellData.match(/\/d\/([a-zA-Z0-9_-]{33})\/view/);
                            if (fileIdMatch && fileIdMatch[1]) {
                                const fileId = fileIdMatch[1];
                                modalHTML += `
                                    <p>
                                        <strong>${header}:</strong>
                                        <img src="https://drive.google.com/thumbnail?id=${fileId}&sz=w100" 
                                             style="width: 100px; height: auto; border: 1px solid #ccc; margin: 5px;" 
                                             class="loading" 
                                             onload="this.classList.remove('loading');" 
                                             onerror="this.src='https://via.placeholder.com/100?text=Image+Not+Available';this.classList.remove('loading');console.error('Thumbnail load failed for URL: ${cellData}');">
                                        <a href="${cellData}" target="_blank" style="color: blue;">View Full File</a>
                                    </p>`;
                            } else {
                                console.error("Invalid Google Drive URL:", cellData);
                                modalHTML += `<p><strong>${header}:</strong> <a href="${cellData}" target="_blank" style="color: blue;">View File</a></p>`;
                            }
                        } else {
                            modalHTML += `<p><strong>${header}:</strong> No attachment</p>`;
                        }
                    } else {
                        modalHTML += `<p><strong>${header}:</strong> ${cellData}</p>`;
                    }
                });

                modalHTML += `
                    <button id="printDetailsBtn" style="position: absolute; top: 10px; right: 10px; padding: 5px 10px; font-size: 14px; background-color: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer;">
                        Print/Save as PDF
                    </button>
                `;
                modalHTML += `</div>`;

                modalContent.innerHTML = modalHTML;
                modal.style.display = "flex";

                const printBtn = document.getElementById("printDetailsBtn");
                printBtn.addEventListener("click", () => {
                    const printContent = modalContent.cloneNode(true);
                    printContent.querySelector("#printDetailsBtn").remove();
                    
                    const printWindow = window.open('', '_blank');
                    printWindow.document.write(`
                        <html>
                            <head>
                                <title>Salary Recalculation Details</title>
                                <style>
                                    body { font-family: Arial, sans-serif; padding: 20px; }
                                    p { margin: 10px 0; }
                                    strong { display: inline-block; width: 150px; }
                                    img { max-width: 100px; height: auto; border: 1px solid #ccc; margin: 5px; }
                                </style>
                            </head>
                            <body>
                                <div id="printContent">${printContent.innerHTML}</div>
                                <script>
                                    window.print();
                                </script>
                            </body>
                        </html>
                    `);
                    printWindow.document.close();
                });
            });
        });

        closeBtn.removeEventListener("click", closeModal);
        closeBtn.addEventListener("click", closeModal);

        window.removeEventListener("click", windowClickHandler);
        window.addEventListener("click", windowClickHandler);

        function closeModal() {
            modal.style.display = "none";
        }

        function windowClickHandler(e) {
            if (e.target === modal) {
                modal.style.display = "none";
            }
        }
    } catch (error) {
        console.error("Error loading reported data:", error);
        dataDisplayBox.innerHTML = `Failed to load data: ${error.message}. Please check the console for details.`;
    }
}

function showStatus(element, message, color) {
    element.textContent = message;
    element.style.color = color;
}

document.addEventListener("DOMContentLoaded", () => {
    populateUsernameFromStorage();

    const salaryForm = document.getElementById("salaryRecalculationForm");
    const salaryHistoryBox = document.getElementById("salaryHistoryBox");
    const submitSalaryBtn = document.getElementById("submitSalaryBtn");
    const salaryStatus = document.getElementById("salaryStatus");
    const salaryRecalculationBtn = document.getElementById("salaryRecalculationBtn");
    const ticketForm = document.getElementById("ticketForm");
    const leaveForm = document.getElementById("leaveForm");
    const ticketHistoryBox = document.getElementById("ticketHistoryBox");
    const leaveHistoryBox = document.getElementById("leaveHistoryBox");
    const statsTableContainer = document.querySelector(".stats-table-container");
    const eligibilityIndicator = document.getElementById("eligibilityIndicator");

    salaryRecalculationBtn.addEventListener("click", () => {
        ticketForm.classList.add("hidden");
        leaveForm.classList.add("hidden");
        salaryForm.classList.remove("hidden");
        ticketHistoryBox.classList.add("hidden");
        leaveHistoryBox.classList.add("hidden");
        salaryHistoryBox.classList.remove("hidden");
        statsTableContainer.classList.add("hidden");
        eligibilityIndicator.classList.add("hidden");

        chrome.storage.local.get("username", (result) => {
            if (result.username) {
                document.getElementById("salaryUsername").value = result.username;
            } else {
                console.warn("No username found in storage.");
                document.getElementById("salaryUsername").value = "";
            }
        });

        displaySalaryRecalculationData();
    });

submitSalaryBtn.addEventListener("click", async () => {
    chrome.storage.local.get("username", async (userResult) => {
        const username = (userResult.username || "").trim();
        const fullName = document.getElementById("salaryFullName").value.trim();
        const department = document.getElementById("salaryDepartment").value.trim();
        const effectiveMonth = document.getElementById("effectiveMonth").value;
        const receivedAmount = document.getElementById("receivedAmount").value;
        const expectedAmount = document.getElementById("expectedAmount").value;
        const reason = document.getElementById("salaryReason").value;
        const description = document.getElementById("salaryDescription").value.trim();
        const file = document.getElementById("salaryFileInput").files[0];

        if (!username || !fullName || !department || !effectiveMonth || !receivedAmount || !expectedAmount || !reason || !description) {
            showStatus(salaryStatus, "Please fill in all required fields.", "red");
            return;
        }

        if (!["January_2025", "February_2025", "March_2025", "April_2025", "May_2025", "June_2025",
            "July_2025", "August_2025", "September_2025", "October_2025", "November_2025", "December_2025"].includes(effectiveMonth)) {
            showStatus(salaryStatus, "Please select a valid month.", "red");
            return;
        }

        if (!["Payroll calculation error", "Night Allowance", "Overtime Adjustment", "Bonus Discrepancy", "Deduction Issue", "Others"].includes(reason)) {
            showStatus(salaryStatus, "Please select a valid reason.", "red");
            return;
        }

        if (isNaN(receivedAmount) || receivedAmount < 0) {
            showStatus(salaryStatus, "Please enter a valid received amount.", "red");
            return;
        }

        if (isNaN(expectedAmount) || expectedAmount < 0) {
            showStatus(salaryStatus, "Please enter a valid expected amount.", "red");
            return;
        }

        showStatus(salaryStatus, "Submitting your salary recalculation request, please wait...", "blue");

        chrome.identity.getAuthToken({ interactive: true }, async (token) => {
            if (chrome.runtime.lastError || !token) {
                const errorMsg = chrome.runtime.lastError?.message || "Unknown authentication error";
                console.error("Authentication failed:", errorMsg);
                showStatus(salaryStatus, `Authentication failed: ${errorMsg}`, "red");
                return;
            }

            console.log("OAuth token retrieved:", token);

            try {
                let imageUrl = "";
                if (file) {
                    console.log("Uploading file to Google Drive...");
                    const uploaded = await uploadToDrive(token, file);
                    imageUrl = `https://drive.google.com/file/d/${uploaded.id}/view`;
                    console.log("File uploaded, URL:", imageUrl);
                }

                // --- CHANGE STARTS HERE ---
                const now = new Date();
                const formattedTimestamp = now.toLocaleString('en-US', {
                    month: '2-digit',
                    day: '2-digit',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: true // Ensures AM/PM
                });
                // --- CHANGE ENDS HERE ---

                // Ensure the order matches your Google Sheet for salary recalculation requests
                const values = [username, fullName, department, formattedTimestamp, effectiveMonth, receivedAmount, expectedAmount, reason, imageUrl, "Pending", "", description];
                console.log("Appending data to sheet:", values);
                await appendToSheet(token, "salary", values);
                showStatus(salaryStatus, "Salary recalculation request submitted successfully.", "green");

                document.getElementById("salaryFullName").value = "";
                document.getElementById("salaryDepartment").value = "";
                document.getElementById("effectiveMonth").value = "";
                document.getElementById("receivedAmount").value = "";
                document.getElementById("expectedAmount").value = "";
                document.getElementById("salaryReason").value = "";
                document.getElementById("salaryDescription").value = "";
                document.getElementById("salaryFileInput").value = "";
                displaySalaryRecalculationData(); // Make sure this function is correctly defined and works
            } catch (error) {
                console.error("Submission error:", error);
                showStatus(salaryStatus, `Error: ${error.message}`, "red");
            }
        });
    });
});
	
	
});