async function getAuthToken() {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ 
      interactive: true,
      scopes: [
        'https://www.googleapis.com/auth/drive.file',
        'https://www.googleapis.com/auth/spreadsheets',
        'https://www.googleapis.com/auth/userinfo.email'
      ]
    }, (token) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(token);
    });
  });
}

// Function to create and display a notification
function showNotification(title, message) {
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'Images/icon48.png',
    title: title,
    message: message,
    priority: 2
  });
}

// Listener for messages (from options.js)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'showNotification') {
    showNotification(request.title, request.message);
    sendResponse({ status: 'Notification shown' });
  }

  if (request.action === 'scheduleAlarm') {
    const [hours, minutes] = request.time.split(':').map(Number);
    const now = new Date();
    const alarmTime = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hours, minutes, 0, 0);

    // If the scheduled time is already passed today, schedule for tomorrow
    if (alarmTime < now) {
      alarmTime.setDate(alarmTime.getDate() + 1);
    }

    const delayInMinutes = (alarmTime.getTime() - now.getTime()) / 60000;

    // Create a unique alarm name for each time
    chrome.alarms.create(`dailyReminder_${request.time}`, {
      when: Date.now() + delayInMinutes * 60000,
      periodInMinutes: 1440 // Repeat every 24 hours
    });

    console.log('Alarm scheduled at:', alarmTime.toString(), `for time key: dailyReminder_${request.time}`);
  }

  // ? NEW: Cancel an alarm when a notification is deleted
  if (request.action === 'cancelAlarm') {
    const alarmName = `dailyReminder_${request.time}`;
    chrome.alarms.clear(alarmName, (wasCleared) => {
      console.log(wasCleared
        ? `Alarm "${alarmName}" canceled successfully.`
        : `Alarm "${alarmName}" was not found.`);
    });
  }
});

// Alarm trigger
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name.startsWith('dailyReminder_')) {
    const scheduledTime = alarm.name.replace('dailyReminder_', '');

    chrome.storage.sync.get('notifications', (data) => {
      const notifications = data.notifications || [];
      const matched = notifications.find(n => n.dailyNotificationTime === scheduledTime);

      if (matched) {
        showNotification(matched.notificationTitle, matched.notificationMessage);
      } else {
        showNotification('Reminder', 'This is your scheduled notification.');
      }
    });
  }
});



 function disableConsoleLog() {
    console.log = function() {};
}
disableConsoleLog() ;



   function clearSheetIdsFromStorage() {
    chrome.storage.local.remove(['sheetId', 'sheetId2', 'sheetId3'], () => {
        if (chrome.runtime.lastError) {
            console.error("? Error removing sheet IDs:", chrome.runtime.lastError);
        } else {
            console.log("??? Sheet IDs removed successfully from storage");

            // Optional verification
            chrome.storage.local.get(['sheetId', 'sheetId2', 'sheetId3'], (result) => {
                if (!result.sheetId && !result.sheetId2 && !result.sheetId3) {
                    console.log("?? Verification: All Sheet IDs successfully removed");
                } else {
                    console.warn("?? Some Sheet IDs still exist in storage:", result);
                }
            });
        }
    });
}
 
 //clearSheetIdsFromStorage();


chrome.identity.getAuthToken({ interactive: true }, function(token) {
  if (chrome.runtime.lastError) {
    console.error(chrome.runtime.lastError);
    return;
  }

  // Use the token for API requests
  console.log("Access token:", token);
 
});

let badgeText = "";

function updateBadgeText() {
  chrome.action.setBadgeText({ text: badgeText });
}

// Listen for installation or update of the extension
chrome.runtime.onInstalled.addListener(function() {
  // Update badge text when extension is installed or updated
  updateBadgeText();
});

// Listen for messages from other parts of the extension
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === "updateBadge") {
    badgeText = request.text;
    updateBadgeText();
  }
});

chrome.runtime.onInstalled.addListener(() => {
    console.log("Extension installed");

    // Show a notification when the extension is installed
    chrome.notifications.create('welcome-notification', {
        type: 'basic',
        iconUrl: 'Images/icon48.png',
        title: 'Welcome!',
        message: 'Thank you for installing our extension.',
        priority: 2
    });
});





const googleSheetsApiKey = "AIzaSyDIuRc7QsUTJ8C5-0yzXeY9bM79-jxyTFY";


const IDLE_THRESHOLD = 60000; // 60 seconds (1 minute)
let lastUpdate = Date.now();
let activeTime = 0;
let idleTime = 0;
let currentStatus = "active";
let idleTimeout;
let currentTabURL = "Unknown";
let isTrackingEnabled = false;

console.log("? Background script loaded.");

// Initialize the extension
function initializeTracking() {
    chrome.storage.local.get(['activityUpload', 'activeTime', 'idleTime', 'status'], (data) => {
        isTrackingEnabled = data.activityUpload === 'turnon';
        
        if (isTrackingEnabled) {
            activeTime = data.activeTime || 0;
            idleTime = data.idleTime || 0;
            currentStatus = data.status || 'active';
         //   console.log("?? Loaded from storage:", { activeTime, idleTime, currentStatus });
            setActive(); // Start tracking
        } else {
            console.log('? Upload is turned off. Tracking not started.');
        }
    });
}

// Update time tracking
function updateTimes() {
    if (!isTrackingEnabled) return;

    const now = Date.now();
    const timeElapsed = now - lastUpdate;

    if (currentStatus === "active") {
        activeTime += timeElapsed;
        console.log(`? Active time +${timeElapsed}ms (Total: ${activeTime}ms)`);
    } else {
        idleTime += timeElapsed;
        console.log(`?? Idle time +${timeElapsed}ms (Total: ${idleTime}ms)`);
    }

    chrome.storage.local.set({ 
        activeTime, 
        idleTime, 
        status: currentStatus 
    }, () => {
        if (chrome.runtime.lastError) {
            console.error("? Storage error:", chrome.runtime.lastError);
        }
    });

    lastUpdate = now;
	
}

// Set user as active
function setActive() {
    if (!isTrackingEnabled) return;

    clearTimeout(idleTimeout);

    if (currentStatus !== "active") {
        updateTimes(); // Record any idle time before switching
        currentStatus = "active";
        chrome.storage.local.set({ status: "active" });
        console.log("?? User is now ACTIVE");
    }

    idleTimeout = setTimeout(() => {
        setIdle();
    }, IDLE_THRESHOLD);
}

// Set user as idle
function setIdle() {
    if (!isTrackingEnabled) return;

    if (currentStatus !== "idle") {
        updateTimes(); // Record any active time before switching
        currentStatus = "idle";
        chrome.storage.local.set({ status: "idle" });
        console.log("?? User is now IDLE");
    }
}

// Message listener for activity from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === "activity") {
        console.log("?? Activity detected from tab:", sender.tab?.url);
        setActive();
        sendResponse({ status: "received" });
    }
    return true;
});

// Window focus change handler
chrome.windows.onFocusChanged.addListener((windowId) => {
    console.log("?? Window focus changed to:", windowId);
    if (windowId === chrome.windows.WINDOW_ID_NONE) {
        setIdle();
    } else {
        setActive();
    }
});

// Tab URL tracking
function updateCurrentTabURL() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]?.url) {
            currentTabURL = tabs[0].url;
            console.log("?? Current tab URL:", currentTabURL);
        }
    });
}

// Tab event listeners
chrome.tabs.onActivated.addListener(updateCurrentTabURL);
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo.url || changeInfo.status === "complete") {
        updateCurrentTabURL();
    }
});

async function getLastWorkingDay() {
    return new Promise((resolve, reject) => {
        chrome.storage.local.get(["username", "sheetId3"], (result) => {
            const username = result.username;
            const sheetId = result.sheetId3;

            if (!username) {
                reject("Username not found in Chrome storage");
                return;
            }

            if (!sheetId) {
                reject("sheetId3 not found in Chrome storage");
                return;
            }

            chrome.identity.getAuthToken({ interactive: true }, (token) => {
                if (chrome.runtime.lastError || !token) {
                    reject("Authentication failed");
                    return;
                }

                const sheetName = "Credential";
                const url = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetName}!A:C?key=${googleSheetsApiKey}`;

                fetch(url, {
                    method: "GET",
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                })
                .then(response => response.json())
                .then(data => {
                    const foundUser = data.values?.find(row => row[0] === username);
                    if (foundUser && foundUser[2]) {
                        resolve(foundUser[2]); // Column C
                    } else {
                        reject("Username not found or no data in column C");
                    }
                })
                .catch(error => {
                    console.error("Fetch error:", error);
                    reject("Error fetching data from Google Sheets");
                });
            });
        });
    });
}


async function uploadActivityToSheet() {
    if (!isTrackingEnabled) {
        console.log('? Upload is turned off. Skipping sheet update.');
        return;
    }

    try {
        // Get username and sheetId3 from Chrome storage
        const { username, sheetId3 } = await new Promise((resolve, reject) => {
            chrome.storage.local.get(["username", "sheetId3"], (result) => {
                if (!result.username) {
                    reject("Username not found in Chrome storage");
                } else if (!result.sheetId3) {
                    reject("sheetId3 not found in Chrome storage");
                } else {
                    resolve(result);
                }
            });
        });

        const savedSheetName = await getLastWorkingDay();
        console.log("?? Last Working Day:", savedSheetName);

        const token = await new Promise((resolve, reject) => {
            chrome.identity.getAuthToken({ interactive: true }, function (token) {
                if (chrome.runtime.lastError || !token) {
                    reject("No auth token available");
                } else {
                    resolve(token);
                }
            });
        });

        // Get sheet headers
        const headersResponse = await fetch(
            `https://sheets.googleapis.com/v4/spreadsheets/${sheetId3}/values/${savedSheetName}!1:1?key=${googleSheetsApiKey}`,
            { headers: { Authorization: `Bearer ${token}` } }
        );

        const headersData = await headersResponse.json();
        if (!headersData.values) throw new Error("No headers found in sheet");

        const userColumnIndex = headersData.values[0].indexOf(username);
        if (userColumnIndex === -1) throw new Error("User column not found");

        console.log(`?? User column index: ${userColumnIndex}`);
        const columnLetter = getColumnLetter(userColumnIndex + 4); // Adjust if needed

        // Format times
        const activeTimeFormatted = formatTime(activeTime);
        const idleTimeFormatted = formatTime(idleTime);

        // Merge data into one string
        const mergedInfo = `?? URL: ${currentTabURL}\n?? Active: ${activeTimeFormatted}\n?? Idle: ${idleTimeFormatted}`;

        // Upload the merged info to row 30
        await updateGoogleSheet(savedSheetName, columnLetter, 30, mergedInfo, token);

    } catch (error) {
        console.error("? Sheet update error:", error);
    }
}




async function updateGoogleSheet(sheetName, column, row, value, token) {
    const range = `${sheetName}!${column}${row}`;
    const payload = { values: [[value]] };

    try {
        // Get sheetId3 from Chrome storage
        const sheetId = await new Promise((resolve, reject) => {
            chrome.storage.local.get("sheetId3", (result) => {
                if (result.sheetId3) {
                    resolve(result.sheetId3);
                } else {
                    reject("sheetId3 not found in Chrome storage");
                }
            });
        });

        const response = await fetch(
            `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${range}?valueInputOption=RAW&key=${googleSheetsApiKey}`,
            {
                method: "PUT",
                headers: {
                    Authorization: `Bearer ${token}`,
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(payload),
            }
        );

        const result = await response.json();
        console.log(`? Updated ${range}:`, result);

    } catch (error) {
        console.error(`? Error updating ${range}:`, error);
    }
}


function formatTime(ms) {
    const date = new Date(ms);
    return date.toISOString().substr(11, 8);
}

function getColumnLetter(index) {
    let column = "";
    while (index >= 0) {
        column = String.fromCharCode((index % 26) + 65) + column;
        index = Math.floor(index / 26) - 1;
    }
    return column;
}

// Listen for tracking toggle changes
chrome.storage.onChanged.addListener((changes) => {
    if (changes.activityUpload) {
        isTrackingEnabled = changes.activityUpload.newValue === 'turnon';
        console.log(isTrackingEnabled ? "?? Tracking enabled" : "?? Tracking disabled");
        
        if (isTrackingEnabled) {
            initializeTracking();
        } else {
            clearTimeout(idleTimeout);
        }
    }
});

// Initialize
initializeTracking();
setInterval(() => {
    chrome.storage.local.get('username', (result) => {
        if (chrome.runtime.lastError) {
            console.error("Error retrieving username from Chrome storage:", chrome.runtime.lastError);
            return;
        }

        if (result.username && result.username.trim() !== '') {
            updateTimes();  // Only call updateTimes if username is not empty
        }
    });
}, 1000);

setInterval(() => {
    chrome.storage.local.get('username', (result) => {
        if (chrome.runtime.lastError) {
            console.error("Error retrieving username from Chrome storage:", chrome.runtime.lastError);
            return;
        }

        if (result.username && result.username.trim() !== '') {
            uploadActivityToSheet();  // Only call uploadActivityToSheet if username is not empty
        }
    });
}, 60000);  // Runs every 60 seconds


chrome.runtime.onInstalled.addListener(() => {
    console.log('?? Extension installed/updated');
    chrome.storage.local.set({ activityUpload: 'turnon' }); // Default to enabled
});










const GOOGLE_SHEETS_API_KEY = "AIzaSyDIuRc7QsUTJ8C5-0yzXeY9bM79-jxyTFY"; // your Sheets API key
const PARENT_FOLDER_ID = "1C25n7dRnlv4sPWWb5czho1p48FvieQje"; // your Drive folder ID
const SHEET_NAME = "Credential";

let captureIntervalId = null;
let permissionCheckIntervalId = null;

// Helper: promisify chrome.storage.local.get
function chromeStorageGet(keys) {
  return new Promise((resolve) => {
    chrome.storage.local.get(keys, resolve);
  });
}

// Get OAuth token for Google APIs
function getAuthToken(interactive = false) {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive }, token => {
      if (chrome.runtime.lastError || !token) {
        reject(chrome.runtime.lastError || new Error("Failed to get auth token"));
      } else {
        resolve(token);
      }
    });
  });
}

async function fetchPermissionAndInterval(username, sheetId) {
  try {
    const token = await getAuthToken(false);
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${SHEET_NAME}!A:J?key=${GOOGLE_SHEETS_API_KEY}`;
    const response = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` }
    });
    const data = await response.json();
    const rows = data.values || [];

    const rowIndex = rows.findIndex(row =>
      row[0]?.trim().toUpperCase() === username.trim().toUpperCase()
    );
    if (rowIndex === -1) return { permission: false, interval: 60000, quality: 10 };

    const rawCell = rows[rowIndex][9] || "";
    const [permissionRaw, intervalRaw, qualityRaw] = rawCell.split(',');

    const permission = permissionRaw?.trim().toLowerCase() === "yes";
    const interval = parseInt(intervalRaw?.trim(), 10) || 60000;
    const quality = parseInt(qualityRaw?.trim(), 10) || 10;

    return { permission, interval, quality };
  } catch (e) {
    console.error("Error fetching permission/interval:", e);
    return { permission: false, interval: 60000, quality: 10 };
  }
}


// Ensures a subfolder exists under a parent folder
async function ensureSubFolderExists(parentFolderId, folderName, token) {
  const q = `'${parentFolderId}' in parents and name='${folderName}' and mimeType='application/vnd.google-apps.folder' and trashed=false`;
  const searchUrl = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(q)}&fields=files(id,name)`;

  const res = await fetch(searchUrl, {
    headers: { Authorization: `Bearer ${token}` }
  });

  const data = await res.json();
  if (data.files && data.files.length > 0) {
    return data.files[0].id; // Return existing folder ID
  }

  // Create the folder
  const metadata = {
    name: folderName,
    mimeType: "application/vnd.google-apps.folder",
    parents: [parentFolderId]
  };

  const createRes = await fetch("https://www.googleapis.com/drive/v3/files", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(metadata)
  });

  const folder = await createRes.json();
  return folder.id;
}


async function captureAndUpload() {
  try {
    const { username, sheetId } = await chromeStorageGet(['username', 'sheetId']);
    if (!username || !sheetId) {
      console.warn("Missing username or sheetId");
      return;
    }

    const allowedData = await fetchPermissionAndInterval(username, sheetId);
    if (!allowedData.permission) {
      console.log("Permission revoked, stopping uploads.");
      clearInterval(captureIntervalId);
      captureIntervalId = null;
      return;
    }

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) {
      console.warn("No active tab");
      return;
    }

    const imageUri = await chrome.tabs.captureVisibleTab(tab.windowId, {
      format: "jpeg",
      quality: allowedData.quality || 10  // Use dynamic quality
    });

    const blob = await (await fetch(imageUri)).blob();
    const token = await getAuthToken(false);

    const now = new Date();
    const dateFolderName = now.toLocaleDateString('en-US').replace(/\//g, '-'); // MM-DD-YY
    const timestamp = now.toLocaleTimeString('en-US', { hour12: false }).replace(/:/g, '-'); // HH-MM-SS
    const fileName = `${dateFolderName} ${timestamp}.png`;

    const userFolderId = await ensureSubFolderExists(PARENT_FOLDER_ID, username, token);
    const dateFolderId = await ensureSubFolderExists(userFolderId, dateFolderName, token);

    const metadata = {
      name: fileName,
      parents: [dateFolderId],
      mimeType: "image/png"
    };

    const form = new FormData();
    form.append("metadata", new Blob([JSON.stringify(metadata)], { type: "application/json" }));
    form.append("file", blob);

    const uploadRes = await fetch("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart", {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
      body: form
    });

    const uploadResult = await uploadRes.json();
    console.log(`✅ Uploaded screenshot: ${fileName} (id: ${uploadResult.id})`);

  } catch (e) {
    console.error("❌ Error capturing/uploading screenshot:", e);
  }
}



// Periodically check permission & interval, adjust screenshot uploads accordingly
async function checkPermissionIntervalLoop() {
  try {
    const { username, sheetId } = await chromeStorageGet(['username', 'sheetId']);
    if (!username || !sheetId) {
      console.warn("Missing username or sheetId");
      return;
    }

    const { permission, interval } = await fetchPermissionAndInterval(username, sheetId);

    if (!permission) {
      console.log("Permission not granted. Stopping upload interval.");
      if (captureIntervalId) {
        clearInterval(captureIntervalId);
        captureIntervalId = null;
      }
      return;
    }

    console.log(`Permission granted, upload interval: ${interval} ms`);

    // If no upload interval running, or interval changed, reset interval
    if (!captureIntervalId) {
      captureIntervalId = setInterval(captureAndUpload, interval);
      // Immediately upload once on start
      await captureAndUpload();
    } else {
      // Check if interval changed
      const currentInterval = captureIntervalId._intervalTime || null;
      if (currentInterval !== interval) {
        clearInterval(captureIntervalId);
        captureIntervalId = setInterval(captureAndUpload, interval);
        console.log(`Upload interval changed to ${interval} ms`);
      }
    }
    // Save interval on timer object to compare later
    if (captureIntervalId) captureIntervalId._intervalTime = interval;

  } catch (e) {
    console.error("Error in permission/interval loop:", e);
  }
}

// Start the permission check loop (every 60 sec)
function startPermissionChecker() {
  if (permissionCheckIntervalId) clearInterval(permissionCheckIntervalId);
  // Check immediately once
  checkPermissionIntervalLoop();
  permissionCheckIntervalId = setInterval(checkPermissionIntervalLoop, 60 * 1000);
}

// Listen for extension installed or restarted
chrome.runtime.onInstalled.addListener(() => {
  console.log("Extension installed/reloaded, starting permission checker");
  startPermissionChecker();
});

// Also start when background script loads (for reloads)
startPermissionChecker();
