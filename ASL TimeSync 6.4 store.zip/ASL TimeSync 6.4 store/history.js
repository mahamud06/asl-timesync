function disableConsoleLog() {
    console.log = function() {};
}
// Call disableConsoleLog() to disable console logging
disableConsoleLog();

const googleSheetsApiKey = "AIzaSyDIuRc7QsUTJ8C5-0yzXeY9bM79-jxyTFY";

document.addEventListener("DOMContentLoaded", () => {
  // Default load: Current month (SALARY SHEET 01)
  loadRafatHistoryTable("SALARY SHEET 01"); // Default sheet load

  // Add button listeners
  const currentBtn = document.getElementById("currentMonthBtn");
  const previousBtn = document.getElementById("previousMonthBtn");
  const fingerprint = document.getElementById("fingerprint");

  currentBtn.addEventListener("click", () => {
    loadRafatHistoryTable("SALARY SHEET 01"); // Load current month sheet
    setActiveButton(currentBtn);
  });

  previousBtn.addEventListener("click", () => {
    loadRafatHistoryTable("SALARY SHEET 02"); // Load previous month sheet
    setActiveButton(previousBtn);
  });

  fingerprint.addEventListener("click", () => {
    loadRafatHistoryTable("SALARY SHEET 03"); // Load fingerprint sheet
    setActiveButton(fingerprint);
  });
});

// Function to set the active button
function setActiveButton(activeButton) {
  const buttons = [document.getElementById("currentMonthBtn"), 
                   document.getElementById("previousMonthBtn"), 
                   document.getElementById("fingerprint")];
  buttons.forEach(btn => {
    if (btn) {
      btn.classList.remove("active");
    }
  });
  if (activeButton) {
    activeButton.classList.add("active");
  }
}













async function loadRafatHistoryTable(sheetName = "SALARY SHEET 01") {
  const loadingScreen = document.getElementById("loadingScreen");
  const container = document.getElementById("historyContainer");
  const popup = document.getElementById("blockPopup") || createBlockPopup(); // Get or create popup

  // Show loading screen and clear previous table content
  loadingScreen.style.display = "block";
  container.innerHTML = "";
  popup.style.display = "none"; // Hide popup initially

  // Disable all buttons while the table is loading
  toggleButtons(false);

  // Check for username first
  chrome.storage.local.get("username", async (userResult) => {
    const username = userResult.username;

    if (!username) {
      console.warn("Username not found. Table will not be loaded.");
      container.innerHTML = `<p style="color: red; font-weight: bold; text-align: center; margin-top: 20px;">
        Please login to view your Salary Sheet.
      </p>`;
      loadingScreen.style.display = "none";
      toggleButtons(true); // Enable buttons again after loading is finished
      return;
    }

    // Check Employee_Management sheet for Draft status
    const isDraft = await checkEmployeeDraftStatus(username);
    if (isDraft) {
      container.innerHTML = ""; // Clear table
      popup.style.display = "block"; // Show popup
      loadingScreen.style.display = "none";
      toggleButtons(false); // Keep buttons disabled
      return;
    }

    // Delay the following code to make sure username is fetched before proceeding
    setTimeout(async () => {
      try {
        chrome.storage.local.get("sheetId2", (result) => {
          const sheetId = result.sheetId2;

          if (!sheetId) {
            console.error("Sheet ID not found in storage.");
            loadingScreen.style.display = "none";
            toggleButtons(true); // Enable buttons again after loading is finished
            return;
          }

          chrome.identity.getAuthToken({ interactive: true }, function (token) {
            if (!token) {
              console.error("Auth token not found.");
              loadingScreen.style.display = "none";
              toggleButtons(true); // Enable buttons again after loading is finished
              return;
            }

            // Write the username to cell D1 before loading the sheet
            const writeRange = `${sheetName}!D1`; // Writing to cell D1
            const writeData = {
              values: [[username]] // Writing username to cell D1
            };

            // Send the write request to update D1 with the username
            fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${writeRange}?valueInputOption=USER_ENTERED&key=${googleSheetsApiKey}`, {
              method: "PUT",
              headers: {
                Authorization: `Bearer ${token}`,
                "Content-Type": "application/json",
              },
              body: JSON.stringify(writeData),
            })
              .then((response) => {
                if (!response.ok) {
                  console.error("Error writing to Google Sheets:", response);
                  loadingScreen.style.display = "none";
                  toggleButtons(true); // Enable buttons again after loading is finished
                  return;
                }

                // Proceed to load the sheet after writing the username
                const range = `${sheetName}!C1:I`; // Define the range for the selected sheet

                fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${range}?key=${googleSheetsApiKey}`, {
                  method: "GET",
                  headers: {
                    Authorization: `Bearer ${token}`,
                  },
                })
                  .then((response) => response.json())
                  .then((data) => {
                    const values = data.values || [];

                    // Create table structure
                    const table = document.createElement("table");
                    table.style.borderCollapse = "collapse";
                    table.style.marginTop = "20px";
                    table.style.width = "100%";
                    table.style.border = "1px solid black";

                    values.forEach((row, rowIndex) => {
                      if (rowIndex === 0) return; // Skip header row

                      const tr = document.createElement("tr");

                      // Handle header row
                      if (rowIndex === 1) {
                        for (let i = 0; i < 7; i++) {
                          const th = document.createElement("th");
                          th.textContent = row[i] || "";
                          th.style.border = "1px solid black";
                          th.style.padding = "6px 10px";
                          th.style.fontSize = "14px";
                          th.style.backgroundColor = "brown";
                          th.style.color = "white";
                          th.style.textAlign = "center";
                          tr.appendChild(th);
                        }
                      } else {
                        // Handle data rows
                        for (let i = 0; i < 7; i++) {
                          const td = document.createElement("td");
                          td.textContent = row[i] || "";
                          td.style.border = "1px solid black";
                          td.style.padding = "6px 10px";
                          td.style.fontSize = "14px";
                          td.style.textAlign = "center";

                          // Apply colors for specific rows in SALARY SHEET 03 (fingerprint)
                          if (sheetName === "SALARY SHEET 03") {
                            if (rowIndex === 33) {
                              td.style.backgroundColor = "red";
                              td.style.color = "white"; // Ensure text is visible on red background
                            } else if (rowIndex === 45) {
                              td.style.backgroundColor = "#ead1dc";
                              td.style.color = "black"; // Ensure text is visible on yellow background
                            } else if (rowIndex === 58) {
                              td.style.backgroundColor = "Green";
                              td.style.color = "white"; // Ensure text is visible on yellow background
                            }
else if (rowIndex === 42 && (i === 2 || i === 3 || i === 4)) {
  td.style.backgroundColor = "#2abf41";
  td.style.color = "white"; // Ensure text is visible on green background
}
else if (rowIndex === 49||rowIndex === 50) {
  td.style.backgroundColor = "#c5e6ca";
  td.style.color = "black"; // Ensure text is visible on green background
}
else if (rowIndex === 51||rowIndex === 52) {
  td.style.backgroundColor = "#f39999";
  td.style.color = "black"; // Ensure text is visible on green background
}

else if ((rowIndex === 38||rowIndex === 37) && (i === 5 || i === 6)) {
  td.style.backgroundColor = "#9d2b16";
  td.style.color = "white"; // Ensure text is visible on green background
}


else if ((rowIndex === 36||rowIndex === 35) && (i === 3)) {
  td.style.backgroundColor = "#9d2b16";
  td.style.color = "white"; // Ensure text is visible on green background
}

							else if (td.textContent === "Check-in miss" || td.textContent === "Check-out miss") {
                              td.style.backgroundColor = "red";
                              td.style.color = "white"; // Ensure text is visible on red background
                            } else if (td.textContent === "Time Problem") {
                              td.style.backgroundColor = "purple";
                              td.style.color = "white"; // Ensure text is visible on purple background
                            } else if (td.textContent === "Time Ok") {
                              td.style.backgroundColor = "orange";
                              td.style.color = "white"; // Ensure text is visible on orange background
                            } else if (td.textContent === "Day off") {
                              td.style.backgroundColor = "green";
                              td.style.color = "white"; // Ensure text is visible on green background
                            } else if (i === 0) {
                              td.style.backgroundColor = "brown";
                              td.style.color = "white";
                            } else {
                              td.style.backgroundColor = "pink";
                            }
                          } else {
                            // Existing logic for other sheets (SALARY SHEET 01 and SALARY SHEET 02)
                            if (td.textContent === "Check-in miss" || td.textContent === "Check-out miss") {
                              td.style.backgroundColor = "red";
                              td.style.color = "white"; // Ensure text is visible on red background
                            } else if (td.textContent === "Time Problem") {
                              td.style.backgroundColor = "purple";
                              td.style.color = "white"; // Ensure text is visible on purple background
                            } else if (td.textContent === "Time Ok") {
                              td.style.backgroundColor = "orange";
                              td.style.color = "white"; // Ensure text is visible on orange background
                            } else if (td.textContent === "Day off") {
                              td.style.backgroundColor = "green";
                              td.style.color = "white"; // Ensure text is visible on green background
                            } else if (rowIndex === 38 || rowIndex === 43) {
                              td.style.backgroundColor = "green";
                              td.style.color = "white"; // Ensure text is visible on green background
                            } else if (i === 0) {
                              td.style.backgroundColor = "brown";
                              td.style.color = "white";
                            } else {
                              td.style.backgroundColor = "pink";
                            }
                          }

                          tr.appendChild(td);
                        }
                      }

                      table.appendChild(tr);
                    });

                    container.appendChild(table);
                    loadingScreen.style.display = "none";
                    toggleButtons(true); // Enable buttons again after the table is loaded
                  })
                  .then(() => {
                    // Set active button based on sheetName after table is loaded
                    const buttonMap = {
                      "SALARY SHEET 01": document.getElementById("currentMonthBtn"),
                      "SALARY SHEET 02": document.getElementById("previousMonthBtn"),
                      "SALARY SHEET 03": document.getElementById("fingerprint")
                    };
                    setActiveButton(buttonMap[sheetName]);
                  })
                  .catch((error) => {
                    console.error("Error fetching data from Google Sheets:", error);
                    loadingScreen.style.display = "none";
                    toggleButtons(true); // Enable buttons again after loading is finished
                  });
              })
              .catch((error) => {
                console.error("Error writing to Google Sheets:", error);
                loadingScreen.style.display = "none";
                toggleButtons(true); // Enable buttons again after loading is finished
              });
          });
        });
      } catch (error) {
        console.error("Error retrieving sheet name:", error);
        loadingScreen.style.display = "none";
        toggleButtons(true); // Enable buttons again after loading is finished
      }
    }, 0);
  });
}

// Function to check if username has Draft status in Employee_Management sheet
async function checkEmployeeDraftStatus(username) {
  try {
    const sheetId = await new Promise((resolve) => {
      chrome.storage.local.get("sheetId2", (result) => resolve(result.sheetId2));
    });

    if (!sheetId) {
      console.error("Sheet ID not found in storage.");
      return false;
    }

    const token = await new Promise((resolve, reject) => {
      chrome.identity.getAuthToken({ interactive: true }, (token) => {
        if (!token) reject("Auth token not found.");
        resolve(token);
      });
    });

    const range = "Employee_Management!A:AG"; // Fetch all columns including AG (Status)
    const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${range}?key=${googleSheetsApiKey}`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      console.error("Error fetching Employee_Management data:", response);
      return false;
    }

    const data = await response.json();
    const values = data.values || [];

    // Assume username is in column A and Status is in column AG (33rd column, index 32)
    for (let i = 1; i < values.length; i++) { // Skip header row
      if (values[i][0] === username && values[i][32] === "Draft") {
        return true;
      }
    }

    return false;
  } catch (error) {
    console.error("Error checking Employee_Management sheet:", error);
    return false;
  }
}

// Function to create a block popup
function createBlockPopup() {
  const popup = document.createElement("div");
  popup.id = "blockPopup";
  popup.style.position = "fixed";
  popup.style.top = "50%";
  popup.style.left = "50%";
  popup.style.transform = "translate(-50%, -50%)";
  popup.style.backgroundColor = "white";
  popup.style.border = "5px solid red";
  popup.style.padding = "20px";
  popup.style.boxShadow = "0 0 10px rgba(0,0,0,0.5)";
  popup.style.zIndex = "10000";
  popup.style.textAlign = "center";
  popup.style.fontSize = "18px";
  popup.style.fontWeight = "bold";
  popup.style.color = "red";
  popup.innerHTML = `
    <strong>Your account restricted to view salary sheet because your profile information is incomplete.</strong><br>
     Please contact support for further assistance.<br>
    <button id="updateInfoBtn" style="margin-top: 10px; padding: 8px 16px; background-color: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer;">
      Update Your Information
    </button>
  `;
  document.body.appendChild(popup);

  // Add event listener to the button
  const updateInfoBtn = document.getElementById("updateInfoBtn");
  updateInfoBtn.addEventListener("click", () => {
    window.open(chrome.runtime.getURL("Form/employeeDetails.html"), "_blank");
  });

  return popup;
}

// Function to toggle button states (enable/disable)
function toggleButtons(enable) {
  const currentBtn = document.getElementById("currentMonthBtn");
  const previousBtn = document.getElementById("previousMonthBtn");
  const fingerprint = document.getElementById("fingerprint");

  if (currentBtn) currentBtn.disabled = !enable;
  if (previousBtn) previousBtn.disabled = !enable;
  if (fingerprint) fingerprint.disabled = !enable;
}